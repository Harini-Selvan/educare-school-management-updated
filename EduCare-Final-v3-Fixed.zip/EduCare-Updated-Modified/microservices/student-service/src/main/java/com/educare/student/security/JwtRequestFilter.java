package com.educare.student.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        // Only accept requests coming through the API Gateway.
        // The gateway sets X-User-Role and X-User-Email headers after validating the JWT.
        // Direct requests without these headers are passed through as-is;
        // the RoleValidator in each controller will reject them if the headers are missing.
        filterChain.doFilter(request, response);
    }
}
