package com.educare.dto.request;

import com.educare.model.Student;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class StudentRequest {

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    private LocalDate dob;

    @NotNull(message = "Gender is required")
    private Student.Gender gender;

    @NotBlank(message = "Contact information is required")
    @Email(message = "Please provide a valid email address") // Assuming contactInfo is an email
    private String contactInfo;

    @NotBlank(message = "Program is required")
    private String program;

    @NotNull(message = "Student status is required")
    private Student.StudentStatus status;
}
