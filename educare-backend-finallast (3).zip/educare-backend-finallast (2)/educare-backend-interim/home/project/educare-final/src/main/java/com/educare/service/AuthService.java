package com.educare.service;

import com.educare.dto.request.LoginRequest;
import com.educare.dto.request.RegisterRequest;
import com.educare.dto.response.AuthResponse;
import com.educare.exception.BadRequestException;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.AuditLog;
import com.educare.model.User;
import com.educare.repository.AuditLogRepository;
import com.educare.repository.UserRepository;
import com.educare.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final EmailService emailService;

    // ============================================
    // Login - any user
    // ============================================
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + request.getEmail()));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadRequestException("Invalid email or password");
        }

        if (user.getStatus() != User.UserStatus.ACTIVE) {
            throw new BadRequestException("Account is " + user.getStatus().name().toLowerCase() + ". Contact administrator.");
        }

        // Append-only audit log entry
        auditLogRepository.save(AuditLog.builder()
            .user(user)
            .action("LOGIN")
            .resourceType("AUTH")
            .details("User logged in successfully")
            .build());

        String token = jwtUtil.generateToken(user);

        return AuthResponse.builder()
            .token(token)
            .type("Bearer")
            .userId(user.getUserId())
            .name(user.getName())
            .email(user.getEmail())
            .role(user.getRole())
            .build();
    }

    // ============================================
    // Register - ADMIN ONLY
    // Admin registers users and sends credentials via email
    // ============================================
    public AuthResponse registerByAdmin(RegisterRequest request, User adminUser) {
        // Only admin can register users
        if (adminUser == null || adminUser.getRole() != User.Role.ADMIN) {
            throw new BadRequestException("Only administrators can register new users");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        // Use provided password or generate one
        String rawPassword = request.getPassword();

        User user = User.builder()
            .name(request.getName())
            .email(request.getEmail())
            .password(passwordEncoder.encode(rawPassword))
            .role(request.getRole())
            .phone(request.getPhone())
            .status(User.UserStatus.ACTIVE)
            .build();

        User saved = userRepository.save(user);

        // Append-only audit log
        auditLogRepository.save(AuditLog.builder()
            .user(adminUser)
            .action("REGISTER_USER")
            .resourceType("USER")
            .resourceId(saved.getUserId())
            .details("Admin " + adminUser.getName() + " registered new user: "
                + saved.getEmail() + " with role: " + saved.getRole())
            .build());

        // Send credentials email to the new user
        if (request.isSendCredentialsEmail()) {
            emailService.sendUserCredentials(
                saved.getEmail(),
                saved.getName(),
                rawPassword,
                saved.getRole().name()
            );
            log.info("Credentials email sent to: {}", saved.getEmail());
        }

        log.info("Admin {} registered new user {} with role {}",
            adminUser.getUserId(), saved.getEmail(), saved.getRole());

        String token = jwtUtil.generateToken(saved);

        return AuthResponse.builder()
            .token(token)
            .type("Bearer")
            .userId(saved.getUserId())
            .name(saved.getName())
            .email(saved.getEmail())
            .role(saved.getRole())
            .build();
    }
}
