package com.educare.dto.request;

import lombok.Data;
import java.util.List;

@Data
public class NotificationRequest {

    private String title;
    private String message;

    // ✅ Send to specific users
    private List<Long> userIds;

    // ✅ Send by roles (MULTIPLE roles)
    private List<String> roles;

    // ✅ Send to all users
    private Boolean sendToAll;

    // ✅ Send email or not
    private boolean sendEmail;
}