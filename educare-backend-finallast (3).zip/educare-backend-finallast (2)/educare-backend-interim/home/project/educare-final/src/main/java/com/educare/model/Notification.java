package com.educare.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String message;

    private Long userId;
    private String userName;
    private String userEmail;
    private String role;

    private boolean emailSent;

    private LocalDateTime createdAt;
}