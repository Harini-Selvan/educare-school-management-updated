package com.educare.config;

import com.educare.model.User;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Check if admin already exists — if yes, skip
        if (userRepository.findByEmail("pallavarapurichithaa@gmail.com").isPresent()) {
            log.info("Admin user already exists — skipping initialization.");
            return;
        }

        // Create default admin user
        User admin = User.builder()
            .name("Admin")
            .email("pallavarapurichithaa@gmail.com")
            .password(passwordEncoder.encode("ADMIN@123"))
            .role(User.Role.ADMIN)
            .phone("08688242239")
            .status(User.UserStatus.ACTIVE)
            .build();

        userRepository.save(admin);
        log.info("✅ Default admin user created successfully.");
        log.info("   Email    : pallavarapurichithaa@gmail.com");
        log.info("   Password : ADMIN@123");
        log.info("   Role     : ADMIN");
    }
}