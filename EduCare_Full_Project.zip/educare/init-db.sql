-- EduCare Database Initialization
-- Creates all service databases

CREATE DATABASE educare_identity;
CREATE DATABASE educare_students;
CREATE DATABASE educare_classes;
CREATE DATABASE educare_attendance;
CREATE DATABASE educare_exams;
CREATE DATABASE educare_notifications;
CREATE DATABASE educare_reporting;
CREATE DATABASE educare_tasks;

GRANT ALL PRIVILEGES ON DATABASE educare_identity TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_students TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_classes TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_attendance TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_exams TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_notifications TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_reporting TO educare;
GRANT ALL PRIVILEGES ON DATABASE educare_tasks TO educare;
