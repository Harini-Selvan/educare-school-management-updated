-- V1__init_reporting_schema.sql

CREATE TABLE IF NOT EXISTS reports (
    report_id    BIGSERIAL    PRIMARY KEY,
    type         VARCHAR(100) NOT NULL,
    title        VARCHAR(200) NOT NULL,
    parameters   TEXT,
    result_uri   TEXT,
    status       VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    requested_by BIGINT       NOT NULL,
    requested_at TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX idx_reports_requested_by ON reports(requested_by, requested_at DESC);
CREATE INDEX idx_reports_type         ON reports(type, requested_at DESC);
CREATE INDEX idx_reports_status       ON reports(status);
