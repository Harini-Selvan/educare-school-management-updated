-- V1__init_exam_grade_schema.sql

CREATE TABLE IF NOT EXISTS exams (
    exam_id      BIGSERIAL    PRIMARY KEY,
    class_id     BIGINT       NOT NULL,
    scheduled_at TIMESTAMPTZ  NOT NULL,
    subject      VARCHAR(200) NOT NULL,
    status       VARCHAR(20)  NOT NULL DEFAULT 'SCHEDULED',
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_exams_class_scheduled ON exams(class_id, scheduled_at);
CREATE INDEX idx_exams_status          ON exams(status);

CREATE TABLE IF NOT EXISTS grades (
    grade_id     BIGSERIAL       PRIMARY KEY,
    student_id   BIGINT          NOT NULL,
    exam_id      BIGINT          NOT NULL REFERENCES exams(exam_id),
    grade_value  NUMERIC(5,2)    NOT NULL CHECK (grade_value >= 0 AND grade_value <= 100),
    submitted_by BIGINT          NOT NULL,
    submitted_at TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    status       VARCHAR(20)     NOT NULL DEFAULT 'SUBMITTED',
    UNIQUE (student_id, exam_id)
);

CREATE INDEX idx_grades_student ON grades(student_id);
CREATE INDEX idx_grades_exam    ON grades(exam_id);

CREATE TABLE IF NOT EXISTS grade_changes (
    change_id    BIGSERIAL    PRIMARY KEY,
    grade_id     BIGINT       NOT NULL REFERENCES grades(grade_id),
    changed_by   BIGINT       NOT NULL,
    changed_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    reason       TEXT         NOT NULL,
    evidence_uri VARCHAR(500),
    status       VARCHAR(20)  NOT NULL DEFAULT 'APPROVED'
);

CREATE INDEX idx_grade_changes_grade ON grade_changes(grade_id);
