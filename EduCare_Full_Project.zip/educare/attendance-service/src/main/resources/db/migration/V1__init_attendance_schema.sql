-- V1__init_attendance_schema.sql

CREATE TABLE IF NOT EXISTS attendance_records (
    attendance_id BIGSERIAL    PRIMARY KEY,
    student_id    BIGINT       NOT NULL,
    class_id      BIGINT       NOT NULL,
    date          DATE         NOT NULL,
    status        VARCHAR(20)  NOT NULL CHECK (status IN ('PRESENT','ABSENT','LATE','EXCUSED')),
    recorded_by   BIGINT       NOT NULL,
    remarks       TEXT,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    UNIQUE (student_id, class_id, date)
);

CREATE INDEX idx_attendance_student_date ON attendance_records(student_id, date);
CREATE INDEX idx_attendance_class_date   ON attendance_records(class_id,   date);
CREATE INDEX idx_attendance_status       ON attendance_records(status);
