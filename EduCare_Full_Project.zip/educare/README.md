# EduCare — School Administration & Student Performance Management System

> Production-ready microservices platform built with Spring Boot 3, React 18, PostgreSQL 15, and Docker.

---

## Architecture Overview

```
                          ┌─────────────────────┐
   Browser / Mobile  ──►  │   React Frontend     │  :3000
                          │   (Bootstrap 5)       │
                          └──────────┬────────────┘
                                     │ HTTP
                          ┌──────────▼────────────┐
                          │   API Gateway          │  :8080
                          │   (JWT Filter, LB)     │
                          └──────────┬────────────┘
                 ┌───────────────────┼───────────────────┐
                 │                   │                   │
        ┌────────▼───────┐  ┌────────▼───────┐  ┌───────▼────────┐
        │ Identity Svc   │  │ Student Svc    │  │ Attendance Svc │
        │ :8081          │  │ :8082          │  │ :8084          │
        └────────────────┘  └────────────────┘  └────────────────┘
        ┌────────────────┐  ┌────────────────┐  ┌────────────────┐
        │ Class/Teacher  │  │ Exam/Grade Svc │  │Notification Svc│
        │ :8083          │  │ :8085          │  │ :8086          │
        └────────────────┘  └────────────────┘  └────────────────┘
        ┌────────────────┐  ┌────────────────┐
        │ Reporting Svc  │  │ Task-Alert Svc │
        │ :8087          │  │ :8088          │
        └────────────────┘  └────────────────┘
                 │
        ┌────────▼───────────────────────────────────────┐
        │              PostgreSQL 15                      │
        │  8 isolated databases (one per service)         │
        └────────────────────────────────────────────────┘
        ┌────────────────┐  ┌────────────────┐
        │  Eureka Server │  │  Config Server │
        │  :8761         │  │  :8888         │
        └────────────────┘  └────────────────┘
```

---

## Project Structure

```
educare/
├── config-server/          Spring Cloud Config Server
├── eureka-server/          Service Discovery
├── api-gateway/            JWT filter + routing
├── identity-service/       Auth, RBAC, Audit Logs
├── student-service/        Student registry & enrollment
├── class-teacher-service/  Class scheduling & teacher assignment
├── attendance-service/     Daily attendance + parent alerts
├── exam-grade-service/     Exam scheduling & grade management
├── notification-service/   In-app + email notifications
├── reporting-service/      KPIs, reports & audit packages
├── task-alert-service/     Task management + overdue scheduler
├── frontend/               React 18 + Bootstrap 5 SPA
├── docker-compose.yml
├── init-db.sql
└── .env.example
```

---

## Prerequisites

| Tool              | Version  | Purpose               |
|-------------------|----------|-----------------------|
| Java (JDK)        | 17 LTS   | Backend runtime       |
| Maven             | 3.9+     | Build tool            |
| Node.js           | 18+      | Frontend build        |
| Docker + Compose  | 24+      | Containerisation      |
| PostgreSQL        | 15+      | Primary database      |

---

## Quick Start

### 1 — Clone & configure

```bash
git clone https://github.com/your-org/educare.git
cd educare
cp .env.example .env
# Edit .env — set DB_PASSWORD and JWT_SECRET
```

### 2 — Start everything with Docker Compose

```bash
docker-compose up -d
```

Services start in dependency order. Allow ~60 s for all services to register with Eureka.

### 3 — Verify

```bash
# Eureka dashboard
open http://localhost:8761

# API Gateway health
curl http://localhost:8080/actuator/health

# Frontend
open http://localhost:3000
```

### 4 — Seed first admin user

```bash
curl -s -X POST http://localhost:8080/api/v1/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"name":"System Admin","email":"admin@school.edu","password":"Admin@1234","role":"ADMIN"}'
```

> **Change the password immediately after first login.**

### 5 — Login and get token

```bash
TOKEN=$(curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@school.edu","password":"Admin@1234"}' | jq -r '.token')

echo $TOKEN
```

---

## Service Port Reference

| Service               | Port |
|-----------------------|------|
| Frontend              | 3000 |
| API Gateway           | 8080 |
| Identity Service      | 8081 |
| Student Service       | 8082 |
| Class/Teacher Service | 8083 |
| Attendance Service    | 8084 |
| Exam/Grade Service    | 8085 |
| Notification Service  | 8086 |
| Reporting Service     | 8087 |
| Task-Alert Service    | 8088 |
| Eureka Server         | 8761 |
| Config Server         | 8888 |
| PostgreSQL            | 5432 |

---

## API Reference (Key Endpoints)

All endpoints go through the API Gateway at `http://localhost:8080`.  
Include `Authorization: Bearer <token>` on all protected routes.

### Auth
| Method | Path                       | Roles     |
|--------|----------------------------|-----------|
| POST   | /api/v1/auth/login         | Public    |
| POST   | /api/v1/auth/register      | ADMIN     |

### Students
| Method | Path                            | Roles                    |
|--------|---------------------------------|--------------------------|
| GET    | /api/v1/students                | ADMIN, TEACHER, AUDITOR  |
| POST   | /api/v1/students                | ADMIN                    |
| GET    | /api/v1/students/{id}           | ADMIN, TEACHER, PARENT   |
| PUT    | /api/v1/students/{id}           | ADMIN                    |
| POST   | /api/v1/students/{id}/enroll    | ADMIN                    |
| POST   | /api/v1/students/import         | ADMIN (CSV)              |

### Attendance
| Method | Path                               | Roles              |
|--------|------------------------------------|--------------------|
| POST   | /api/v1/attendance                 | TEACHER            |
| GET    | /api/v1/attendance/student/{id}    | All authenticated  |
| GET    | /api/v1/attendance/class/{id}      | ADMIN, TEACHER     |

### Exams & Grades
| Method | Path                            | Roles                        |
|--------|---------------------------------|------------------------------|
| POST   | /api/v1/exams                   | EXAM_COORDINATOR             |
| GET    | /api/v1/exams                   | TEACHER, STUDENT, ADMIN      |
| POST   | /api/v1/grades                  | TEACHER, EXAM_COORDINATOR    |
| PUT    | /api/v1/grades/{id}             | EXAM_COORDINATOR             |
| GET    | /api/v1/grades/student/{id}     | All authenticated            |

### Reports & KPIs
| Method | Path                     | Roles          |
|--------|--------------------------|----------------|
| GET    | /api/v1/kpis             | ADMIN, AUDITOR |
| POST   | /api/v1/reports/generate | ADMIN          |
| POST   | /api/v1/audit-packages   | ADMIN, AUDITOR |

---

## RBAC Summary

| Role             | Key Permissions                                      |
|------------------|------------------------------------------------------|
| ADMIN            | Full access — enrollment, scheduling, user mgmt      |
| TEACHER          | Mark attendance, submit grades, message parents      |
| STUDENT          | View own grades, attendance, timetable               |
| PARENT           | View child's data, receive alerts, message teachers  |
| EXAM_COORDINATOR | Schedule exams, modify grades with evidence          |
| AUDITOR          | Read-only access to all records and audit packages   |

---

## JWT Flow

```
1. POST /api/v1/auth/login  →  { token, role, name }
2. Store token in localStorage
3. All requests: Authorization: Bearer <token>
4. API Gateway validates signature + expiry
5. Gateway injects X-User-Id and X-User-Role headers
6. Services enforce @PreAuthorize("hasRole('...')")
```

Token payload:
```json
{ "sub": "userId", "email": "...", "role": "ADMIN", "iat": ..., "exp": ... }
```

---

## Running Tests

```bash
# All unit tests
mvn test

# Specific service
cd identity-service && mvn test

# With coverage report
mvn verify
open target/site/jacoco/index.html
```

---

## CSV Import Format (Students)

```csv
name,dob,gender,contactInfo,program
Alice Smith,2008-03-15,F,alice@parent.com,Science
Bob Jones,2009-07-22,M,bob@parent.com,Arts
```

---

## Environment Variables

| Variable       | Description                          | Required |
|----------------|--------------------------------------|----------|
| DB_PASSWORD    | PostgreSQL password                  | Yes      |
| JWT_SECRET     | HS512 signing key (min 32 chars)     | Yes      |
| MAIL_HOST      | SMTP host for email alerts           | No       |
| MAIL_PORT      | SMTP port                            | No       |
| MAIL_USERNAME  | SMTP username                        | No       |
| MAIL_PASSWORD  | SMTP password                        | No       |

---

## Production Checklist

- [ ] Change default admin password after first login
- [ ] Set strong `JWT_SECRET` (minimum 32 random characters)
- [ ] Set strong `DB_PASSWORD`
- [ ] Enable TLS on API Gateway
- [ ] Restrict `/api/v1/notifications/internal/*` to internal network
- [ ] Configure real SMTP credentials for email alerts
- [ ] Set up nightly PostgreSQL backups
- [ ] Configure centralised logging (ELK or Grafana Loki)
- [ ] Add health check alerts to monitoring system

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | React 18, Bootstrap 5, Axios, Chart.js |
| Backend     | Spring Boot 3.2, Spring Security 6 |
| Gateway     | Spring Cloud Gateway                |
| Discovery   | Netflix Eureka                      |
| Auth        | JWT (JJWT 0.11, HS512)             |
| Database    | PostgreSQL 15 + Flyway migrations   |
| Build       | Maven 3.9 (backend), npm (frontend) |
| Container   | Docker + Docker Compose 24          |
| Testing     | JUnit 5, Mockito                    |
| Docs        | SpringDoc OpenAPI / Swagger UI      |

---

*EduCare v1.0 — Confidential*
