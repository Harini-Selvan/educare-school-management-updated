-- V1__init_notification_schema.sql

CREATE TABLE IF NOT EXISTS notifications (
    notification_id BIGSERIAL    PRIMARY KEY,
    recipient_id    BIGINT       NOT NULL,
    category        VARCHAR(50)  NOT NULL,
    type            VARCHAR(50)  NOT NULL,
    message         TEXT         NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'UNREAD',
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notif_recipient ON notifications(recipient_id, status);
CREATE INDEX idx_notif_created   ON notifications(created_at DESC);

CREATE TABLE IF NOT EXISTS messages (
    message_id   BIGSERIAL    PRIMARY KEY,
    sender_id    BIGINT       NOT NULL,
    recipient_id BIGINT       NOT NULL,
    content      TEXT         NOT NULL,
    status       VARCHAR(20)  NOT NULL DEFAULT 'SENT',
    sent_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_msg_recipient ON messages(recipient_id, sent_at DESC);
CREATE INDEX idx_msg_sender    ON messages(sender_id,    sent_at DESC);
