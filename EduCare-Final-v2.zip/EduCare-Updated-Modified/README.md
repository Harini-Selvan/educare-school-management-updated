# EduCare — School Administration & Student Performance Management System

## Quick Start

### Step 1 — Prerequisites
- Java 17 (https://adoptium.net)
- Maven 3.8+ (https://maven.apache.org)
- MySQL 8.x running on localhost:3306

### Step 2 — Create Databases
Run this in MySQL Workbench or terminal:
```sql
CREATE DATABASE auth_db;
CREATE DATABASE student_db;
CREATE DATABASE class_db;
CREATE DATABASE attendance_db;
CREATE DATABASE exam_db;
CREATE DATABASE notification_db;
CREATE DATABASE report_db;
```

### Step 3 — Update MySQL Password (if not 'root')
Edit each file in: config-server/src/main/resources/config-repo/
Change: spring.datasource.password=root
To:     spring.datasource.password=YOUR_PASSWORD

### Step 4 — Start Services IN THIS ORDER

1. discovery-service    → port 8761
2. config-server        → port 8888
3. api-gateway          → port 9090
4. auth-service         → port 8081
5. student-service      → port 8082
6. class-service        → port 8083
7. attendance-service   → port 8084
8. exam-service         → port 8085
9. notification-service → port 8086
10. report-service      → port 8087

### Step 5 — Verify
- Eureka Dashboard:  http://localhost:8761
- Swagger UI:        http://localhost:9090/swagger-ui.html

### Step 6 — Default Admin Login
POST http://localhost:9090/api/auth/login
{
  "email": "admin@educare.com",
  "password": "admin123"
}

## Service Summary
| Service              | Port | Database        |
|----------------------|------|-----------------|
| discovery-service    | 8761 | —               |
| config-server        | 8888 | —               |
| api-gateway          | 9090 | —               |
| auth-service         | 8081 | auth_db         |
| student-service      | 8082 | student_db      |
| class-service        | 8083 | class_db        |
| attendance-service   | 8084 | attendance_db   |
| exam-service         | 8085 | exam_db         |
| notification-service | 8086 | notification_db |
| report-service       | 8087 | report_db       |
