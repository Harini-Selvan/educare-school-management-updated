import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Auth
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Admin
import AdminDashboard from './pages/admin/Dashboard';
import AdminUsers from './pages/admin/Users';
import AdminClasses from './pages/admin/Classes';
import AdminTeachers from './pages/admin/Teachers';
import AdminStudents from './pages/admin/Students';
import AdminTasks from './pages/admin/Tasks';
import AdminProfile from './pages/admin/Profile';
import AdminEnrollments from './pages/admin/Enrollments';

// Teacher
import TeacherDashboard from './pages/teacher/Dashboard';
import TeacherMyStudents from './pages/teacher/MyStudents';
import TeacherTimetable from './pages/teacher/Timetable';
import TeacherAttendance from './pages/teacher/Attendance';
import TeacherGrades from './pages/teacher/Grades';
import TeacherMessages from './pages/teacher/Messages';
import TeacherTasks from './pages/teacher/Tasks';
import TeacherGradeRequests from './pages/teacher/GradeRequests';

// Student
import StudentDashboard from './pages/student/Dashboard';
import StudentProfile from './pages/student/Profile';
import StudentAttendance from './pages/student/Attendance';
import StudentTimetable from './pages/student/Timetable';
import StudentGrades from './pages/student/Grades';

// Parent
import ParentDashboard from './pages/parent/Dashboard';
import ParentAttendance from './pages/parent/Attendance';
import ParentGrades from './pages/parent/Grades';
import ParentMessages from './pages/parent/Messages';

// Coordinator
import CoordinatorDashboard from './pages/coordinator/Dashboard';
import CoordinatorExams from './pages/coordinator/Exams';
import CoordinatorTasks from './pages/coordinator/Tasks';
import CoordinatorGradeRequests from './pages/coordinator/GradeRequests';

// Auditor
import AuditorDashboard from './pages/auditor/Dashboard';
import AuditorLogs from './pages/auditor/AuditLogs';

// Protected Route
function ProtectedRoute({ children, allowedRoles }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 40, height: 40, border: '4px solid #e2e8f0', borderTopColor: '#2563eb', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 16px' }} />
        <p style={{ color: '#64748b', fontFamily: 'Outfit, sans-serif' }}>Loading...</p>
      </div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/login" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/" element={<Navigate to={user ? getDefaultRoute(user.role) : '/login'} replace />} />

      {/* Admin Routes */}
      <Route path="/admin" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/users" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminUsers /></ProtectedRoute>} />
      <Route path="/admin/classes" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminClasses /></ProtectedRoute>} />
      <Route path="/admin/teachers" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminTeachers /></ProtectedRoute>} />
      <Route path="/admin/students" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminStudents /></ProtectedRoute>} />
      <Route path="/admin/tasks" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminTasks /></ProtectedRoute>} />
      <Route path="/admin/profile" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminProfile /></ProtectedRoute>} />
      <Route path="/admin/enrollments" element={<ProtectedRoute allowedRoles={['ADMIN']}><AdminEnrollments /></ProtectedRoute>} />

      {/* Teacher Routes */}
      <Route path="/teacher" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherDashboard /></ProtectedRoute>} />
      <Route path="/teacher/students" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherMyStudents /></ProtectedRoute>} />
      <Route path="/teacher/timetable" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherTimetable /></ProtectedRoute>} />
      <Route path="/teacher/attendance" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherAttendance /></ProtectedRoute>} />
      <Route path="/teacher/grades" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherGrades /></ProtectedRoute>} />
      <Route path="/teacher/messages" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherMessages /></ProtectedRoute>} />
      <Route path="/teacher/tasks" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherTasks /></ProtectedRoute>} />
      <Route path="/teacher/grade-requests" element={<ProtectedRoute allowedRoles={['TEACHER']}><TeacherGradeRequests /></ProtectedRoute>} />

      {/* Student Routes */}
      <Route path="/student" element={<ProtectedRoute allowedRoles={['STUDENT']}><StudentDashboard /></ProtectedRoute>} />
      <Route path="/student/profile" element={<ProtectedRoute allowedRoles={['STUDENT']}><StudentProfile /></ProtectedRoute>} />
      <Route path="/student/attendance" element={<ProtectedRoute allowedRoles={['STUDENT']}><StudentAttendance /></ProtectedRoute>} />
      <Route path="/student/timetable" element={<ProtectedRoute allowedRoles={['STUDENT']}><StudentTimetable /></ProtectedRoute>} />
      <Route path="/student/grades" element={<ProtectedRoute allowedRoles={['STUDENT']}><StudentGrades /></ProtectedRoute>} />

      {/* Parent Routes */}
      <Route path="/parent" element={<ProtectedRoute allowedRoles={['PARENT']}><ParentDashboard /></ProtectedRoute>} />
      <Route path="/parent/attendance" element={<ProtectedRoute allowedRoles={['PARENT']}><ParentAttendance /></ProtectedRoute>} />
      <Route path="/parent/grades" element={<ProtectedRoute allowedRoles={['PARENT']}><ParentGrades /></ProtectedRoute>} />
      <Route path="/parent/messages" element={<ProtectedRoute allowedRoles={['PARENT']}><ParentMessages /></ProtectedRoute>} />

      {/* Coordinator Routes */}
      <Route path="/coordinator" element={<ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}><CoordinatorDashboard /></ProtectedRoute>} />
      <Route path="/coordinator/exams" element={<ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}><CoordinatorExams /></ProtectedRoute>} />
      <Route path="/coordinator/tasks" element={<ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}><CoordinatorTasks /></ProtectedRoute>} />
      <Route path="/coordinator/grade-requests" element={<ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}><CoordinatorGradeRequests /></ProtectedRoute>} />

      {/* Auditor Routes */}
      <Route path="/auditor" element={<ProtectedRoute allowedRoles={['AUDITOR']}><AuditorDashboard /></ProtectedRoute>} />
      <Route path="/auditor/audit-logs" element={<ProtectedRoute allowedRoles={['AUDITOR']}><AuditorLogs /></ProtectedRoute>} />

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

function getDefaultRoute(role) {
  const routes = {
    ADMIN: '/admin', TEACHER: '/teacher', STUDENT: '/student',
    PARENT: '/parent', EXAM_COORDINATOR: '/coordinator', AUDITOR: '/auditor',
  };
  return routes[role] || '/login';
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
