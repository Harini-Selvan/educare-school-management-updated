import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import { authAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

export default function AuditorDashboard() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    authAPI.getAuditLogs().then(r => setLogs(r.data || [])).finally(() => setLoading(false));
  }, []);

  const recent = logs.slice(0, 10);
  const methodCounts = { POST: 0, PUT: 0, PATCH: 0, DELETE: 0 };
  logs.forEach(l => {
    const m = (l.httpMethod || '').toUpperCase();
    if (methodCounts[m] !== undefined) methodCounts[m]++;
  });

  return (
    <DashboardLayout title="Auditor Dashboard">
      <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 10, padding: '14px 18px', marginBottom: 20, fontSize: 13, color: '#78350f' }}>
        <strong>🔍 Read-Only Access</strong> — You can view audit logs only. No create, edit, or delete actions are permitted for the Auditor role.
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          ['Total Logs', logs.length, '#1e40af'],
          ['POST Operations', methodCounts.POST, '#059669'],
          ['Mutations (PUT/PATCH)', methodCounts.PUT + methodCounts.PATCH, '#d97706'],
          ['DELETE Operations', methodCounts.DELETE, '#dc2626'],
        ].map(([l, v, c]) => (
          <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)' }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: c }}>{v}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: 12, fontWeight: 600, marginTop: 4 }}>{l}</div>
          </div>
        ))}
      </div>

      <Card title="Recent Audit Activity" extra={<Button onClick={() => navigate('/auditor/audit-logs')}>View All Logs</Button>}>
        {loading ? <p style={{ padding: 20, color: 'var(--text-muted)' }}>Loading...</p> :
          recent.map((log, i) => (
            <div key={i} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 700, color: 'var(--primary)', background: 'var(--primary-light)', padding: '2px 6px', borderRadius: 4 }}>{log.action}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 10 }}>by {log.userEmail || log.performedBy || `User #${log.userId}`}</span>
              </div>
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{log.timestamp ? new Date(log.timestamp).toLocaleString() : '—'}</span>
            </div>
          ))
        }
        {!loading && logs.length === 0 && <p style={{ padding: 20, color: 'var(--text-muted)', textAlign: 'center' }}>No audit logs yet.</p>}
      </Card>
    </DashboardLayout>
  );
}
