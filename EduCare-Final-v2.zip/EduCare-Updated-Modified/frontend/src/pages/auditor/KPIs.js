import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Toast from '../../components/common/Toast';
import { reportAPI } from '../../services/api';
import { generateKpiPDF } from '../../utils/pdfGenerator';

export default function AuditorKPIs() {
  const [kpis, setKpis] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createModal, setCreateModal] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ name: '', definition: '', target: '', currentValue: '', reportingPeriod: '' });
  const [newValue, setNewValue] = useState('');
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await reportAPI.getKpis();
        if (!cancelled) setKpis(r.data || []);
      } catch (err) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function loadKpis() {
    try {
      const r = await reportAPI.getKpis();
      setKpis(r.data || []);
    } catch (err) { /* ignore */ }
  }

  async function create(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await reportAPI.createKpi({
        name: form.name,
        definition: form.definition,
        target: Number(form.target),
        currentValue: Number(form.currentValue),
        reportingPeriod: form.reportingPeriod,
      });
      setToast({ message: 'KPI created successfully!', type: 'success' });
      setCreateModal(false);
      setForm({ name: '', definition: '', target: '', currentValue: '', reportingPeriod: '' });
      await loadKpis();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error creating KPI', type: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function update(e) {
    e.preventDefault();
    if (!newValue || isNaN(Number(newValue))) {
      setToast({ message: 'Please enter a valid number', type: 'error' });
      return;
    }
    setSaving(true);
    try {
      await reportAPI.updateKpiValue(selected.id, Number(newValue));
      setToast({ message: 'KPI value updated to ' + newValue + '%!', type: 'success' });
      setUpdateModal(false);
      await loadKpis();
    } catch (err) {
      const msg = err.response?.data?.message || err.message || 'Error updating KPI';
      setToast({ message: msg, type: 'error' });
    } finally {
      setSaving(false);
    }
  }

  function openUpdate(kpi) {
    setSelected(kpi);
    setNewValue(String(kpi.currentValue));
    setUpdateModal(true);
  }

  function downloadPDF() {
    generateKpiPDF(kpis);
    setToast({ message: 'Opening KPI PDF...', type: 'info' });
  }

  const columns = [
    { title: 'KPI Name', key: 'name', render: v => <span style={{ fontWeight: 700 }}>{v}</span> },
    { title: 'Definition', key: 'definition', render: v => <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v}</span> },
    { title: 'Target', key: 'target', render: v => <span style={{ fontWeight: 600 }}>{v}%</span> },
    { title: 'Current', key: 'currentValue', render: (v, r) => (
      <div>
        <span style={{ fontSize: 20, fontWeight: 800, color: v >= r.target ? 'var(--success)' : 'var(--danger)' }}>{v}%</span>
        <div style={{ background: '#e2e8f0', height: 5, borderRadius: 3, marginTop: 4, width: 80 }}>
          <div style={{ background: v >= r.target ? 'var(--success)' : 'var(--primary)', height: '100%', borderRadius: 3, width: Math.min((v / r.target) * 100, 100) + '%' }} />
        </div>
      </div>
    )},
    { title: 'Period', key: 'reportingPeriod' },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <Button size="sm" variant="ghost" onClick={() => openUpdate(r)}>
        Update Value
      </Button>
    )},
  ];

  return (
    <DashboardLayout title="KPI Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <Card
        title="Key Performance Indicators"
        subtitle={kpis.length + " KPIs tracked"}
        extra={
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="ghost" onClick={downloadPDF}>📄 Export PDF</Button>
            <Button onClick={() => setCreateModal(true)}>+ Create KPI</Button>
          </div>
        }
      >
        <Table columns={columns} data={kpis} loading={loading} emptyText="No KPIs defined yet" />
      </Card>

      {/* Create Modal */}
      <Modal open={createModal} onClose={() => setCreateModal(false)} title="Create New KPI">
        <form onSubmit={create}>
          <Input label="KPI Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} required placeholder="Monthly Attendance Rate" />
          <Input label="Definition" value={form.definition} onChange={e => setForm({...form, definition: e.target.value})} placeholder="Percentage of students present per month" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="Target (%)" type="number" step="0.1" min="0" max="100" value={form.target} onChange={e => setForm({...form, target: e.target.value})} required placeholder="95" />
            <Input label="Current Value (%)" type="number" step="0.1" min="0" max="100" value={form.currentValue} onChange={e => setForm({...form, currentValue: e.target.value})} required placeholder="88.5" />
          </div>
          <Input label="Reporting Period" value={form.reportingPeriod} onChange={e => setForm({...form, reportingPeriod: e.target.value})} placeholder="April 2026" />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }}>
            <Button variant="secondary" onClick={() => setCreateModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create KPI</Button>
          </div>
        </form>
      </Modal>

      {/* Update Modal */}
      <Modal open={updateModal} onClose={() => setUpdateModal(false)} title={"Update: " + (selected?.name || '')} width={400}>
        <div style={{ background: 'var(--surface2)', borderRadius: 8, padding: 16, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Current Value</span>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Target</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 28, fontWeight: 800, color: selected?.currentValue >= selected?.target ? 'var(--success)' : 'var(--danger)' }}>
              {selected?.currentValue}%
            </span>
            <span style={{ fontSize: 20, fontWeight: 600, color: 'var(--text-secondary)' }}>
              {selected?.target}%
            </span>
          </div>
          <div style={{ background: '#e2e8f0', height: 6, borderRadius: 3, marginTop: 8 }}>
            <div style={{ background: selected?.currentValue >= selected?.target ? 'var(--success)' : 'var(--primary)', height: '100%', borderRadius: 3, width: Math.min(((selected?.currentValue || 0) / (selected?.target || 1)) * 100, 100) + '%' }} />
          </div>
        </div>
        <form onSubmit={update}>
          <Input
            label="New Value (%)"
            type="number"
            step="0.1"
            min="0"
            max="100"
            value={newValue}
            onChange={e => setNewValue(e.target.value)}
            required
            placeholder="Enter new percentage value"
            hint="Enter the updated KPI value as a percentage"
          />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }}>
            <Button variant="secondary" onClick={() => setUpdateModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving} variant="success">Update Value</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
