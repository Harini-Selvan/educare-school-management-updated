import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Toast from '../../components/common/Toast';
import { reportAPI } from '../../services/api';
import { generateAuditPackagePDF } from '../../utils/pdfGenerator';

export default function AuditPackages() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ periodStart: '', periodEnd: '', contentsJson: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await reportAPI.getAuditPackages();
        if (!cancelled) setPackages(r.data || []);
      } catch (err) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function create(e) {
    e.preventDefault(); setSaving(true);
    try {
      await reportAPI.createAuditPackage(form);
      setToast({ message: 'Audit package created!', type: 'success' });
      setModal(false);
      const r = await reportAPI.getAuditPackages();
      setPackages(r.data || []);
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  }

  function downloadPDF(pkg) {
    generateAuditPackagePDF(pkg);
    setToast({ message: 'Opening Audit Package PDF...', type: 'info' });
  }

  const columns = [
    { title: 'Period', key: 'periodStart', render: (v, r) => <span style={{ fontWeight: 600 }}>{r.periodStart} → {r.periodEnd}</span> },
    { title: 'Contents', key: 'contentsJson', render: v => <span style={{ fontSize: 12, fontFamily: 'monospace' }}>{v?.substring(0, 35)}...</span> },
    { title: 'Generated At', key: 'generatedAt', render: v => v ? new Date(v).toLocaleString() : '-' },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <Button size="sm" variant="ghost" onClick={() => downloadPDF(r)}>
        📄 Download PDF
      </Button>
    )},
  ];

  return (
    <DashboardLayout title="Audit Packages">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Audit Packages" subtitle={packages.length + " packages"} extra={<Button onClick={() => setModal(true)}>+ Create Package</Button>}>
        <Table columns={columns} data={packages} loading={loading} />
      </Card>
      <Modal open={modal} onClose={() => setModal(false)} title="Create Audit Package">
        <form onSubmit={create}>
          <Input label="Period Start" type="date" value={form.periodStart} onChange={e => setForm({...form, periodStart: e.target.value})} required />
          <Input label="Period End" type="date" value={form.periodEnd} onChange={e => setForm({...form, periodEnd: e.target.value})} required />
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Contents (JSON)</label>
            <textarea value={form.contentsJson} onChange={e => setForm({...form, contentsJson: e.target.value})} rows={3}
              style={{ width: '100%', padding: '9px 13px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 13, resize: 'vertical', fontFamily: 'monospace', boxSizing: 'border-box', outline: 'none', background: '#f8fafc' }}
              placeholder={'{"reports":[1,2,3],"kpis":[1,2],"gradeChanges":[1]}'} />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
