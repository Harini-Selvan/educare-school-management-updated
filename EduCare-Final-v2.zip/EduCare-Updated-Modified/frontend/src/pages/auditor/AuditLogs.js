import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import { authAPI } from '../../services/api';

const METHOD_COLORS = {
  POST: '#059669', PUT: '#0891b2', PATCH: '#d97706', DELETE: '#dc2626', GET: '#475569',
};

export default function AuditorLogs() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterMethod, setFilterMethod] = useState('');

  useEffect(() => {
    authAPI.getAuditLogs()
      .then(r => setLogs(r.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const filtered = logs.filter(l => {
    const matchMethod = !filterMethod || (l.httpMethod || '').toUpperCase() === filterMethod;
    const q = search.toLowerCase();
    const matchSearch = !q
      || (l.userEmail || '').toLowerCase().includes(q)
      || (l.performedBy || '').toLowerCase().includes(q)
      || (l.action || '').toLowerCase().includes(q)
      || (l.details || '').toLowerCase().includes(q);
    return matchMethod && matchSearch;
  });

  const loginCount = logs.filter(l => (l.action || '').toUpperCase().includes('LOGIN')).length;
  const todayCount = logs.filter(l => l.timestamp && new Date(l.timestamp).toDateString() === new Date().toDateString()).length;

  const columns = [
    {
      title: 'Timestamp',
      key: 'timestamp',
      render: v => v ? (
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)' }}>
            {new Date(v).toLocaleDateString()}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            {new Date(v).toLocaleTimeString()}
          </div>
        </div>
      ) : <span style={{ color: 'var(--text-muted)' }}>—</span>,
    },
    {
      title: 'User',
      key: 'userEmail',
      render: (v, r) => (
        <div>
          <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text)' }}>
            {r.performedBy || v || '—'}
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{v || ''}</div>
        </div>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: v => (
        <span style={{
          fontFamily: 'monospace', fontSize: 12, fontWeight: 700,
          color: 'var(--primary)', background: 'var(--primary-light)',
          padding: '3px 8px', borderRadius: 4, wordBreak: 'break-word',
        }}>
          {v || '—'}
        </span>
      ),
    },
    {
      title: 'Endpoint',
      key: 'endpoint',
      render: v => (
        <span style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--text-secondary)' }}>
          {v || '—'}
        </span>
      ),
    },
    {
      title: 'Method',
      key: 'httpMethod',
      render: v => {
        const m = (v || '').toUpperCase();
        const color = METHOD_COLORS[m] || '#475569';
        return m ? (
          <span style={{
            fontFamily: 'monospace', fontSize: 12, fontWeight: 700,
            color, background: color + '18', padding: '3px 8px', borderRadius: 4,
          }}>
            {m}
          </span>
        ) : <span style={{ color: 'var(--text-muted)' }}>—</span>;
      },
    },
    {
      title: 'Details',
      key: 'details',
      render: v => (
        <span style={{ fontSize: 12, color: 'var(--text-muted)', wordBreak: 'break-word' }}>
          {v || '—'}
        </span>
      ),
    },
  ];

  return (
    <DashboardLayout title="Audit Logs">
      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
        {[
          ['Total Entries', logs.length, '#1e40af'],
          ['Login Events', loginCount, '#059669'],
          ['Today', todayCount, '#d97706'],
          ['Filtered', filtered.length, '#7c3aed'],
        ].map(([label, value, color]) => (
          <div key={label} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '16px 20px', borderLeft: `4px solid ${color}` }}>
            <div style={{ fontSize: 26, fontWeight: 800, color }}>{value}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      <Card
        title="System Audit Trail"
        subtitle="All login timings and user actions — Read Only"
        extra={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: 11, background: '#f1f5f9', border: '1px solid var(--border)', borderRadius: 6, padding: '4px 10px', color: 'var(--text-muted)', fontWeight: 600 }}>
              🔒 Read Only
            </span>
            <input
              placeholder="Search user / action..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ padding: '6px 10px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 12, outline: 'none', width: 170, fontFamily: 'Outfit, sans-serif' }}
            />
            <select
              value={filterMethod}
              onChange={e => setFilterMethod(e.target.value)}
              style={{ padding: '6px 10px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 13, background: 'var(--surface)', outline: 'none' }}
            >
              <option value="">All Methods</option>
              {['POST', 'PATCH', 'PUT', 'DELETE', 'GET'].map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        }
      >
        <Table
          columns={columns}
          data={filtered}
          loading={loading}
          emptyText="No audit logs found. Logs are created automatically on login and every user action."
        />
      </Card>
    </DashboardLayout>
  );
}
