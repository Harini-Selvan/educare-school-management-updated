import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { notificationAPI } from '../../services/api';

export default function TeacherNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    notificationAPI.getMy()
      .then(r => setNotifications(r.data || []))
      .finally(() => setLoading(false));
  }, []);

  const markRead = id => {
    notificationAPI.markRead(id)
      .then(() => setNotifications(prev => prev.map(n => n.id === id ? { ...n, status: 'READ' } : n)))
      .catch(() => {});
  };

  const unread = notifications.filter(n => n.status === 'UNREAD').length;
  const examNotifications = notifications.filter(n => n.category === 'EXAM');

  return (
    <DashboardLayout title="Notifications">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, borderTop: '3px solid #0891b2' }}>
          <div style={{ fontSize: 26, fontWeight: 800, color: '#0891b2' }}>{examNotifications.length}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginTop: 2 }}>Exam Notifications</div>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>From Exam Coordinator</p>
        </div>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, borderTop: '3px solid #dc2626' }}>
          <div style={{ fontSize: 26, fontWeight: 800, color: '#dc2626' }}>{unread}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginTop: 2 }}>Unread</div>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>Requires attention</p>
        </div>
      </div>

      <Card title="All Notifications" subtitle={`${notifications.length} total • ${unread} unread`}>
        {loading ? <p style={{ color: 'var(--text-muted)', padding: 20 }}>Loading...</p> :
         notifications.length === 0
          ? <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}><div style={{ fontSize: 32, marginBottom: 8 }}>🔔</div><p>No notifications yet</p><p style={{ fontSize: 12, marginTop: 4 }}>You'll receive notifications when the Exam Coordinator schedules exams for your classes.</p></div>
          : notifications.map(n => (
            <div key={n.id} style={{ padding: 16, borderBottom: '1px solid var(--border)', background: n.status === 'UNREAD' ? 'var(--primary-light)' : 'transparent', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                  <Badge text={n.category} />
                  <Badge text={n.status} />
                  {n.category === 'EXAM' && <span style={{ fontSize: 11, background: '#cffafe', color: '#0e7490', padding: '2px 8px', borderRadius: 12, fontWeight: 700 }}>📅 Exam Alert</span>}
                </div>
                <p style={{ fontSize: 14, fontWeight: n.status === 'UNREAD' ? 600 : 400 }}>{n.message}</p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>{n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</p>
              </div>
              {n.status === 'UNREAD' && <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>Mark Read</Button>}
            </div>
          ))
        }
      </Card>
    </DashboardLayout>
  );
}
