import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Toast from '../../components/common/Toast';
import { notificationAPI, studentAPI, authAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function TeacherMessages() {
  const { user } = useAuth();
  const [inbox, setInbox] = useState([]);
  const [sent, setSent] = useState([]);
  const [students, setStudents] = useState([]);
  const [parentUsers, setParentUsers] = useState([]); // all registered PARENT accounts
  const [tab, setTab] = useState('inbox');
  const [modal, setModal] = useState(false);
  const [composeForm, setComposeForm] = useState({ toEmail: '', toName: '', content: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = async () => {
    notificationAPI.getInbox().then(r => setInbox(r.data || [])).catch(() => {});
    notificationAPI.getSent().then(r => setSent(r.data || [])).catch(() => {});
    studentAPI.getAll().then(r => setStudents(r.data || [])).catch(() => {});
    // Load all parent user accounts to match by email
    try {
      const usersRes = await authAPI.getUsers();
      const parents = (usersRes.data || []).filter(u => u.role === 'PARENT');
      setParentUsers(parents);
    } catch {
      // If teacher can't access all users, try by role
      try {
        const pRes = await authAPI.getUsersByRole('PARENT');
        setParentUsers(pRes.data || []);
      } catch { setParentUsers([]); }
    }
  };
  useEffect(() => { load(); }, []);

  // Find the parent's LOGIN email from their user account
  // A student record stores parentEmail; the parent account email is used to log in.
  // These should match if admin registered parent with same email.
  const getParentAccount = (student) => {
    if (!student.parentEmail) return null;
    // Direct match: parent account email == student's parentEmail
    const direct = parentUsers.find(p => p.email === student.parentEmail);
    if (direct) return direct;
    // No account found for that parentEmail — still use parentEmail as fallback
    // (message delivery will work only if parent logs in with that exact email)
    return { id: null, email: student.parentEmail, name: 'Parent of ' + student.name };
  };

  const openCompose = (toEmail, toName) => {
    setComposeForm({ toEmail: toEmail || '', toName: toName || '', content: '' });
    setModal(true);
  };

  const send = async e => {
    e.preventDefault();
    if (!composeForm.toEmail) return;
    setSaving(true);
    try {
      // Find userId for recipient if available
      const recipient = parentUsers.find(p => p.email === composeForm.toEmail);
      await notificationAPI.sendMessage({
        fromEmail: user?.email,
        toEmail: composeForm.toEmail,
        content: composeForm.content,
        fromUserId: user?.userId || 0,
        toUserId: recipient?.id || 0,
      });
      setToast({ message: `Message sent to ${composeForm.toEmail}!`, type: 'success' });
      setModal(false);
      setComposeForm({ toEmail: '', toName: '', content: '' });
      load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Failed to send message', type: 'error' });
    } finally { setSaving(false); }
  };

  const MessageList = ({ messages, type }) => (
    <div>
      {messages.length === 0
        ? <p style={{ color: 'var(--text-muted)', fontSize: 14, padding: '24px 0', textAlign: 'center' }}>No messages yet</p>
        : messages.map(m => (
          <div key={m.id} style={{ padding: 16, borderBottom: '1px solid var(--border)', display: 'flex', gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--primary-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 700, color: 'var(--primary)', flexShrink: 0 }}>
              {(type === 'inbox' ? m.fromEmail : m.toEmail)?.charAt(0)?.toUpperCase()}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>
                  {type === 'inbox' ? `From: ${m.fromEmail}` : `To: ${m.toEmail}`}
                </span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.sentAt ? new Date(m.sentAt).toLocaleString() : ''}</span>
              </div>
              <p style={{ fontSize: 14, color: 'var(--text)', margin: 0 }}>{m.content}</p>
            </div>
          </div>
        ))}
    </div>
  );

  return (
    <DashboardLayout title="Messages">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Students & Parents contact list */}
      <Card title="Students & Parents" style={{ marginBottom: 16 }}>
        <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 14 }}>
          Click <strong>Message Parent</strong> to send a message that will appear in the parent's inbox.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 10 }}>
          {students.map(s => {
            const parentAcct = getParentAccount(s);
            return (
              <div key={s.id} style={{ padding: '12px 14px', border: '1px solid var(--border)', borderRadius: 8, background: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{s.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                    Parent email: <span style={{ color: parentAcct ? '#059669' : '#dc2626', fontWeight: 500 }}>
                      {parentAcct ? parentAcct.email : 'Not set'}
                    </span>
                  </div>
                </div>
                {parentAcct && (
                  <Button size="sm" variant="ghost" onClick={() => openCompose(parentAcct.email, parentAcct.name)}>
                    Message Parent
                  </Button>
                )}
              </div>
            );
          })}
          {students.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: 13, gridColumn: '1/-1', textAlign: 'center', padding: 16 }}>No students found.</p>}
        </div>
      </Card>

      {/* Inbox / Sent */}
      <Card title="Messages" extra={<Button onClick={() => openCompose('', '')}>+ New Message</Button>}>
        <div style={{ display: 'flex', gap: 0, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
          {['inbox', 'sent'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              padding: '10px 24px', background: 'none', border: 'none',
              borderBottom: tab === t ? '2px solid var(--primary)' : '2px solid transparent',
              color: tab === t ? 'var(--primary)' : 'var(--text-secondary)',
              fontWeight: tab === t ? 700 : 400, fontSize: 14, cursor: 'pointer',
              fontFamily: 'Outfit, sans-serif', textTransform: 'capitalize',
            }}>{t} ({(t === 'inbox' ? inbox : sent).length})</button>
          ))}
        </div>
        <MessageList messages={tab === 'inbox' ? inbox : sent} type={tab} />
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Send Message">
        <form onSubmit={send}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
              To (Email Address)
            </label>
            <input type="email" required value={composeForm.toEmail}
              onChange={e => setComposeForm({ ...composeForm, toEmail: e.target.value })}
              placeholder="parent@email.com"
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, outline: 'none', background: '#f8fafc', boxSizing: 'border-box', fontFamily: 'Outfit, sans-serif' }}
              onFocus={e => e.target.style.borderColor = '#1e40af'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
            <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
              The message will appear in the recipient's inbox.
            </p>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Message</label>
            <textarea value={composeForm.content} onChange={e => setComposeForm({ ...composeForm, content: e.target.value })} required rows={4}
              style={{ width: '100%', padding: '10px 14px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none' }}
              placeholder="Write your message..." />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Send Message</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
