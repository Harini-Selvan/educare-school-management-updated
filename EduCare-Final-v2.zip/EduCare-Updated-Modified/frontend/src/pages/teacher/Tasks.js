import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { notificationAPI } from '../../services/api';

export default function TeacherTasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  const load = () => { setLoading(true); notificationAPI.getMyTasks().then(r => setTasks(r.data || [])).finally(() => setLoading(false)); };
  useEffect(load, []);

  const updateStatus = async (id, status) => {
    try { await notificationAPI.updateTaskStatus(id, status); setToast({ message: 'Task updated!', type: 'success' }); load(); }
    catch { setToast({ message: 'Error updating task', type: 'error' }); }
  };

  const columns = [
    { title: 'Description', key: 'description', render: v => <span style={{ fontWeight: 500 }}>{v}</span> },
    { title: 'Due Date', key: 'dueDate', render: (v) => {
      const overdue = new Date(v) < new Date() ? 'var(--danger)' : 'var(--text)';
      return <span style={{ color: overdue, fontWeight: 600 }}>{v}</span>;
    }},
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <div style={{ display: 'flex', gap: 6 }}>
        {r.status === 'PENDING' && <Button size="sm" variant="ghost" onClick={() => updateStatus(r.id, 'IN_PROGRESS')}>Start</Button>}
        {r.status === 'IN_PROGRESS' && <Button size="sm" variant="success" onClick={() => updateStatus(r.id, 'COMPLETED')}>Complete</Button>}
        {r.status === 'COMPLETED' && <span style={{ color: 'var(--success)', fontSize: 13, fontWeight: 600 }}>✓ Done</span>}
      </div>
    )},
  ];

  return (
    <DashboardLayout title="My Tasks">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Assigned Tasks" subtitle={`${tasks.length} total tasks`}>
        <Table columns={columns} data={tasks} loading={loading} emptyText="No tasks assigned to you" />
      </Card>
    </DashboardLayout>
  );
}
