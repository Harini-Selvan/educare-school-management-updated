import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import { examAPI, studentAPI } from '../../services/api';

export default function TeacherGradeRequests() {
  const [requests, setRequests] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [r, s] = await Promise.all([examAPI.getMyRequests(), studentAPI.getAll()]);
        if (!cancelled) {
          setRequests(r.data || []);
          setStudents(s.data || []);
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const getStudentName = (id) => students.find(s => Number(s.id) === Number(id))?.name || `Student #${id}`;

  const statusColors = { PENDING: '#d97706', APPROVED: '#059669', REJECTED: '#dc2626' };

  const columns = [
    { title: 'Grade ID', key: 'gradeId', render: v => <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--primary)' }}>#{v}</span> },
    { title: 'Student Name', key: 'studentId', render: v => <span style={{ fontWeight: 600 }}>{getStudentName(v)}</span> },
    { title: 'Current Marks', key: 'currentValue', render: v => <span style={{ fontWeight: 700 }}>{v ?? '—'}</span> },
    { title: 'Requested Marks', key: 'requestedValue', render: v => <span style={{ fontWeight: 700, color: '#1e40af' }}>{v}</span> },
    { title: 'Reason', key: 'reason', render: v => <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{v?.substring(0, 60)}{v?.length > 60 ? '...' : ''}</span> },
    { title: 'Status', key: 'status', render: v => (
      <span style={{ fontWeight: 700, fontSize: 12, color: statusColors[v] || '#475569', background: (statusColors[v] || '#475569') + '15', padding: '3px 10px', borderRadius: 20 }}>{v}</span>
    )},
    { title: 'Submitted', key: 'requestedAt', render: v => v ? new Date(v).toLocaleDateString() : '—' },
  ];

  const pending = requests.filter(r => r.status === 'PENDING').length;
  const approved = requests.filter(r => r.status === 'APPROVED').length;

  return (
    <DashboardLayout title="My Grade Change Requests">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
        {[['Total Requests', requests.length, '#1e40af'], ['Pending', pending, '#d97706'], ['Approved', approved, '#059669']].map(([l, v, c]) => (
          <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, borderLeft: `4px solid ${c}` }}>
            <div style={{ fontSize: 26, fontWeight: 800, color: c }}>{v}</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{l}</div>
          </div>
        ))}
      </div>
      <Card title="Grade Change Requests" subtitle="Requests you submitted — updated by Exam Coordinator">
        <Table columns={columns} data={requests} loading={loading} emptyText="No grade change requests submitted yet." />
      </Card>
    </DashboardLayout>
  );
}
