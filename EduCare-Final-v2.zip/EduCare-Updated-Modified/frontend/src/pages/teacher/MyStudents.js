import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import { studentAPI, classAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function TeacherMyStudents() {
  const { user } = useAuth();
  const [students, setStudents] = useState([]);
  const [className, setClassName] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [viewModal, setViewModal] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        // Step 1: find teacher profile by userId
        const teachersRes = await classAPI.getTeachers();
        const allTeachers = teachersRes.data || [];
        const myProfile = allTeachers.find(t =>
          String(t.userId) === String(user?.userId) || t.name === user?.name
        );

        if (!myProfile) {
          // fallback: show all students
          const r = await studentAPI.getAll();
          if (!cancelled) { setStudents(r.data || []); setClassName('All Students'); }
          return;
        }

        // Step 2: get this teacher's assigned classes
        const assignRes = await classAPI.getAssignmentsByTeacher(myProfile.id);
        const assignments = (assignRes.data || []).filter(a => a.status === 'ACTIVE');
        if (assignments.length === 0) {
          if (!cancelled) setLoading(false);
          return;
        }

        // Step 3: get class names
        const allClassesRes = await classAPI.getAll();
        const allClasses = allClassesRes.data || [];
        const assignedClassIds = assignments.map(a => String(a.classId));
        const myClasses = allClasses.filter(c => assignedClassIds.includes(String(c.id)));
        if (!cancelled) setClassName(myClasses.map(c => c.name).join(', '));

        // Step 4: get enrollments for each class and collect unique studentIds
        const allStudentIds = new Set();
        for (const classId of assignedClassIds) {
          try {
            const enrollRes = await studentAPI.getEnrollmentsByClass(classId);
            (enrollRes.data || [])
              .filter(e => e.status === 'ACTIVE')
              .forEach(e => allStudentIds.add(String(e.studentId)));
          } catch {}
        }

        // Step 5: get all students and filter
        const allStudentsRes = await studentAPI.getAll();
        const myStudents = (allStudentsRes.data || [])
          .filter(s => allStudentIds.has(String(s.id)));

        if (!cancelled) setStudents(myStudents);
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  const columns = [
    { title: 'Student', key: 'name', render: (v, r) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: '50%', background: '#fff7ed', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#c2410c' }}>{v?.charAt(0)}</div>
        <div>
          <div style={{ fontWeight: 600 }}>{v}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>ID: {r.id}</div>
        </div>
      </div>
    )},
    { title: 'Program/Grade', key: 'program' },
    { title: 'Gender', key: 'gender' },
    { title: 'Contact', key: 'contactInfo' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <Button variant="ghost" size="sm" onClick={() => { setSelected(r); setViewModal(true); }}>View</Button>
    )},
  ];

  return (
    <DashboardLayout title="My Students">
      <Card title={`Students${className ? ' — ' + className : ''}`} subtitle={`${students.length} enrolled students`}>
        <Table columns={columns} data={students} loading={loading}
          emptyText={loading ? "Loading..." : "No students enrolled in your class yet."} />
      </Card>

      {selected && (
        <Modal open={viewModal} onClose={() => setViewModal(false)} title="Student Details">
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, background: '#fff7ed', borderRadius: 10, marginBottom: 14 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#fed7aa', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 800, color: '#c2410c' }}>{selected.name?.charAt(0)}</div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700 }}>{selected.name}</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{selected.program}</div>
            </div>
          </div>
          {[['Student ID', selected.id], ['Date of Birth', selected.dob || '—'], ['Gender', selected.gender || '—'], ['Contact', selected.contactInfo || '—'], ['Parent Email', selected.parentEmail || '—'], ['Status', selected.status]].map(([l, v]) => (
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{l}</span>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{v}</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
            <Button variant="secondary" onClick={() => setViewModal(false)}>Close</Button>
          </div>
        </Modal>
      )}
    </DashboardLayout>
  );
}
