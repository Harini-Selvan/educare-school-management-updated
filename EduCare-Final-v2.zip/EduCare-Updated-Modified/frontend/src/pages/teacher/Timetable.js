import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import { classAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const PERIODS = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00'];

const DAY_COLORS = { Monday: '#eff6ff', Tuesday: '#f0fdf4', Wednesday: '#fffbeb', Thursday: '#fdf4ff', Friday: '#fff1f2' };
const DAY_TEXT   = { Monday: '#1e40af', Tuesday: '#065f46', Wednesday: '#92400e', Thursday: '#6b21a8', Friday: '#9f1239' };

export default function TeacherTimetable() {
  const { user } = useAuth();
  const [myClasses, setMyClasses] = useState([]);   // classes this teacher is assigned to
  const [schedules, setSchedules] = useState([]);   // parsed schedule entries
  const [loading, setLoading] = useState(true);
  const [teacherName, setTeacherName] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        // Step 1: Find this teacher's profile (match by userId from login)
        const teachersRes = await classAPI.getTeachers();
        const allTeachers = teachersRes.data || [];

        // Match teacher profile by userId stored in teacher record
        // userId in teacher profile == the user's auth account id
        const myProfile = allTeachers.find(t =>
          String(t.userId) === String(user?.userId) ||
          t.name === user?.name
        );

        if (!myProfile) {
          if (!cancelled) setLoading(false);
          return;
        }
        if (!cancelled) setTeacherName(myProfile.name);

        // Step 2: Get all class assignments for this teacher
        const assignRes = await classAPI.getAssignmentsByTeacher(myProfile.id);
        const assignments = (assignRes.data || []).filter(a => a.status === 'ACTIVE');

        if (assignments.length === 0) {
          if (!cancelled) setLoading(false);
          return;
        }

        // Step 3: Load class details for each assigned class
        const allClassesRes = await classAPI.getAll();
        const allClasses = allClassesRes.data || [];
        const assignedClassIds = new Set(assignments.map(a => String(a.classId)));
        const teacherClasses = allClasses.filter(c => assignedClassIds.has(String(c.id)));

        if (!cancelled) setMyClasses(teacherClasses);

        // Step 4: Parse timetable entries — only show slots assigned to this teacher
        const allEntries = [];
        for (const cls of teacherClasses) {
          try {
            const sched = cls.scheduleJson ? JSON.parse(cls.scheduleJson) : {};
            Object.entries(sched).forEach(([key, v]) => {
              if (!v.subject) return;
              const [day, time] = key.split('_');
              // Show ALL periods for this teacher's class (admin set the subject/teacher for each slot)
              // Filter: only show slots where teacher field matches this teacher's name OR show all
              const isLunch = time === '12:00';
              allEntries.push({
                day, time, subject: v.subject,
                teacher: v.teacher,
                className: cls.name,
                classId: cls.id,
                isLunch,
              });
            });
          } catch {}
        }
        if (!cancelled) setSchedules(allEntries);
      } catch (err) {
        console.error('Timetable load error:', err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  const getCell = (day, time) => schedules.find(s => s.day === day && s.time === time);
  const isLunchSlot = (time) => time === '12:00';

  if (loading) {
    return (
      <DashboardLayout title="My Timetable">
        <Card title="Loading...">
          <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
            Loading your timetable...
          </div>
        </Card>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="My Timetable">
      {myClasses.length === 0 ? (
        <Card title="My Timetable">
          <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📅</div>
            <p style={{ fontSize: 15, fontWeight: 600 }}>No classes assigned yet</p>
            <p style={{ fontSize: 13, marginTop: 6 }}>Ask admin to assign you to a class with a timetable.</p>
          </div>
        </Card>
      ) : (
        <>
          {/* Header info */}
          <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 20px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 800, color: '#166534' }}>
              {teacherName?.charAt(0)}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{teacherName || user?.name}</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                Assigned to: {myClasses.map(c => c.name).join(', ')}
              </div>
            </div>
          </div>

          {/* Timetable grid */}
          <Card title="Weekly Schedule" subtitle="Your assigned periods only">
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr>
                    <th style={{ padding: '10px 14px', background: '#f8fafc', border: '1px solid var(--border)', fontWeight: 700, color: 'var(--text-muted)', width: 80, textAlign: 'center' }}>
                      Time
                    </th>
                    {DAYS.map(d => (
                      <th key={d} style={{ padding: '10px 14px', background: DAY_COLORS[d], border: '1px solid var(--border)', fontWeight: 700, color: DAY_TEXT[d], textAlign: 'center' }}>
                        {d}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {PERIODS.map(time => (
                    <tr key={time}>
                      <td style={{ padding: '8px 12px', border: '1px solid var(--border)', fontWeight: 700, textAlign: 'center', background: isLunchSlot(time) ? '#fef3c7' : '#f8fafc', color: isLunchSlot(time) ? '#92400e' : 'var(--text-muted)', fontSize: 11 }}>
                        {time}{isLunchSlot(time) ? ' 🍽️' : ''}
                      </td>
                      {DAYS.map(day => {
                        if (isLunchSlot(time)) {
                          return (
                            <td key={day} style={{ padding: 8, border: '1px solid var(--border)', background: '#fef3c7', textAlign: 'center' }}>
                              <span style={{ fontSize: 12, fontWeight: 600, color: '#92400e' }}>Lunch Break</span>
                            </td>
                          );
                        }
                        const cell = getCell(day, time);
                        return (
                          <td key={day} style={{ padding: 8, border: '1px solid var(--border)', background: cell ? DAY_COLORS[day] : '#fff', minHeight: 56, verticalAlign: 'top' }}>
                            {cell ? (
                              <div>
                                <div style={{ fontWeight: 700, color: DAY_TEXT[day], fontSize: 13 }}>{cell.subject}</div>
                                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>🏫 {cell.className}</div>
                                {cell.teacher && (
                                  <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>👤 {cell.teacher}</div>
                                )}
                              </div>
                            ) : (
                              <span style={{ color: '#e2e8f0', fontSize: 11 }}>—</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </DashboardLayout>
  );
}
