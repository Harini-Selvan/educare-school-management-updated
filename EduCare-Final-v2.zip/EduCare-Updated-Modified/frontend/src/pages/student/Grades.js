import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import { examAPI, studentAPI } from '../../services/api';

export default function StudentGrades() {
  const [grades, setGrades] = useState([]);
  const [studentName, setStudentName] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const p = await studentAPI.getMyProfile();
        if (cancelled) return;
        setStudentName(p.data?.name || '');
        const g = await examAPI.getGradesByStudent(p.data.id);
        if (!cancelled) setGrades(g.data || []);
      } catch (err) {
        if (!cancelled) setError('Could not load grades.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const avg = grades.length ? (grades.reduce((s, g) => s + g.gradeValue, 0) / grades.length).toFixed(1) : null;
  const passed = grades.filter(g => g.gradeValue >= 40).length;

  const columns = [
    { title: 'Student Name', key: 'studentId', render: () => <span style={{ fontWeight: 600 }}>{studentName}</span> },
    { title: 'Exam Name', key: 'examName', render: (v, r) => <span style={{ fontWeight: 500 }}>{v || r.subject || `Exam #${r.examId}`}</span> },
    { title: 'Grade', key: 'gradeValue', render: v => (
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 22, fontWeight: 800, color: v >= 40 ? 'var(--success)' : 'var(--danger)' }}>{v}</span>
        {v >= 40 ? '✅' : '❌'}
      </div>
    )},
    { title: 'Date', key: 'submittedAt', render: v => v ? new Date(v).toLocaleDateString() : '-' },
    { title: 'Remarks', key: 'remarks' },
  ];

  return (
    <DashboardLayout title="My Grades">
      {error && <div style={{ background: '#fee2e2', borderRadius: 8, padding: 12, color: '#991b1b', marginBottom: 16, fontSize: 13 }}>{error}</div>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
        {[['Total Exams', grades.length, '#1e40af'], ['Passed', passed, '#059669'], ['Average', avg || 'N/A', avg >= 40 ? '#059669' : '#dc2626']].map(([l, v, c]) => (
          <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, textAlign: 'center', boxShadow: 'var(--shadow)' }}>
            <div style={{ fontSize: 32, fontWeight: 800, color: c }}>{v}</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{l}</div>
          </div>
        ))}
      </div>
      <Card title="All Grades">
        <Table columns={columns} data={grades} loading={loading} emptyText="No grades available yet" />
      </Card>
    </DashboardLayout>
  );
}
