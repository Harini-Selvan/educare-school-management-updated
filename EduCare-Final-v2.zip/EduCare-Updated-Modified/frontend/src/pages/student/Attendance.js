import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import { attendanceAPI, studentAPI, classAPI } from '../../services/api';

export default function StudentAttendance() {
  const [records, setRecords] = useState([]);
  const [summary, setSummary] = useState(null);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const p = await studentAPI.getMyProfile();
        if (cancelled) return;
        const [r, s, cRes] = await Promise.all([
          attendanceAPI.getByStudent(p.data.id),
          attendanceAPI.getSummary(p.data.id),
          classAPI.getAll(),
        ]);
        if (!cancelled) {
          setRecords(r.data || []);
          setSummary(s.data);
          setClasses(cRes.data || []);
        }
      } catch (err) {
        if (!cancelled) setError('Could not load attendance.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const getClassName = (classId) => {
    const cls = classes.find(c => String(c.id) === String(classId));
    return cls?.name || `Class ${classId}`;
  };

  const columns = [
    { title: 'Class', key: 'classId', render: v => <span style={{ fontWeight: 500 }}>{getClassName(v)}</span> },
    { title: 'Date', key: 'date', render: v => v ? new Date(v).toLocaleDateString() : '—' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Recorded By', key: 'recordedBy' },
    { title: 'Remarks', key: 'remarks', render: v => v || '—' },
  ];

  return (
    <DashboardLayout title="My Attendance">
      {error && <div style={{ background: '#fee2e2', borderRadius: 8, padding: 12, color: '#991b1b', marginBottom: 16, fontSize: 13 }}>{error}</div>}
      {summary && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, marginBottom: 20 }}>
          {[
            ['Total Days', summary.totalDays, '#1e40af'],
            ['Present', summary.presentDays, '#059669'],
            ['Absent', summary.absentDays, '#dc2626'],
            ['Late', summary.lateDays, '#d97706'],
            ['Attendance %', summary.attendancePercentage + '%', summary.attendancePercentage >= 75 ? '#059669' : '#dc2626'],
          ].map(([l, v, c]) => (
            <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 16, textAlign: 'center', boxShadow: 'var(--shadow)' }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: c }}>{v}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>
      )}
      <Card title="Attendance Records" subtitle={`${records.length} records`}>
        <Table columns={columns} data={records} loading={loading} emptyText="No attendance records yet" />
      </Card>
    </DashboardLayout>
  );
}
