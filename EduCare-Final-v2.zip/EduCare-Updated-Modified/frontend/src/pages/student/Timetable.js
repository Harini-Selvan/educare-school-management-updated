import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import { classAPI, studentAPI } from '../../services/api';

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
const PERIODS = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00'];
const DAY_COLORS = { Monday: '#eff6ff', Tuesday: '#f0fdf4', Wednesday: '#fffbeb', Thursday: '#fdf4ff', Friday: '#fff1f2' };
const DAY_TEXT   = { Monday: '#1e40af', Tuesday: '#065f46', Wednesday: '#92400e', Thursday: '#6b21a8', Friday: '#9f1239' };

export default function StudentTimetable() {
  const [timetable, setTimetable] = useState({});
  const [className, setClassName] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        // Step 1: get student profile to get studentId
        const profileRes = await studentAPI.getMyProfile();
        const studentId = profileRes.data?.id;
        if (!studentId || cancelled) return;

        // Step 2: get student's enrollment to find classId
        const enrollRes = await studentAPI.getEnrollmentsByStudent(studentId);
        const activeEnrollment = (enrollRes.data || []).find(e => e.status === 'ACTIVE');

        if (!activeEnrollment) {
          if (!cancelled) setLoading(false);
          return;
        }

        // Step 3: get class details and parse scheduleJson
        const classRes = await classAPI.getById(activeEnrollment.classId);
        const classData = classRes.data;
        if (!cancelled) {
          setClassName(classData.name);
          try { setTimetable(JSON.parse(classData.scheduleJson || '{}')); } catch { setTimetable({}); }
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const getCell = (day, time) => timetable[`${day}_${time}`];
  const isLunch = time => time === '12:00';

  return (
    <DashboardLayout title="My Timetable">
      <Card title={`Weekly Schedule${className ? ' — ' + className : ''}`} subtitle="Your class timetable">
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading timetable...</div>
        ) : Object.keys(timetable).length === 0 ? (
          <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>📅</div>
            <p style={{ fontWeight: 600 }}>No timetable set up yet</p>
            <p style={{ fontSize: 13, marginTop: 6 }}>Ask your admin to set up the class timetable.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr>
                  <th style={{ padding: '10px 14px', background: '#f8fafc', border: '1px solid var(--border)', fontWeight: 700, color: 'var(--text-muted)', width: 80, textAlign: 'center' }}>Time</th>
                  {DAYS.map(d => <th key={d} style={{ padding: '10px 14px', background: DAY_COLORS[d], border: '1px solid var(--border)', fontWeight: 700, color: DAY_TEXT[d], textAlign: 'center' }}>{d}</th>)}
                </tr>
              </thead>
              <tbody>
                {PERIODS.map(time => (
                  <tr key={time}>
                    <td style={{ padding: '8px 12px', border: '1px solid var(--border)', fontWeight: 700, textAlign: 'center', background: isLunch(time) ? '#fef3c7' : '#f8fafc', color: isLunch(time) ? '#92400e' : 'var(--text-muted)', fontSize: 11 }}>
                      {time}{isLunch(time) ? ' 🍽️' : ''}
                    </td>
                    {DAYS.map(day => {
                      if (isLunch(time)) return (
                        <td key={day} style={{ padding: 8, border: '1px solid var(--border)', background: '#fef3c7', textAlign: 'center' }}>
                          <span style={{ fontSize: 12, fontWeight: 600, color: '#92400e' }}>Lunch Break</span>
                        </td>
                      );
                      const cell = getCell(day, time);
                      return (
                        <td key={day} style={{ padding: 10, border: '1px solid var(--border)', background: cell?.subject ? DAY_COLORS[day] : '#fff', minHeight: 56, verticalAlign: 'top' }}>
                          {cell?.subject ? (
                            <div>
                              <div style={{ fontWeight: 700, color: DAY_TEXT[day], fontSize: 13 }}>{cell.subject}</div>
                              {cell.teacher && <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>👤 {cell.teacher}</div>}
                            </div>
                          ) : <span style={{ color: '#e2e8f0', fontSize: 11 }}>—</span>}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
