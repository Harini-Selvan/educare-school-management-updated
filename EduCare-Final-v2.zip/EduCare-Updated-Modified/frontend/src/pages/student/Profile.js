import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import { studentAPI } from '../../services/api';

export default function StudentProfile() {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    studentAPI.getMyProfile()
      .then(r => { if (!cancelled) setProfile(r.data); })
      .catch(() => { if (!cancelled) setError('Could not load profile. Ask admin to register your student link.'); });
    return () => { cancelled = true; };
  }, []);

  if (error) return (
    <DashboardLayout title="My Profile">
      <div style={{ background: '#fee2e2', border: '1px solid #fecaca', borderRadius: 10, padding: 24, color: '#991b1b' }}>
        <strong>⚠️ {error}</strong>
      </div>
    </DashboardLayout>
  );

  if (!profile) return (
    <DashboardLayout title="My Profile">
      <p style={{ color: 'var(--text-muted)', padding: 20 }}>Loading...</p>
    </DashboardLayout>
  );

  return (
    <DashboardLayout title="My Profile">
      <div style={{ maxWidth: 520, margin: '0 auto' }}>
        <Card title="Personal Information">
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: '#fff7ed', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, fontWeight: 800, color: '#c2410c', margin: '0 auto 12px' }}>
              {profile.name?.charAt(0)}
            </div>
            <h2 style={{ fontSize: 22, fontWeight: 800, margin: '0 0 6px' }}>{profile.name}</h2>
            <Badge text={profile.status} />
          </div>
          {[
            ['Student ID', profile.id],
            ['Program', profile.program],
            ['Date of Birth', profile.dob],
            ['Gender', profile.gender],
            ['Contact', profile.contactInfo],
          ].map(([l, v]) => (
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{l}</span>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{v || '-'}</span>
            </div>
          ))}
        </Card>
      </div>
    </DashboardLayout>
  );
}
