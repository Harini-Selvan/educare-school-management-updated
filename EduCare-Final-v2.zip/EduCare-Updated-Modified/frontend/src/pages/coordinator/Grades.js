import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { examAPI, classAPI } from '../../services/api';

export default function CoordinatorGrades() {
  const { user } = useAuth();
  const [classes, setClasses] = useState([]);
  const [exams, setExams] = useState([]);
  const [grades, setGrades] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await classAPI.getAll();
        if (!cancelled) setClasses(r.data?.filter(c => c.status === 'ACTIVE') || []);
      } catch (err) { /* ignore */ }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  function loadExams(id) { setSelectedClass(id); if (id) examAPI.getByClass(id).then(r => setExams(r.data || [])).catch(() => {}); }
  function loadGrades(id) { setSelectedExam(id); if (id) examAPI.getGradesByExam(id).then(r => setGrades(r.data || [])).catch(() => {}); }

  // Coordinators approve grade changes raised by teachers only

  const columns = [
    { title: 'Student ID', key: 'studentId' },
    { title: 'Grade', key: 'gradeValue', render: v => <span style={{ fontSize: 20, fontWeight: 800, color: v >= 40 ? 'var(--success)' : 'var(--danger)' }}>{v}</span> },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Remarks', key: 'remarks' },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <div style={{ display: 'flex', gap: 4 }}>
        {r.status === 'MODERATED' && (
          <Button size="sm" variant="success" onClick={() =>
            examAPI.approveGradeChange(r.id)
              .then(() => {
                setToast({ message: 'Grade change approved!', type: 'success' });
                loadGrades(selectedExam);
              })
              .catch(() => setToast({ message: 'Error approving grade change', type: 'error' }))
          }>Approve</Button>
        )}
      </div>
    )},
  ];

  return (
    <DashboardLayout title="Grade Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Grades">
        <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1 }}><Select value={selectedClass} onChange={e => loadExams(e.target.value)} options={classes.map(c => ({value: c.id, label: c.name}))} style={{ marginBottom: 0 }} /></div>
          <div style={{ flex: 1 }}><Select value={selectedExam} onChange={e => loadGrades(e.target.value)} options={exams.map(e => ({value: e.id, label: e.subject}))} style={{ marginBottom: 0 }} /></div>
        </div>
        <Table columns={columns} data={grades} emptyText="Select class and exam to view grades" />
      </Card>
    </DashboardLayout>
  );
}
