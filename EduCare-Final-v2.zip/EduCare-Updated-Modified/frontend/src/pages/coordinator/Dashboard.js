import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import { examAPI, classAPI, notificationAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

function computeStatus(scheduledAt) {
  if (!scheduledAt) return 'SCHEDULED';
  const now = new Date();
  const examDate = new Date(scheduledAt);
  if (now < examDate) return 'SCHEDULED';
  if (now > new Date(examDate.getTime() + 3 * 60 * 60 * 1000)) return 'COMPLETED';
  return 'ONGOING';
}

export default function CoordinatorDashboard() {
  const [exams, setExams] = useState([]);
  const [classes, setClasses] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      examAPI.getAll().catch(() => ({ data: [] })),
      classAPI.getAll().catch(() => ({ data: [] })),
      notificationAPI.getMyTasks().catch(() => ({ data: [] })),
      notificationAPI.getMy().catch(() => ({ data: [] })),
    ]).then(([e, c, t, n]) => {
      setExams(e.data || []);
      setClasses(c.data?.filter(cls => cls.status === 'ACTIVE') || []);
      setTasks(t.data || []);
      setNotifications(n.data || []);
    }).finally(() => setLoading(false));
  }, []);

  const scheduled = exams.filter(e => computeStatus(e.scheduledAt) === 'SCHEDULED').length;
  const ongoing = exams.filter(e => computeStatus(e.scheduledAt) === 'ONGOING').length;
  const pendingTasks = tasks.filter(t => t.status !== 'COMPLETED').length;

  const upcomingExams = exams
    .filter(e => computeStatus(e.scheduledAt) === 'SCHEDULED')
    .sort((a, b) => new Date(a.scheduledAt) - new Date(b.scheduledAt))
    .slice(0, 5);

  return (
    <DashboardLayout title="Exam Coordinator Dashboard">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          ['📅', exams.length, 'Total Exams', '#0891b2', () => navigate('/coordinator/exams')],
          ['⏰', scheduled, 'Scheduled', '#1e40af', () => navigate('/coordinator/exams')],
          ['🟡', ongoing, 'Ongoing Now', '#d97706', () => navigate('/coordinator/exams')],
          ['📋', pendingTasks, 'Pending Tasks', '#dc2626', () => navigate('/coordinator/tasks')],
        ].map(([icon, count, label, color, onClick]) => (
          <div key={label} onClick={onClick} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', cursor: 'pointer', borderTop: `3px solid ${color}`, transition: 'transform 0.12s' }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{icon}</div>
            <div style={{ fontSize: 28, fontWeight: 800, color }}>{count}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>{label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        <Card title="Upcoming Exams" extra={<Button size="sm" onClick={() => navigate('/coordinator/exams')}>View All</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)', padding: 16 }}>Loading...</p> :
           upcomingExams.length === 0 ? (
            <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>📅</div>
              <p>No upcoming exams. <a href="/coordinator/exams" style={{ color: 'var(--primary)' }}>Schedule one</a></p>
            </div>
          ) : upcomingExams.map(exam => (
            <div key={exam.id} style={{ padding: '14px 0', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{exam.subject}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                  {classes.find(c => String(c.id) === String(exam.classId))?.name || `Class #${exam.classId}`}
                  {exam.scheduledAt && ` • ${new Date(exam.scheduledAt).toLocaleString()}`}
                </div>
              </div>
              <span style={{ background: '#eff6ff', color: '#1e40af', padding: '4px 10px', borderRadius: 20, fontSize: 12, fontWeight: 700 }}>SCHEDULED</span>
            </div>
          ))}
        </Card>

        <Card title="Quick Actions">
          {[
            ['📅 Schedule Exam', () => navigate('/coordinator/exams'), '#0891b2'],
            ['📢 Send Notification', () => navigate('/coordinator/notifications'), '#7c3aed'],
            ['📋 My Tasks', () => navigate('/coordinator/tasks'), '#d97706'],
          ].map(([label, onClick, color]) => (
            <button key={label} onClick={onClick}
              style={{ width: '100%', padding: '12px 16px', marginBottom: 8, background: color + '10', border: `1px solid ${color}25`, borderRadius: 8, cursor: 'pointer', textAlign: 'left', fontSize: 14, fontWeight: 600, color, fontFamily: 'Outfit, sans-serif' }}
              onMouseEnter={e => e.currentTarget.style.background = color + '20'}
              onMouseLeave={e => e.currentTarget.style.background = color + '10'}>
              {label}
            </button>
          ))}
        </Card>
      </div>
    </DashboardLayout>
  );
}
