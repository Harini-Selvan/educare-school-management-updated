import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { notificationAPI, classAPI, studentAPI, authAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function CoordinatorNotifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ classId: '', message: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [sendProgress, setSendProgress] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [nRes, cRes] = await Promise.all([notificationAPI.getMy(), classAPI.getAll()]);
        if (!cancelled) {
          setNotifications(nRes.data || []);
          setClasses(cRes.data?.filter(c => c.status === 'ACTIVE') || []);
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function sendClassNotification(e) {
    e.preventDefault();
    setSaving(true);
    setSendProgress('Loading class data...');
    const notifyTargets = [];

    try {
      // 1. Get all enrolled students in this class
      setSendProgress('Finding enrolled students...');
      let enrolledStudentIds = [];
      try {
        const enrollRes = await studentAPI.getEnrollmentsByClass(form.classId);
        enrolledStudentIds = (enrollRes.data || [])
          .filter(e => e.status === 'ACTIVE')
          .map(e => e.studentId);
      } catch {}

      // 2. Get all users (allowed for EXAM_COORDINATOR)
      setSendProgress('Loading user accounts...');
      let allUsers = [];
      try {
        const usersRes = await authAPI.getUsers();
        allUsers = usersRes.data || [];
      } catch {}

      // 3. For each enrolled student: notify student + parent
      setSendProgress(`Preparing notifications for ${enrolledStudentIds.length} students...`);
      for (const studentId of enrolledStudentIds) {
        try {
          const sRes = await studentAPI.getById(studentId);
          const sRecord = sRes.data;
          if (!sRecord) continue;

          // Find student's user account by name match or email match
          const studentUser = allUsers.find(u =>
            u.role === 'STUDENT' && (
              u.name?.toLowerCase() === sRecord.name?.toLowerCase() ||
              u.email === sRecord.contactInfo
            )
          );
          if (studentUser) {
            notifyTargets.push({
              userId: studentUser.id,
              recipientEmail: studentUser.email,
              type: 'STUDENT',
              name: studentUser.name,
            });
          }

          // Find parent's user account by email
          if (sRecord.parentEmail) {
            const parentUser = allUsers.find(u =>
              u.email === sRecord.parentEmail
            );
            if (parentUser) {
              notifyTargets.push({
                userId: parentUser.id,
                recipientEmail: parentUser.email,
                type: 'PARENT',
                name: parentUser.name,
              });
            } else {
              // Parent might not have a user account yet — still add by email
              notifyTargets.push({
                userId: 0,
                recipientEmail: sRecord.parentEmail,
                type: 'PARENT',
                name: 'Parent',
              });
            }
          }
        } catch {}
      }

      // 4. Find teachers assigned to this class
      setSendProgress('Finding assigned teachers...');
      try {
        const assignRes = await classAPI.getAssignmentsByClass(form.classId);
        const assignments = assignRes.data || [];
        // Get all teacher profiles to map teacherId (profile id) -> userId (auth id)
        const teacherProfilesRes = await classAPI.getTeachers();
        const teacherProfiles = teacherProfilesRes.data || [];

        for (const asgn of assignments) {
          // asgn.teacherId = teacher PROFILE id
          // Find teacher profile to get their auth userId
          const teacherProfile = teacherProfiles.find(t => String(t.id) === String(asgn.teacherId));
          if (!teacherProfile) continue;

          // Find auth user by userId stored in teacher profile
          const teacherUser = allUsers.find(u =>
            u.role === 'TEACHER' && String(u.id) === String(teacherProfile.userId)
          );
          if (teacherUser) {
            notifyTargets.push({
              userId: teacherUser.id,
              recipientEmail: teacherUser.email,
              type: 'TEACHER',
              name: teacherUser.name,
            });
          }
        }
      } catch {}

      if (notifyTargets.length === 0) {
        setToast({ message: 'No recipients found. Make sure students are enrolled and users are registered.', type: 'error' });
        setSaving(false);
        setSendProgress('');
        return;
      }

      // 5. Send notification to each target
      const className = classes.find(c => String(c.id) === String(form.classId))?.name || 'class';
      let sentCount = 0;
      let failCount = 0;

      for (const target of notifyTargets) {
        setSendProgress(`Sending to ${target.name || target.recipientEmail}...`);
        try {
          await notificationAPI.create({
            userId: target.userId,
            recipientEmail: target.recipientEmail,
            message: form.message,
            category: 'EXAM',
            entityId: Number(form.classId),
          });
          sentCount++;
        } catch {
          failCount++;
        }
      }

      const studentCount = notifyTargets.filter(t => t.type === 'STUDENT').length;
      const parentCount  = notifyTargets.filter(t => t.type === 'PARENT').length;
      const teacherCount = notifyTargets.filter(t => t.type === 'TEACHER').length;

      setToast({
        message: `✅ Notification sent! Students: ${studentCount}, Parents: ${parentCount}, Teachers: ${teacherCount}. Total: ${sentCount}${failCount > 0 ? ` (${failCount} failed)` : ''}.`,
        type: 'success',
      });
      setModal(false);
      setForm({ classId: '', message: '' });
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error sending notification', type: 'error' });
    } finally {
      setSaving(false);
      setSendProgress('');
    }
  }

  function markRead(id) {
    notificationAPI.markRead(id)
      .then(() => setNotifications(prev => prev.map(n => n.id === id ? { ...n, status: 'READ' } : n)))
      .catch(() => {});
  }

  const unread = notifications.filter(n => n.status === 'UNREAD').length;

  return (
    <DashboardLayout title="Notifications">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <Card title="Send Class Notification" style={{ marginBottom: 16 }}>
        <div style={{ padding: '16px', background: '#f0f9ff', borderRadius: 10, border: '1px solid #bae6fd' }}>
          <p style={{ fontSize: 13, color: '#0369a1', marginBottom: 12, fontWeight: 600 }}>
            📢 Send a notification to all enrolled students, their parents, and assigned teachers in a class.
          </p>
          <Button onClick={() => setModal(true)}>+ Send Class Notification</Button>
        </div>
      </Card>

      <Card title="My Notifications" subtitle={`${unread} unread`}>
        {loading ? (
          <p style={{ color: 'var(--text-muted)', padding: 20 }}>Loading...</p>
        ) : notifications.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🔔</div>
            <p>No notifications yet</p>
          </div>
        ) : (
          notifications.map(n => (
            <div key={n.id} style={{ padding: 16, borderBottom: '1px solid var(--border)', background: n.status === 'UNREAD' ? 'var(--primary-light)' : 'transparent', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                  <Badge text={n.category} />
                  <Badge text={n.status} />
                </div>
                <p style={{ fontSize: 14, fontWeight: n.status === 'UNREAD' ? 600 : 400 }}>{n.message}</p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>{n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</p>
              </div>
              {n.status === 'UNREAD' && (
                <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>Mark Read</Button>
              )}
            </div>
          ))
        )}
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Send Class Notification">
        <form onSubmit={sendClassNotification}>
          <Select
            label="Select Class"
            value={form.classId}
            onChange={e => setForm({ ...form, classId: e.target.value })}
            required
            placeholder="Choose a class..."
            options={classes.map(c => ({ value: c.id, label: c.name }))}
          />
          {form.classId && (
            <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, padding: 12, marginBottom: 14, fontSize: 13, color: '#065f46' }}>
              ✅ Will be sent to: all enrolled students, their linked parents, and assigned teachers.
            </div>
          )}
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
              Message
            </label>
            <textarea
              value={form.message}
              onChange={e => setForm({ ...form, message: e.target.value })}
              required
              rows={4}
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none', background: '#f8fafc' }}
              placeholder="Exam scheduled for next Monday at 9AM..."
            />
          </div>
          {sendProgress && (
            <div style={{ background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 7, padding: '8px 12px', marginBottom: 12, fontSize: 12, color: '#1e40af' }}>
              ⏳ {sendProgress}
            </div>
          )}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Send to Class</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
