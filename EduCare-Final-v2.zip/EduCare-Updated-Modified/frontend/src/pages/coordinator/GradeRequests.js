import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Toast from '../../components/common/Toast';
import { examAPI, studentAPI, classAPI } from '../../services/api';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function CoordinatorGradeRequests() {
  const { user } = useAuth();

  // Opens PDF evidence with JWT token attached
  const openEvidence = async (evidenceUri) => {
    try {
      const response = await api.get(evidenceUri, { responseType: 'blob' });
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(() => window.URL.revokeObjectURL(url), 10000);
    } catch (err) {
      setToast({ message: 'Could not open evidence file. Please try again.', type: 'error' });
    }
  };
  const [requests, setRequests] = useState([]);
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewModal, setReviewModal] = useState(false);
  const [selectedReq, setSelectedReq] = useState(null);
  const [reviewForm, setReviewForm] = useState({ status: 'APPROVED', reviewRemarks: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const [rRes, sRes, cRes] = await Promise.all([
        examAPI.getPendingRequests(),
        studentAPI.getAll(),
        classAPI.getAll(),
      ]);
      const sData = sRes.data || [];
      setRequests(rRes.data || []);
      setStudents(sData);
      setClasses(cRes.data || []);

      // Get enrollments for class lookup
      const allEnrollments = [];
      for (const s of sData.slice(0, 30)) { // limit to first 30 to avoid too many calls
        try {
          const eRes = await studentAPI.getEnrollmentsByStudent(s.id);
          (eRes.data || []).filter(e => e.status === 'ACTIVE').forEach(e => allEnrollments.push(e));
        } catch {}
      }
      setEnrollments(allEnrollments);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const getStudentName = (studentId) => students.find(s => Number(s.id) === Number(studentId))?.name || `Student #${studentId}`;
  
  const getStudentClass = (studentId) => {
    const enrollment = enrollments.find(e => Number(e.studentId) === Number(studentId));
    if (!enrollment) return '—';
    return classes.find(c => String(c.id) === String(enrollment.classId))?.name || `Class #${enrollment.classId}`;
  };

  const openReview = (req) => {
    setSelectedReq(req);
    setReviewForm({ status: 'APPROVED', reviewRemarks: '' });
    setReviewModal(true);
  };

  const submitReview = async () => {
    if (!reviewForm.reviewRemarks.trim()) {
      setToast({ message: 'Please enter review remarks.', type: 'error' });
      return;
    }
    setSaving(true);
    try {
      await examAPI.reviewRequest(selectedReq.id, {
        status: reviewForm.status,
        reviewRemarks: reviewForm.reviewRemarks,
      });
      setToast({ message: `Request ${reviewForm.status.toLowerCase()}!`, type: 'success' });
      setReviewModal(false);
      load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  };

  const statusColors = { PENDING: '#d97706', APPROVED: '#059669', REJECTED: '#dc2626' };

  const columns = [
    { title: 'Student Name', key: 'studentId', render: v => (
      <span style={{ fontWeight: 600 }}>{getStudentName(v)}</span>
    )},
    { title: 'Class', key: 'studentId', render: v => (
      <span style={{ fontSize: 13 }}>{getStudentClass(v)}</span>
    )},
    { title: 'Submitted By', key: 'requestedBy', render: v => (
      <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{v || '—'}</span>
    )},
    { title: 'Current Marks', key: 'currentValue', render: v => (
      <span style={{ fontWeight: 700, fontSize: 15 }}>{v ?? '—'}</span>
    )},
    { title: 'Requested Marks', key: 'requestedValue', render: v => (
      <span style={{ fontWeight: 700, fontSize: 15, color: '#1e40af' }}>{v}</span>
    )},
    { title: 'Evidence', key: 'evidenceUri', render: v => v ? (
      <button onClick={() => openEvidence(v)}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: '#1e40af', fontSize: 13, textDecoration: 'underline', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
        📄 View PDF
      </button>
    ) : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>No file</span> },
    { title: 'Status', key: 'status', render: v => (
      <span style={{ fontWeight: 700, fontSize: 12, color: statusColors[v] || '#475569', background: (statusColors[v] || '#475569') + '15', padding: '3px 10px', borderRadius: 20 }}>
        {v}
      </span>
    )},
    { title: 'Action', key: 'id', render: (v, r) => r.status === 'PENDING' ? (
      <div style={{ display: 'flex', gap: 6 }}>
        <Button size="sm" onClick={() => { openReview(r); setReviewForm({ status: 'APPROVED', reviewRemarks: '' }); }}
          style={{ background: '#059669', color: '#fff', border: 'none' }}>Approve</Button>
        <Button size="sm" variant="danger" onClick={() => { openReview(r); setReviewForm({ status: 'REJECTED', reviewRemarks: '' }); }}>Reject</Button>
      </div>
    ) : <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Reviewed</span> },
  ];

  const pending = requests.filter(r => r.status === 'PENDING').length;

  return (
    <DashboardLayout title="Grade Requests">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          ['Total Requests', requests.length, '#1e40af'],
          ['Pending Review', pending, '#d97706'],
          ['Reviewed', requests.length - pending, '#059669'],
        ].map(([l, v, c]) => (
          <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, borderLeft: `4px solid ${c}` }}>
            <div style={{ fontSize: 26, fontWeight: 800, color: c }}>{v}</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{l}</div>
          </div>
        ))}
      </div>

      <Card title="Grade Change Requests"
        subtitle="Teacher-submitted requests for grade changes. Review evidence and approve or reject."
        extra={<Button variant="ghost" onClick={load}>🔄 Refresh</Button>}
      >
        <Table
          columns={columns}
          data={requests}
          loading={loading}
          emptyText="No grade change requests pending."
        />
      </Card>

      {/* Review Modal */}
      {selectedReq && (
        <Modal open={reviewModal} onClose={() => setReviewModal(false)} title={`Review Grade Request`}>
          <div style={{ background: '#f8fafc', borderRadius: 8, padding: 14, marginBottom: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 13 }}>
              <div><span style={{ color: 'var(--text-muted)' }}>Student:</span> <strong>{getStudentName(selectedReq.studentId)}</strong></div>
              <div><span style={{ color: 'var(--text-muted)' }}>Class:</span> <strong>{getStudentClass(selectedReq.studentId)}</strong></div>
              <div><span style={{ color: 'var(--text-muted)' }}>Current Marks:</span> <strong>{selectedReq.currentValue ?? '—'}</strong></div>
              <div><span style={{ color: 'var(--text-muted)' }}>Requested Marks:</span> <strong style={{ color: '#1e40af' }}>{selectedReq.requestedValue}</strong></div>
              <div style={{ gridColumn: '1/-1' }}><span style={{ color: 'var(--text-muted)' }}>Teacher Reason:</span> <em>{selectedReq.reason}</em></div>
              {selectedReq.evidenceUri && (
                <div style={{ gridColumn: '1/-1' }}>
                  <button onClick={() => openEvidence(selectedReq.evidenceUri)}
                    style={{ color: '#1e40af', textDecoration: 'underline', fontSize: 13, background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>📄 View Evidence PDF</button>
                </div>
              )}
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 8, textTransform: 'uppercase' }}>Decision</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {['APPROVED', 'REJECTED'].map(s => (
                <button key={s} onClick={() => setReviewForm(f => ({...f, status: s}))}
                  style={{ padding: '8px 20px', borderRadius: 6, fontWeight: 700, fontSize: 14, cursor: 'pointer', fontFamily: 'Outfit, sans-serif', border: reviewForm.status === s ? 'none' : '1.5px solid var(--border)',
                    background: reviewForm.status === s ? (s === 'APPROVED' ? '#059669' : '#dc2626') : 'var(--surface)',
                    color: reviewForm.status === s ? '#fff' : 'var(--text-secondary)' }}>
                  {s === 'APPROVED' ? '✅ Approve' : '❌ Reject'}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase' }}>Review Remarks</label>
            <textarea value={reviewForm.reviewRemarks} onChange={e => setReviewForm(f => ({...f, reviewRemarks: e.target.value}))} required rows={3}
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none' }}
              placeholder="Add your review remarks..." />
          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setReviewModal(false)}>Cancel</Button>
            <Button loading={saving} onClick={submitReview}
              style={{ background: reviewForm.status === 'APPROVED' ? '#059669' : '#dc2626', color: '#fff', border: 'none' }}>
              {reviewForm.status === 'APPROVED' ? 'Approve Request' : 'Reject Request'}
            </Button>
          </div>
        </Modal>
      )}
    </DashboardLayout>
  );
}
