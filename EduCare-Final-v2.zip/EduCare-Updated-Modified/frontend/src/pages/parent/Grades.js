import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Select from '../../components/common/Select';
import { examAPI, studentAPI } from '../../services/api';

export default function ParentGrades() {
  const [children, setChildren] = useState([]);
  const [selected, setSelected] = useState('');
  const [selectedName, setSelectedName] = useState('');
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await studentAPI.getMyChildren();
        if (!cancelled) setChildren(r.data || []);
      } catch (err) {}
    }
    load();
    return () => { cancelled = true; };
  }, []);

  function loadGrades(id) {
    const child = children.find(c => String(c.id) === String(id));
    setSelected(id);
    setSelectedName(child?.name || '');
    if (!id) { setGrades([]); return; }
    setLoading(true);
    examAPI.getGradesByStudent(id)
      .then(r => setGrades(r.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }

  const columns = [
    { title: 'Student Name', key: 'studentId', render: () => <span style={{ fontWeight: 600 }}>{selectedName}</span> },
    { title: 'Exam Name', key: 'examName', render: (v, r) => <span style={{ fontWeight: 500 }}>{v || r.subject || `Exam #${r.examId}`}</span> },
    { title: 'Grade', key: 'gradeValue', render: v => <span style={{ fontSize: 20, fontWeight: 800, color: v >= 40 ? 'var(--success)' : 'var(--danger)' }}>{v}</span> },
    { title: 'Date', key: 'submittedAt', render: v => v ? new Date(v).toLocaleDateString() : '-' },
    { title: 'Remarks', key: 'remarks' },
  ];

  return (
    <DashboardLayout title="Child Grades">
      <Card title="Select Child" style={{ marginBottom: 16 }}>
        <Select value={selected} onChange={e => loadGrades(e.target.value)} style={{ marginBottom: 0 }}
          placeholder="Select a child..." options={[ ...children.map(c => ({value: c.id, label: c.name}))]} />
      </Card>
      {selected && <Card title={`Grades — ${selectedName}`}><Table columns={columns} data={grades} loading={loading} /></Card>}
    </DashboardLayout>
  );
}
