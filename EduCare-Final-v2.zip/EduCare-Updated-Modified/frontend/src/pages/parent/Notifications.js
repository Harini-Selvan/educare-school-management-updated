import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { notificationAPI } from '../../services/api';

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await notificationAPI.getMy();
        if (!cancelled) setNotifications(r.data || []);
      } catch (err) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  function markRead(id) {
    notificationAPI.markRead(id)
      .then(() => setNotifications(prev => prev.map(n => n.id === id ? { ...n, status: 'READ' } : n)))
      .catch(() => {});
  }

  const unread = notifications.filter(n => n.status === 'UNREAD').length;

  return (
    <DashboardLayout title="Notifications">
      <Card title="My Notifications" subtitle={unread + " unread"}>
        {loading ? (
          <p style={{ color: 'var(--text-muted)', padding: 20, textAlign: 'center' }}>Loading notifications...</p>
        ) : notifications.length === 0 ? (
          <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🔔</div>
            <p>No notifications yet</p>
          </div>
        ) : (
          notifications.map(n => (
            <div key={n.id} style={{
              padding: 16,
              borderBottom: '1px solid var(--border)',
              background: n.status === 'UNREAD' ? 'var(--primary-light)' : 'transparent',
              display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                  <Badge text={n.category} />
                  <Badge text={n.status} />
                </div>
                <p style={{ fontSize: 14, fontWeight: n.status === 'UNREAD' ? 600 : 400, color: 'var(--text)' }}>
                  {n.message}
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>
                  {n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}
                </p>
              </div>
              {n.status === 'UNREAD' && (
                <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>
                  Mark Read
                </Button>
              )}
            </div>
          ))
        )}
      </Card>
    </DashboardLayout>
  );
}
