import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import { studentAPI, attendanceAPI } from '../../services/api';

export default function ParentChildren() {
  const [children, setChildren] = useState([]);
  const [summaries, setSummaries] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await studentAPI.getMyChildren();
        if (cancelled) return;
        const kids = r.data || [];
        setChildren(kids);
        const sums = {};
        for (const k of kids) {
          try {
            const s = await attendanceAPI.getSummary(k.id);
            if (!cancelled) sums[k.id] = s.data;
          } catch (e) {}
        }
        if (!cancelled) setSummaries(sums);
      } catch (err) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  return (
    <DashboardLayout title="My Children">
      {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
          {children.length === 0 ? (
            <Card title="No Children"><p style={{ color: 'var(--text-muted)', fontSize: 14 }}>No children linked. Contact admin.</p></Card>
          ) : children.map(child => (
            <Card key={child.id} title={child.name}>
              <div style={{ textAlign: 'center', marginBottom: 16 }}>
                <div style={{ width: 72, height: 72, borderRadius: '50%', background: '#fdf4ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 800, color: '#7c3aed', margin: '0 auto 12px' }}>
                  {child.name?.charAt(0)}
                </div>
                <Badge text={child.status} />
              </div>
              {[['Student ID', child.id], ['Program', child.program], ['Gender', child.gender], ['DOB', child.dob]].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{l}</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{v || '-'}</span>
                </div>
              ))}
              {summaries[child.id] && (
                <div style={{ marginTop: 12, background: 'var(--surface2)', borderRadius: 8, padding: 12 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Attendance</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, textAlign: 'center' }}>
                    {[['Present', summaries[child.id].presentDays, '#059669'], ['Absent', summaries[child.id].absentDays, '#dc2626'], ['%', summaries[child.id].attendancePercentage, summaries[child.id].attendancePercentage >= 75 ? '#059669' : '#dc2626']].map(([l, v, c]) => (
                      <div key={l}><div style={{ fontSize: 20, fontWeight: 800, color: c }}>{v}</div><div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{l}</div></div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
