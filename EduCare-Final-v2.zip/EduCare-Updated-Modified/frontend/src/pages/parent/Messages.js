import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Toast from '../../components/common/Toast';
import { notificationAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function ParentMessages() {
  const { user } = useAuth();
  const [inbox, setInbox] = useState([]);
  const [sent, setSent] = useState([]);
  const [tab, setTab] = useState('inbox');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ toEmail: '', content: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = () => {
    notificationAPI.getInbox().then(r => setInbox(r.data || [])).catch(() => {});
    notificationAPI.getSent().then(r => setSent(r.data || [])).catch(() => {});
  };
  useEffect(load, []);

  const send = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await notificationAPI.sendMessage({
        fromEmail: user?.email,
        toEmail: form.toEmail,
        content: form.content,
        fromUserId: user?.userId || 0,
        toUserId: 0,
      });
      setToast({ message: 'Message sent!', type: 'success' });
      setModal(false); setForm({ toEmail: '', content: '' }); load();
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error', type: 'error' }); }
    finally { setSaving(false); }
  };

  const msgs = tab === 'inbox' ? inbox : sent;

  return (
    <DashboardLayout title="Messages">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Messages" extra={<Button onClick={() => setModal(true)}>+ Message Teacher</Button>}>
        <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 16 }}>
          {['inbox', 'sent'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ padding: '10px 24px', background: 'none', border: 'none', borderBottom: tab === t ? '2px solid var(--primary)' : '2px solid transparent', color: tab === t ? 'var(--primary)' : 'var(--text-secondary)', fontWeight: tab === t ? 700 : 400, fontSize: 14, cursor: 'pointer', fontFamily: 'Outfit, sans-serif', textTransform: 'capitalize' }}>
              {t} ({(t === 'inbox' ? inbox : sent).length})
            </button>
          ))}
        </div>
        {msgs.map(m => (
          <div key={m.id} style={{ padding: 16, borderBottom: '1px solid var(--border)', display: 'flex', gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#fdf4ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 700, color: '#7e22ce', flexShrink: 0 }}>
              {(tab === 'inbox' ? m.fromEmail : m.toEmail)?.charAt(0)?.toUpperCase()}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>{tab === 'inbox' ? m.fromEmail : m.toEmail}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.sentAt ? new Date(m.sentAt).toLocaleString() : ''}</span>
              </div>
              <p style={{ fontSize: 14 }}>{m.content}</p>
            </div>
          </div>
        ))}
        {msgs.length === 0 && <p style={{ color: 'var(--text-muted)', padding: 20, textAlign: 'center' }}>No messages</p>}
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Message Teacher">
        <form onSubmit={send}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>To (Mail ID)</label>
            <input type="email" required value={form.toEmail}
              onChange={e => setForm({...form, toEmail: e.target.value})}
              placeholder="teacher@school.edu"
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, outline: 'none', background: '#f8fafc', boxSizing: 'border-box', fontFamily: 'Outfit,sans-serif' }}
              onFocus={e => e.target.style.borderColor = '#7c3aed'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Message</label>
            <textarea value={form.content} onChange={e => setForm({...form, content: e.target.value})} required rows={4}
              style={{ width: '100%', padding: '10px 14px', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none' }}
              placeholder="Write your message to the teacher..." />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Send</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
