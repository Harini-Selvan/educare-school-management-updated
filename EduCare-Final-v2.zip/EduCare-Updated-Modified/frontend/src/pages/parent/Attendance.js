import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Select from '../../components/common/Select';
import { attendanceAPI, studentAPI, classAPI } from '../../services/api';

export default function ParentAttendance() {
  const [children, setChildren] = useState([]);
  const [classes, setClasses] = useState([]);
  const [selected, setSelected] = useState('');
  const [records, setRecords] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [cRes, clsRes] = await Promise.all([studentAPI.getMyChildren(), classAPI.getAll()]);
        if (!cancelled) {
          setChildren(cRes.data || []);
          setClasses(clsRes.data || []);
        }
      } catch {}
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function loadChild(id) {
    setSelected(id);
    setRecords([]); setSummary(null);
    if (!id) return;
    setLoading(true);
    try {
      const [r, s] = await Promise.all([attendanceAPI.getByStudent(id), attendanceAPI.getSummary(id)]);
      setRecords(r.data || []);
      setSummary(s.data);
    } catch {} finally { setLoading(false); }
  }

  const getClassName = (classId) => {
    const cls = classes.find(c => String(c.id) === String(classId));
    return cls?.name || `Class ${classId}`;
  };

  const columns = [
    { title: 'Class', key: 'classId', render: v => <span style={{ fontWeight: 500 }}>{getClassName(v)}</span> },
    { title: 'Date', key: 'date', render: v => v ? new Date(v).toLocaleDateString() : '—' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Remarks', key: 'remarks', render: v => v || '—' },
  ];

  return (
    <DashboardLayout title="Child Attendance">
      <Card title="Select Child" style={{ marginBottom: 16 }}>
        <Select value={selected} onChange={e => loadChild(e.target.value)} style={{ marginBottom: 0 }}
          placeholder="Select a child..."
          options={children.map(c => ({ value: c.id, label: `${c.name} (${c.program || 'N/A'})` }))} />
      </Card>
      {summary && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, marginBottom: 16 }}>
          {[
            ['Total Days', summary.totalDays, '#1e40af'],
            ['Present', summary.presentDays, '#059669'],
            ['Absent', summary.absentDays, '#dc2626'],
            ['Late', summary.lateDays, '#d97706'],
            ['Attendance %', summary.attendancePercentage + '%', summary.attendancePercentage >= 75 ? '#059669' : '#dc2626'],
          ].map(([l, v, c]) => (
            <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 16, textAlign: 'center', boxShadow: 'var(--shadow)' }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: c }}>{v}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>
      )}
      {selected && (
        <Card title="Attendance Records">
          <Table columns={columns} data={records} loading={loading} emptyText="No attendance records yet" />
        </Card>
      )}
    </DashboardLayout>
  );
}
