import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { studentAPI, attendanceAPI, examAPI, classAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

export default function ParentDashboard() {
  const [children, setChildren] = useState([]);
  const [grades, setGrades] = useState([]);
  const [upcomingExams, setUpcomingExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [childClass, setChildClass] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const cRes = await studentAPI.getMyChildren();
        if (cancelled) return;
        const kids = cRes.data || [];
        setChildren(kids);

        if (kids.length > 0) {
          try {
            const g = await examAPI.getGradesByStudent(kids[0].id);
            if (!cancelled) setGrades(g.data || []);
          } catch {}

          let classId = null;
          try {
            const eRes = await studentAPI.getEnrollmentsByStudent(kids[0].id);
            const activeEnrollment = (eRes.data || []).find(e => e.status === 'ACTIVE');
            if (activeEnrollment) {
              classId = activeEnrollment.classId;
              const clsRes = await classAPI.getById(activeEnrollment.classId);
              if (!cancelled) setChildClass(clsRes.data?.name || '');
            }
          } catch {}

          // Load upcoming exams for child's class
          if (classId) {
            try {
              const exRes = await examAPI.getByClass(classId);
              const now = new Date();
              const upcoming = (exRes.data || [])
                .filter(ex => new Date(ex.fromTime || ex.scheduledAt) > now)
                .sort((a, b) => new Date(a.fromTime || a.scheduledAt) - new Date(b.fromTime || b.scheduledAt));
              if (!cancelled) setUpcomingExams(upcoming);
            } catch {}
          }
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const child = children[0];

  return (
    <DashboardLayout title="Parent Portal">
      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #059669' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📝</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#059669' }}>{grades.length}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Grade Records</div>
        </div>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #0891b2' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🎓</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#0891b2' }}>{childClass || child?.program || '—'}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Enrolled Class</div>
        </div>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #f59e0b' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📅</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#f59e0b' }}>{upcomingExams.length}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Upcoming Exams</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Child Info */}
        <Card title="Linked Student">
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           !child ? <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>No student linked. Ask admin to register student link.</p> : (
            <div>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center', padding: '16px', background: '#fdf4ff', borderRadius: 10, marginBottom: 16 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#e9d5ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 800, color: '#7c3aed' }}>
                  {child.name?.charAt(0)}
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700 }}>{child.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{child.program} • ID: {child.id}</div>
                  <Badge text={child.status} />
                </div>
              </div>
              {[['Date of Birth', child.dob || '—'], ['Gender', child.gender || '—'], ['Contact', child.contactInfo || '—']].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{l}</span>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{v}</span>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                <Button size="sm" variant="ghost" onClick={() => navigate('/parent/grades')}>📊 View Grades</Button>
                <Button size="sm" variant="ghost" onClick={() => navigate('/parent/attendance')}>📅 Attendance</Button>
              </div>
            </div>
          )}
        </Card>

        {/* Recent Grades */}
        <Card title="Recent Grades">
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           grades.length === 0 ? (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>📝</div>
              <p>No grades yet</p>
            </div>
          ) : grades.slice(0, 5).map(g => (
            <div key={g.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{g.examName || g.subject || `Exam #${g.examId}`}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{g.submittedAt ? new Date(g.submittedAt).toLocaleDateString() : ''}</div>
              </div>
              <div style={{ fontSize: 20, fontWeight: 800, color: g.gradeValue >= 40 ? 'var(--success)' : 'var(--danger)' }}>{g.gradeValue}</div>
            </div>
          ))}
        </Card>
      </div>

      {/* Upcoming Exams */}
      <Card title="📅 Upcoming Exams for Your Child" subtitle={upcomingExams.length > 0 ? `${upcomingExams.length} exam(s) scheduled` : 'No upcoming exams'}>
        {loading ? (
          <p style={{ color: 'var(--text-muted)', padding: 16 }}>Loading...</p>
        ) : upcomingExams.length === 0 ? (
          <div style={{ padding: '32px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>📋</div>
            <p>No upcoming exams at this time</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 10 }}>
            {upcomingExams.map(ex => {
              const examDate = new Date(ex.fromTime || ex.scheduledAt);
              const daysLeft = Math.ceil((examDate - new Date()) / (1000 * 60 * 60 * 24));
              return (
                <div key={ex.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 16px', background: daysLeft <= 3 ? '#fef3c7' : '#f0fdf4', borderRadius: 10, border: `1px solid ${daysLeft <= 3 ? '#fde68a' : '#bbf7d0'}` }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: '#1e293b' }}>{ex.subject}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>
                      📅 {examDate.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}
                      {' '} ⏰ {examDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      {ex.toTime && ` – ${new Date(ex.toTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>Max Marks: {ex.totalMarks}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span style={{ background: daysLeft <= 3 ? '#f59e0b' : '#059669', color: '#fff', borderRadius: 20, padding: '4px 12px', fontSize: 12, fontWeight: 700 }}>
                      {daysLeft === 0 ? 'Today!' : daysLeft === 1 ? 'Tomorrow!' : `${daysLeft} days`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
