import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const roleRoutes = {
  ADMIN: '/admin', TEACHER: '/teacher', STUDENT: '/student',
  PARENT: '/parent', EXAM_COORDINATOR: '/coordinator', AUDITOR: '/auditor',
};

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await authAPI.login(form);
      const d = res.data;
      login({ token: d.token, role: d.role, name: d.name, email: d.email, userId: d.id });
      navigate(roleRoutes[d.role] || '/');
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid credentials. Please try again.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{
      minHeight: '100vh', background: '#1a6b7c',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: 24, fontFamily: 'Outfit, sans-serif', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', top: -80, right: -80, width: 300, height: 300, borderRadius: '50%', background: 'rgba(255,255,255,0.04)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: -100, left: -60, width: 400, height: 400, borderRadius: '50%', background: 'rgba(255,255,255,0.03)', pointerEvents: 'none' }} />

      <div style={{
        width: '100%', maxWidth: 480, background: '#fff', borderRadius: 12,
        overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.25)', position: 'relative', zIndex: 1,
      }}>
        {/* Yellow Header */}
        <div style={{ background: 'linear-gradient(135deg, #f5c842 0%, #f0b429 100%)', padding: '28px 40px 24px', textAlign: 'center', position: 'relative' }}>
          <div style={{ position: 'absolute', inset: 0, opacity: 0.15, backgroundImage: 'radial-gradient(circle, #7a5900 1px, transparent 1px)', backgroundSize: '20px 20px', pointerEvents: 'none' }} />
          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: 4 }}>
              <div style={{ width: 40, height: 40, background: '#1a6b7c', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, color: '#f5c842', fontWeight: 900 }}>E</div>
              <h1 style={{ fontSize: 26, fontWeight: 900, color: '#2d2200', margin: 0, letterSpacing: '-0.5px' }}>EduCare</h1>
            </div>
            <p style={{ fontSize: 13, color: '#5a3f00', margin: 0, fontWeight: 600 }}>School Management System</p>
          </div>
        </div>

        {/* Form Area */}
        <div style={{ padding: '32px 40px 32px' }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: '#1a1a2e', marginBottom: 4, textAlign: 'center' }}>Welcome Back</h2>
          <p style={{ fontSize: 13, color: '#64748b', textAlign: 'center', marginBottom: 24 }}>Sign in to your account to continue</p>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' }}>Email Address</label>
              <input type="email" required value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="you@school.edu"
                style={{ width: '100%', padding: '11px 14px', border: '1.5px solid #e2e8f0', borderRadius: 6, fontSize: 14, outline: 'none', background: '#f8fafc', boxSizing: 'border-box' }}
                onFocus={e => { e.target.style.borderColor = '#1a6b7c'; e.target.style.background = '#fff'; }}
                onBlur={e => { e.target.style.borderColor = '#e2e8f0'; e.target.style.background = '#f8fafc'; }} />
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' }}>Password</label>
              <div style={{ position: 'relative' }}>
                <input type={showPassword ? 'text' : 'password'} required value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                  style={{ width: '100%', padding: '11px 42px 11px 14px', border: '1.5px solid #e2e8f0', borderRadius: 6, fontSize: 14, outline: 'none', background: '#f8fafc', boxSizing: 'border-box' }}
                  onFocus={e => { e.target.style.borderColor = '#1a6b7c'; e.target.style.background = '#fff'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; e.target.style.background = '#f8fafc'; }} />
                <button type="button" onClick={() => setShowPassword(p => !p)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', fontSize: 15, padding: 0 }}>
                  {showPassword ? '🙈' : '👁'}
                </button>
              </div>
            </div>

            {error && <div style={{ background: '#fee2e2', border: '1px solid #fecaca', color: '#991b1b', padding: '10px 14px', borderRadius: 6, fontSize: 13, marginBottom: 16 }}>{error}</div>}

            <button type="submit" disabled={loading}
              style={{ width: '100%', padding: '13px', background: loading ? '#f4a882' : '#e8734a', color: '#fff', border: 'none', borderRadius: 30, fontSize: 16, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'background 0.15s', boxShadow: '0 4px 14px rgba(232,115,74,0.35)', marginBottom: 16 }}
              onMouseEnter={e => { if (!loading) e.currentTarget.style.background = '#d4623a'; }}
              onMouseLeave={e => { if (!loading) e.currentTarget.style.background = '#e8734a'; }}>
              {loading && <span style={{ width: 15, height: 15, border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block' }} />}
              {loading ? 'Signing in...' : 'Log In'}
            </button>
          </form>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
            <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
            <span style={{ fontSize: 12, color: '#94a3b8', fontWeight: 600 }}>OR</span>
            <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
          </div>

          {/* Register New Account button */}
          <button onClick={() => navigate('/register')}
            style={{ width: '100%', padding: '12px', background: '#1a3a7c', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: 'pointer', transition: 'background 0.15s', marginBottom: 16 }}
            onMouseEnter={e => e.currentTarget.style.background = '#0f2a5e'}
            onMouseLeave={e => e.currentTarget.style.background = '#1a3a7c'}>
            Register New Account
          </button>

          <div style={{ textAlign: 'center' }}>
            <a href="/forgot-password" style={{ fontSize: 13, color: '#1a6b7c', textDecoration: 'underline', fontWeight: 500 }}>Forgot Password?</a>
          </div>
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
