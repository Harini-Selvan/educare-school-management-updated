import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../../services/api';

const EDU_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function getPasswordStrength(pw) {
  if (!pw) return { score: 0, label: '', color: '#e2e8f0' };
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
  const colors = ['#e2e8f0', '#ef4444', '#f59e0b', '#3b82f6', '#22c55e'];
  return { score, label: labels[score], color: colors[score] };
}

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', role: '' });
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const strength = getPasswordStrength(form.password);

  const validateEmail = (val) => {
    if (val && !EDU_REGEX.test(val)) {
      setEmailError('Please enter a valid email address');
    } else {
      setEmailError('');
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!EDU_REGEX.test(form.email)) { setEmailError('Please enter a valid email address'); return; }
    setLoading(true); setError('');
    try {
      await authAPI.register(form);
      setSuccess('Account created successfully! Your account is pending admin approval. You will be able to login once an admin approves your account.');
      setTimeout(() => navigate('/login'), 3500);
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Try again.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#1a6b7c', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, fontFamily: 'Outfit, sans-serif' }}>
      <div style={{ width: '100%', maxWidth: 480, background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.25)' }}>
        {/* Yellow header */}
        <div style={{ background: 'linear-gradient(135deg, #f5c842 0%, #f0b429 100%)', padding: '24px 40px', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, background: '#1a6b7c', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: '#f5c842', fontWeight: 900 }}>E</div>
            <h1 style={{ fontSize: 22, fontWeight: 900, color: '#2d2200', margin: 0 }}>Create Account</h1>
          </div>
        </div>

        <div style={{ padding: '28px 40px' }}>
          {success && <div style={{ background: '#dcfce7', border: '1px solid #86efac', color: '#166534', padding: '12px 14px', borderRadius: 8, fontSize: 13, marginBottom: 16 }}>{success}</div>}
          {error && <div style={{ background: '#fee2e2', border: '1px solid #fecaca', color: '#991b1b', padding: '12px 14px', borderRadius: 8, fontSize: 13, marginBottom: 16 }}>{error}</div>}

          <form onSubmit={handleSubmit}>
            {/* Name */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Full Name</label>
              <input type="text" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Alice" style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
            </div>

            {/* Email */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Email Address</label>
              <input type="email" required value={form.email}
                onChange={e => { setForm({ ...form, email: e.target.value }); validateEmail(e.target.value); }}
                placeholder="yourname@school.edu"
                style={{ ...inputStyle, borderColor: emailError ? '#ef4444' : '#e2e8f0' }}
                onFocus={focusStyle} onBlur={blurStyle} />
              {emailError && <p style={{ fontSize: 12, color: '#ef4444', marginTop: 4 }}>{emailError}</p>}
              <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 3 }}>Must end with .edu</p>
            </div>

            {/* Password + strength */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Password</label>
              <input type="password" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}
                placeholder="Min 8 characters" style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
              {form.password && (
                <div style={{ marginTop: 8 }}>
                  <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
                    {[1,2,3,4].map(i => (
                      <div key={i} style={{ flex: 1, height: 4, borderRadius: 4, background: i <= strength.score ? strength.color : '#e2e8f0', transition: 'background 0.2s' }} />
                    ))}
                  </div>
                  <p style={{ fontSize: 12, color: strength.color, fontWeight: 600 }}>{strength.label}</p>
                </div>
              )}
            </div>

            {/* Phone */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Phone Number</label>
              <input type="tel" value={form.phone} onChange={e => { const v = e.target.value.replace(/\D/g,''); setForm({ ...form, phone: v }); }}
                placeholder="e.g. 9876543210" style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
              <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 3 }}>Numbers only</p>
            </div>

            {/* Role */}
            <div style={{ marginBottom: 20 }}>
              <label style={labelStyle}>Role</label>
              <select required value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}
                style={{ ...inputStyle, cursor: 'pointer' }}>
                <option value="">Select your role</option>
                <option value="STUDENT">Student</option>
                <option value="TEACHER">Teacher</option>
                <option value="ADMIN">Admin</option>
                <option value="EXAM_COORDINATOR">Exam Coordinator</option>
                <option value="AUDITOR">Auditor</option>
                <option value="PARENT">Parent</option>
              </select>
            </div>

            <button type="submit" disabled={loading || !!emailError}
              style={{ width: '100%', padding: '13px', background: loading ? '#93c5fd' : '#e8734a', color: '#fff', border: 'none', borderRadius: 30, fontSize: 15, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', marginBottom: 14, boxShadow: '0 4px 14px rgba(232,115,74,0.3)' }}>
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>

            <p style={{ textAlign: 'center', fontSize: 13, color: '#64748b' }}>
              Already have an account?{' '}
              <a href="/login" style={{ color: '#1a6b7c', fontWeight: 700, textDecoration: 'underline' }}>Sign in</a>
            </p>
            <p style={{ textAlign: 'center', marginTop: 8 }}>
              <a href="/forgot-password" style={{ fontSize: 12, color: '#94a3b8', textDecoration: 'underline' }}>Forgot Password?</a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

const labelStyle = { display: 'block', fontSize: 11, fontWeight: 700, color: '#94a3b8', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' };
const inputStyle = { width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 6, fontSize: 14, outline: 'none', background: '#f8fafc', boxSizing: 'border-box', fontFamily: 'Outfit, sans-serif' };
const focusStyle = e => { e.target.style.borderColor = '#1a6b7c'; e.target.style.background = '#fff'; };
const blurStyle = e => { e.target.style.borderColor = '#e2e8f0'; e.target.style.background = '#f8fafc'; };
