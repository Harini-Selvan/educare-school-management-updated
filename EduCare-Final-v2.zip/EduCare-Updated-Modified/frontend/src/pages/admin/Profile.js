import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import { authAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function AdminProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.userId) {
      authAPI.getUserById(user.userId)
        .then(r => setProfile(r.data))
        .catch(() => setProfile(user))
        .finally(() => setLoading(false));
    } else {
      setProfile(user);
      setLoading(false);
    }
  }, [user]);

  const accentColor = '#1e40af';

  return (
    <DashboardLayout title="My Profile">
      <div style={{ maxWidth: 520, margin: '0 auto' }}>
        <Card title="Admin Profile">
          {loading ? (
            <p style={{ color: 'var(--text-muted)', padding: 20 }}>Loading...</p>
          ) : profile ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px', background: accentColor + '10', borderRadius: 10, marginBottom: 20 }}>
                <div style={{ width: 64, height: 64, borderRadius: '50%', background: accentColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 800, color: '#fff', flexShrink: 0 }}>
                  {(profile.name || user?.name)?.charAt(0)?.toUpperCase()}
                </div>
                <div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text)' }}>{profile.name || user?.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{profile.email || user?.email}</div>
                  <div style={{ marginTop: 4 }}><Badge text="ADMIN" /></div>
                </div>
              </div>
              {[
                ['User ID', profile.id || user?.userId],
                ['Full Name', profile.name || user?.name],
                ['Email', profile.email || user?.email],
                ['Phone', profile.phone || '—'],
                ['Role', 'Administrator'],
                ['Status', profile.status || 'ACTIVE'],
                ['Registered', profile.createdAt ? new Date(profile.createdAt).toLocaleString() : '—'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{label}</span>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{String(value)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p style={{ color: 'var(--text-muted)' }}>Profile not found.</p>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
