import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Input from '../../components/common/Input';
import Toast from '../../components/common/Toast';
import Table from '../../components/common/Table';
import { studentAPI, authAPI } from '../../services/api';

export default function AdminSetup() {
  const [students, setStudents] = useState([]);
  const [users, setUsers] = useState([]);
  const [links, setLinks] = useState([]);
  const [form, setForm] = useState({ studentId: '', studentEmail: '', parentEmail: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [verifyResult, setVerifyResult] = useState(null);
  const [verifyForm, setVerifyForm] = useState({ studentId: '', email: '', role: 'STUDENT' });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [s, u] = await Promise.all([studentAPI.getAll(), authAPI.getUsers()]);
        if (!cancelled) {
          setStudents(s.data || []);
          setUsers(u.data || []);
        }
      } catch (err) { /* ignore */ }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  async function registerLink(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await studentAPI.registerLink({
        studentId: Number(form.studentId),
        studentEmail: form.studentEmail,
        parentEmail: form.parentEmail,
      });
      setToast({ message: `✅ Link registered! Student ${form.studentId} linked to ${form.studentEmail}`, type: 'success' });
      setLinks(prev => [...prev, { ...form, id: res.data?.id }]);
      setForm({ studentId: '', studentEmail: '', parentEmail: '' });
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error registering link. Link may already exist.', type: 'error' });
    } finally { setSaving(false); }
  }

  async function verifyLink(e) {
    e.preventDefault();
    try {
      const res = await studentAPI.verifyLink(Number(verifyForm.studentId), verifyForm.email, verifyForm.role);
      setVerifyResult(res.data === true
        ? { ok: true, msg: `✅ Link EXISTS — ${verifyForm.email} is linked to student ${verifyForm.studentId}` }
        : { ok: false, msg: `❌ Link NOT found — register it below first` }
      );
    } catch (err) {
      setVerifyResult({ ok: false, msg: 'Error: ' + (err.response?.data?.message || err.message) });
    }
  }

  const quickLinks = [
    { studentId: 1, studentEmail: 'alice@student.com', parentEmail: 'robert.johnson@gmail.com' },
    { studentId: 2, studentEmail: 'bob@student.com',   parentEmail: 'bob.parent@gmail.com' },
    { studentId: 3, studentEmail: 'carol@student.com', parentEmail: 'carol.parent@gmail.com' },
  ];

  async function registerQuick(link) {
    setSaving(true);
    try {
      await studentAPI.registerLink({ ...link, studentId: Number(link.studentId) });
      setToast({ message: `✅ Linked: ${link.studentEmail} → Student ${link.studentId}`, type: 'success' });
      setLinks(prev => [...prev, link]);
    } catch (err) {
      setToast({ message: `${link.studentEmail}: ` + (err.response?.data?.message || 'Already linked or error'), type: 'error' });
    } finally { setSaving(false); }
  }

  async function registerAllDemo() {
    for (const link of quickLinks) {
      try {
        await studentAPI.registerLink({ ...link, studentId: Number(link.studentId) });
      } catch (err) { /* already exists is fine */ }
    }
    setToast({ message: '✅ All demo student links registered!', type: 'success' });
  }

  const studentColumns = [
    { title: 'ID', key: 'id' },
    { title: 'Name', key: 'name', render: v => <span style={{ fontWeight: 600 }}>{v}</span> },
    { title: 'Program', key: 'program' },
    { title: 'Quick Link', key: 'id', render: (v, r) => {
      const demo = quickLinks.find(l => l.studentId === v);
      return demo ? (
        <Button size="sm" variant="ghost" onClick={() => registerQuick(demo)}>
          Register Link
        </Button>
      ) : <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>Set manually below</span>;
    }},
  ];

  return (
    <DashboardLayout title="System Setup">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Quick Setup */}
      <Card title="🚀 Quick Demo Setup" subtitle="Register all demo student links in one click" style={{ marginBottom: 16, border: '2px solid #1e40af' }}>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>
          This registers student links for Alice, Bob and Carol so they can view their profiles.
        </p>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          {quickLinks.map(link => (
            <div key={link.studentId} style={{ background: 'var(--surface2)', borderRadius: 8, padding: '10px 16px', fontSize: 13 }}>
              <div style={{ fontWeight: 600 }}>Student {link.studentId}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: 12 }}>{link.studentEmail}</div>
            </div>
          ))}
          <Button onClick={registerAllDemo} loading={saving} style={{ marginLeft: 'auto' }}>
            Register All 3 Links
          </Button>
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Manual Register */}
        <Card title="Register Student Link" subtitle="Link a student email to their student record">
          <form onSubmit={registerLink}>
            <Input
              label="Student ID"
              type="number"
              value={form.studentId}
              onChange={e => setForm({...form, studentId: e.target.value})}
              required
              placeholder="1"
              hint="The numeric ID from the Students table"
            />
            <Input
              label="Student Email"
              type="email"
              value={form.studentEmail}
              onChange={e => setForm({...form, studentEmail: e.target.value})}
              required
              placeholder="alice@student.com"
              hint="The email the student uses to login"
            />
            <Input
              label="Parent Email"
              type="email"
              value={form.parentEmail}
              onChange={e => setForm({...form, parentEmail: e.target.value})}
              required
              placeholder="parent@email.com"
              hint="The email the parent uses to login"
            />
            <Button type="submit" loading={saving} style={{ width: '100%' }}>
              Register Link
            </Button>
          </form>
        </Card>

        {/* Verify Link */}
        <Card title="Verify Student Link" subtitle="Check if a link is registered">
          <form onSubmit={verifyLink}>
            <Input
              label="Student ID"
              type="number"
              value={verifyForm.studentId}
              onChange={e => setVerifyForm({...verifyForm, studentId: e.target.value})}
              required
              placeholder="1"
            />
            <Input
              label="Email"
              type="email"
              value={verifyForm.email}
              onChange={e => setVerifyForm({...verifyForm, email: e.target.value})}
              required
              placeholder="alice@student.com"
            />
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Role</label>
              <div style={{ display: 'flex', gap: 8 }}>
                {['STUDENT', 'PARENT'].map(r => (
                  <button key={r} type="button" onClick={() => setVerifyForm({...verifyForm, role: r})}
                    style={{ flex: 1, padding: '9px', borderRadius: 7, border: '1.5px solid', borderColor: verifyForm.role === r ? '#1e40af' : '#e2e8f0', background: verifyForm.role === r ? '#eff6ff' : '#f8fafc', color: verifyForm.role === r ? '#1e40af' : '#475569', fontWeight: verifyForm.role === r ? 700 : 400, cursor: 'pointer', fontSize: 13, fontFamily: 'Outfit, sans-serif' }}>
                    {r}
                  </button>
                ))}
              </div>
            </div>
            <Button type="submit" variant="secondary" style={{ width: '100%' }}>Verify Link</Button>
          </form>
          {verifyResult && (
            <div style={{ marginTop: 16, padding: 14, borderRadius: 8, background: verifyResult.ok ? '#d1fae5' : '#fee2e2', color: verifyResult.ok ? '#065f46' : '#991b1b', fontSize: 14, fontWeight: 600 }}>
              {verifyResult.msg}
            </div>
          )}
        </Card>
      </div>

      {/* Students Table */}
      <Card title="All Students" subtitle={students.length + " students registered"}>
        <Table columns={studentColumns} data={students} emptyText="No students registered yet. Create students first." />
      </Card>
    </DashboardLayout>
  );
}
