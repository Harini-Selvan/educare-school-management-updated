import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { studentAPI, classAPI } from '../../services/api';

export default function AdminEnrollments() {
  const [students, setStudents] = useState([]);
  const [classes, setClasses] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ studentId: '', classId: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [s, c] = await Promise.all([studentAPI.getAll(), classAPI.getAll()]);
        if (!cancelled) { setStudents(s.data || []); setClasses(c.data || []); }
      } catch (err) {
        // ignore
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  function loadEnrollments(studentId) {
    setSelectedStudent(studentId);
    if (!studentId) { setEnrollments([]); return; }
    setLoading(true);
    studentAPI.getEnrollmentsByStudent(studentId)
      .then(r => setEnrollments(r.data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }

  async function handleEnroll(e) {
    e.preventDefault(); setSaving(true);
    try {
      await studentAPI.enroll({ studentId: Number(form.studentId), classId: Number(form.classId) });
      setToast({ message: 'Student enrolled!', type: 'success' });
      setModal(false);
      if (selectedStudent) loadEnrollments(selectedStudent);
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error enrolling', type: 'error' });
    } finally { setSaving(false); }
  }

  const getClassName = id => classes.find(c => c.id === id)?.name || 'Class ' + id;
  const getStudentName = id => students.find(s => s.id === Number(id))?.name || 'Student ' + id;

  const columns = [
    { title: 'Student', key: 'studentId', render: v => getStudentName(v) },
    { title: 'Class', key: 'classId', render: v => getClassName(v) },
    { title: 'Enrolled At', key: 'enrolledAt', render: v => v ? new Date(v).toLocaleDateString() : '-' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => r.status === 'ACTIVE' && (
      <Button variant="danger" size="sm" onClick={() => studentAPI.updateEnrollmentStatus(r.id, 'DROPPED').then(() => loadEnrollments(selectedStudent))}>Drop</Button>
    )},
  ];

  return (
    <DashboardLayout title="Enrollment Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Enrollments" extra={<Button onClick={() => setModal(true)}>+ Enroll Student</Button>}>
        <div style={{ marginBottom: 16, display: 'flex', gap: 12, alignItems: 'center' }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>Filter by Student:</label>
          <select value={selectedStudent} onChange={e => loadEnrollments(e.target.value)}
            style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 7, fontSize: 13, background: 'var(--surface)', outline: 'none' }}>
            <option value="">Select a student...</option>
            {students.map(s => <option key={s.id} value={s.id}>{s.name} (ID: {s.id})</option>)}
          </select>
        </div>
        <Table columns={columns} data={enrollments} loading={loading} emptyText="Select a student to see enrollments" />
      </Card>
      <Modal open={modal} onClose={() => setModal(false)} title="Enroll Student">
        <form onSubmit={handleEnroll}>
          <Select label="Student" value={form.studentId} onChange={e => setForm({...form, studentId: e.target.value})} required options={students.map(s => ({value: s.id, label: s.name + ' (' + s.program + ')'}))} />
          <Select label="Class" value={form.classId} onChange={e => setForm({...form, classId: e.target.value})} required options={classes.filter(c => c.status === 'ACTIVE').map(c => ({value: c.id, label: c.name}))} />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Enroll</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
