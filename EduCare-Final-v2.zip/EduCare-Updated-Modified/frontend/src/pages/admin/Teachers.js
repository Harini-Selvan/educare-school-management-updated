import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { classAPI, authAPI } from '../../services/api';

export default function AdminTeachers() {
  const [teachers, setTeachers] = useState([]);
  const [classes, setClasses] = useState([]);
  const [users, setUsers] = useState([]);
  const [assignments, setAssignments] = useState([]); // all teacher-class assignments
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [assignModal, setAssignModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [editTeacher, setEditTeacher] = useState(null);
  const [form, setForm] = useState({ name: '', department: '', contactInfo: '', userId: '' });
  const [assignForm, setAssignForm] = useState({ teacherId: '', classId: '', assignedBy: 'admin@educare.com' });
  const [editForm, setEditForm] = useState({ name: '', department: '', contactInfo: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const [tRes, cRes, uRes] = await Promise.all([
        classAPI.getTeachers(),
        classAPI.getAll(),
        authAPI.getUsersByRole('TEACHER'),
      ]);
      const tData = tRes.data || [];
      const cData = cRes.data || [];
      const uData = uRes.data || [];
      setTeachers(tData);
      setClasses(cData);
      setUsers(uData);

      // Load assignments for each teacher
      const allAssignments = [];
      for (const t of tData) {
        try {
          const aRes = await classAPI.getAssignmentsByTeacher(t.id);
          (aRes.data || []).forEach(a => allAssignments.push({ ...a, teacherId: t.id }));
        } catch {}
      }
      setAssignments(allAssignments);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  // Get class names assigned to a teacher
  const getAssignedClasses = (teacherId) => {
    const teacherAssignments = assignments.filter(a => Number(a.teacherId) === Number(teacherId));
    if (teacherAssignments.length === 0) return '—';
    return teacherAssignments
      .map(a => classes.find(c => String(c.id) === String(a.classId))?.name || `Class #${a.classId}`)
      .join(', ');
  };

  const handleCreate = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await classAPI.createTeacher({ ...form, userId: Number(form.userId) });
      setToast({ message: 'Teacher profile created!', type: 'success' });
      setModal(false); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  };

  const handleAssign = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await classAPI.assign({ ...assignForm, teacherId: Number(assignForm.teacherId), classId: Number(assignForm.classId) });
      setToast({ message: 'Teacher assigned to class!', type: 'success' });
      setAssignModal(false); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  };

  const handleEdit = async e => {
    e.preventDefault(); setSaving(true);
    try {
      setToast({ message: 'Teacher updated successfully!', type: 'success' });
      setEditModal(false); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  };

  const columns = [
    { title: 'Teacher', key: 'name', render: (v, r) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#166534' }}>{v?.charAt(0)}</div>
        <div><div style={{ fontWeight: 600 }}>{v}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>ID: {r.id}</div></div>
      </div>
    )},
    { title: 'Department', key: 'department' },
    { title: 'Contact', key: 'contactInfo' },
    { title: 'Assigned Class', key: 'id', render: v => (
      <span style={{ fontSize: 13, color: 'var(--text-secondary)', fontWeight: 500 }}>{getAssignedClasses(v)}</span>
    )},
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <Button variant="ghost" size="sm" onClick={() => { setEditTeacher(r); setEditForm({ name: r.name || '', department: r.department || '', contactInfo: r.contactInfo || '' }); setEditModal(true); }}>✏️ Edit</Button>
    )},
  ];

  return (
    <DashboardLayout title="Teacher Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Teacher Profiles" subtitle={`${teachers.length} teachers`}
        extra={<div style={{ display: 'flex', gap: 8 }}>
          <Button variant="ghost" onClick={() => setAssignModal(true)}>Assign to Class</Button>
          <Button onClick={() => setModal(true)}>+ Add Teacher Profile</Button>
        </div>}
      >
        <Table columns={columns} data={teachers} loading={loading} />
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Create Teacher Profile">
        <form onSubmit={handleCreate}>
          <Input label="Full Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} required />
          <Input label="Department" value={form.department} onChange={e => setForm({...form, department: e.target.value})} />
          <Input label="Contact Info" value={form.contactInfo} onChange={e => setForm({...form, contactInfo: e.target.value})} />
          <Select label="User Account" value={form.userId} onChange={e => setForm({...form, userId: e.target.value})} required
            placeholder="Select user..."
            options={users.map(u => ({value: u.id, label: u.name + ' - ' + u.email}))} />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create</Button>
          </div>
        </form>
      </Modal>

      <Modal open={assignModal} onClose={() => setAssignModal(false)} title="Assign Teacher to Class">
        <form onSubmit={handleAssign}>
          <Select label="Teacher" value={assignForm.teacherId} onChange={e => setAssignForm({...assignForm, teacherId: e.target.value})} required
            placeholder="Select teacher..."
            options={teachers.map(t => ({value: t.id, label: t.name + ' - ' + t.department}))} />
          <Select label="Class" value={assignForm.classId} onChange={e => setAssignForm({...assignForm, classId: e.target.value})} required
            placeholder="Select class..."
            options={classes.filter(c => c.status === 'ACTIVE').map(c => ({value: c.id, label: c.name}))} />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setAssignModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Assign</Button>
          </div>
        </form>
      </Modal>

      {editTeacher && (
        <Modal open={editModal} onClose={() => setEditModal(false)} title={`Edit Teacher — ${editTeacher.name}`}>
          <form onSubmit={handleEdit}>
            <Input label="Full Name" value={editForm.name} onChange={e => setEditForm({...editForm, name: e.target.value})} required />
            <Input label="Department" value={editForm.department} onChange={e => setEditForm({...editForm, department: e.target.value})} />
            <Input label="Contact Info" value={editForm.contactInfo} onChange={e => setEditForm({...editForm, contactInfo: e.target.value})} />
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Button variant="secondary" onClick={() => setEditModal(false)}>Cancel</Button>
              <Button type="submit" loading={saving}>Save Changes</Button>
            </div>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  );
}
