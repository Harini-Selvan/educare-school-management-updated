import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { notificationAPI, authAPI } from '../../services/api';

export default function AdminTasks() {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ assignedTo: '', description: '', dueDate: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = () => {
    setLoading(true);
    Promise.all([notificationAPI.getAllTasks(), authAPI.getUsers()])
      .then(([t, u]) => { setTasks(t.data || []); setUsers(u.data || []); })
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const handleCreate = async e => {
    e.preventDefault(); setSaving(true);
    try {
      const selectedUser = users.find(u => u.id === Number(form.assignedTo));
      await notificationAPI.createTask({
        assignedTo: Number(form.assignedTo),
        assignedToEmail: selectedUser?.email || '',
        description: form.description,
        dueDate: form.dueDate,
        relatedEntityId: null,
      });
      setToast({ message: 'Task created!', type: 'success' });
      setModal(false); setForm({ assignedTo: '', description: '', dueDate: '' }); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  };

  const assignableUsers = users.filter(u => ['TEACHER','EXAM_COORDINATOR'].includes(u.role));

  const statusColor = { PENDING: '#d97706', IN_PROGRESS: '#0891b2', COMPLETED: '#059669', OVERDUE: '#dc2626' };

  const columns = [
    { title: 'Task', key: 'description', render: v => <span style={{ fontWeight: 500 }}>{v}</span> },
    { title: 'Assigned To', key: 'assignedToEmail', render: (v, r) => (
      <div>
        <div style={{ fontWeight: 600 }}>{users.find(u => u.id === r.assignedTo)?.name || '—'}</div>
        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v}</div>
      </div>
    )},
    { title: 'Due Date', key: 'dueDate', render: v => {
      const overdue = v && new Date(v) < new Date();
      return <span style={{ color: overdue ? '#dc2626' : 'var(--text)', fontWeight: 600 }}>{v || '—'}</span>;
    }},
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
  ];

  const statusGroups = ['PENDING','IN_PROGRESS','COMPLETED','OVERDUE'].map(s => ({ status: s, count: tasks.filter(t => t.status === s).length }));

  return (
    <DashboardLayout title="Task Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {statusGroups.map(({ status, count }) => (
          <div key={status} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '16px 20px', borderLeft: `4px solid ${statusColor[status]}` }}>
            <div style={{ fontSize: 26, fontWeight: 800, color: statusColor[status] }}>{count}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, marginTop: 2 }}>{status}</div>
          </div>
        ))}
      </div>

      <Card title="All Tasks" subtitle={`${tasks.length} tasks total`} extra={
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="ghost" onClick={load}>🔄 Refresh</Button>
            <Button onClick={() => setModal(true)}>+ Create Task</Button>
          </div>
        }>
        <Table columns={columns} data={tasks} loading={loading} emptyText="No tasks yet" />
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Create Task">
        <form onSubmit={handleCreate}>
          <Select label="Assign To (Teacher or Coordinator)" value={form.assignedTo} onChange={e => setForm({...form, assignedTo: e.target.value})} required
            placeholder='Select user...' options={[ ...assignableUsers.map(u => ({value: u.id, label: `${u.name} (${u.role})`}))]} />
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Description</label>
            <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} required rows={3}
              style={{ width: '100%', padding: '10px 14px', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none' }}
              placeholder="Submit attendance report for April..." />
          </div>
          <Input label="Due Date" type="date" value={form.dueDate} onChange={e => setForm({...form, dueDate: e.target.value})} required />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create Task</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
