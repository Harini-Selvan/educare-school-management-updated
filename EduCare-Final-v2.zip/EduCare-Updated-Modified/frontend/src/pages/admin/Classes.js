import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Toast from '../../components/common/Toast';
import { classAPI } from '../../services/api';

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
const PERIODS = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00'];

export default function AdminClasses() {
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [timetableModal, setTimetableModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const [form, setForm] = useState({ name: '', capacity: '' });
  const [editForm, setEditForm] = useState({ name: '', capacity: '' });
  const [timetable, setTimetable] = useState({});
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const load = () => {
    setLoading(true);
    classAPI.getAll()
      .then(c => { setClasses(c.data || []); })
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const handleCreate = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await classAPI.create({ name: form.name, capacity: Number(form.capacity) });
      setToast({ message: 'Class created successfully', type: 'success' });
      setModal(false); setForm({ name: '', capacity: '' }); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error creating class', type: 'error' });
    } finally { setSaving(false); }
  };

  const handleEdit = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await classAPI.update(selectedClass.id, { ...selectedClass, name: editForm.name, capacity: Number(editForm.capacity) });
      setToast({ message: 'Class updated successfully', type: 'success' });
      setEditModal(false); load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error updating class', type: 'error' });
    } finally { setSaving(false); }
  };

  const openEdit = (cls) => {
    setSelectedClass(cls);
    setEditForm({ name: cls.name || '', capacity: cls.capacity || '' });
    setEditModal(true);
  };

  const openTimetable = (cls) => {
    setSelectedClass(cls);
    try { setTimetable(cls.scheduleJson ? JSON.parse(cls.scheduleJson) : {}); } catch { setTimetable({}); }
    setTimetableModal(true);
  };

  const saveTimetable = async () => {
    setSaving(true);
    try {
      await classAPI.update(selectedClass.id, { ...selectedClass, scheduleJson: JSON.stringify(timetable) });
      setToast({ message: 'Timetable saved!', type: 'success' });
      setTimetableModal(false); load();
    } catch (err) {
      setToast({ message: 'Error saving timetable', type: 'error' });
    } finally { setSaving(false); }
  };

  const setCellValue = (day, time, field, value) => {
    const key = `${day}_${time}`;
    setTimetable(prev => ({ ...prev, [key]: { ...prev[key], [field]: value } }));
  };

  // Enforce lunch at 12:00
  const isLunchSlot = (time) => time === '12:00';

  const columns = [
    { title: 'Class', key: 'name', render: v => <span style={{ fontWeight: 600 }}>{v}</span> },
    { title: 'Capacity', key: 'capacity' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <div style={{ display: 'flex', gap: 6 }}>
        <Button variant="ghost" size="sm" onClick={() => openEdit(r)}>✏️ Edit</Button>
        <Button variant="ghost" size="sm" onClick={() => openTimetable(r)}>📅 Timetable</Button>
        <Button variant={r.status === 'ACTIVE' ? 'danger' : 'success'} size="sm"
          onClick={() => classAPI.updateStatus(r.id, r.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE').then(load)}>
          {r.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
        </Button>
      </div>
    )},
  ];

  return (
    <DashboardLayout title="Class Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="All Classes" subtitle={`${classes.length} classes`} extra={<Button onClick={() => setModal(true)}>+ Create Class</Button>}>
        <Table columns={columns} data={classes} loading={loading} />
      </Card>

      {/* Create Class Modal */}
      <Modal open={modal} onClose={() => setModal(false)} title="Create New Class">
        <form onSubmit={handleCreate}>
          <Input label="Class" value={form.name} onChange={e => setForm({...form, name: e.target.value})} required placeholder="10 A" hint="Enter class name e.g. 10 A, 9 B, etc." />
          <Input label="Capacity" type="number" value={form.capacity} onChange={e => setForm({...form, capacity: e.target.value})} placeholder="30" />
          <div style={{ background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: 12, color: '#0369a1' }}>
            ℹ️ Multiple teachers and students can be linked to one class.
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create Class</Button>
          </div>
        </form>
      </Modal>

      {/* Edit Class Modal */}
      {selectedClass && (
        <Modal open={editModal} onClose={() => setEditModal(false)} title={`Edit Class — ${selectedClass.name}`}>
          <form onSubmit={handleEdit}>
            <Input label="Class" value={editForm.name} onChange={e => setEditForm({...editForm, name: e.target.value})} required placeholder="10 A" />
            <Input label="Capacity" type="number" value={editForm.capacity} onChange={e => setEditForm({...editForm, capacity: e.target.value})} placeholder="30" />
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Button variant="secondary" onClick={() => setEditModal(false)}>Cancel</Button>
              <Button type="submit" loading={saving}>Save Changes</Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Timetable Modal */}
      {selectedClass && (
        <Modal open={timetableModal} onClose={() => setTimetableModal(false)} title={`Timetable — ${selectedClass.name}`} width={800}>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>Configure weekly periods. The 12:00–1:00 slot is reserved as Lunch.</p>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr>
                  <th style={{ padding: '8px 12px', background: '#f8fafc', border: '1px solid var(--border)', fontWeight: 700, color: 'var(--text)', width: 80 }}>Time</th>
                  {DAYS.map(d => <th key={d} style={{ padding: '8px 12px', background: '#eff6ff', border: '1px solid var(--border)', fontWeight: 700, color: '#1e40af' }}>{d}</th>)}
                </tr>
              </thead>
              <tbody>
                {PERIODS.map(time => (
                  <tr key={time}>
                    <td style={{ padding: '8px', border: '1px solid var(--border)', fontWeight: 600, textAlign: 'center', background: isLunchSlot(time) ? '#fef3c7' : '#f8fafc', color: isLunchSlot(time) ? '#92400e' : 'var(--text-muted)', fontSize: 11 }}>{time}{isLunchSlot(time) ? ' 🍽️' : ''}</td>
                    {DAYS.map(day => {
                      const key = `${day}_${time}`;
                      const cell = timetable[key] || {};
                      if (isLunchSlot(time)) {
                        return (
                          <td key={day} style={{ padding: 6, border: '1px solid var(--border)', background: '#fef3c7', textAlign: 'center', fontSize: 12, fontWeight: 600, color: '#92400e' }}>
                            Lunch Break
                          </td>
                        );
                      }
                      return (
                        <td key={day} style={{ padding: 6, border: '1px solid var(--border)', minWidth: 120, background: cell.subject ? '#f0fdf4' : '#fff' }}>
                          <input
                            placeholder="Subject"
                            value={cell.subject || ''}
                            onChange={e => setCellValue(day, time, 'subject', e.target.value)}
                            style={{ width: '100%', padding: '4px 6px', border: '1px solid #e2e8f0', borderRadius: 4, fontSize: 11, marginBottom: 3, boxSizing: 'border-box', outline: 'none', fontFamily: 'Outfit,sans-serif' }}
                          />
                          <input
                            placeholder="Teacher"
                            value={cell.teacher || ''}
                            onChange={e => setCellValue(day, time, 'teacher', e.target.value)}
                            style={{ width: '100%', padding: '4px 6px', border: '1px solid #e2e8f0', borderRadius: 4, fontSize: 11, boxSizing: 'border-box', outline: 'none', fontFamily: 'Outfit,sans-serif' }}
                          />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16 }}>
            <Button variant="secondary" onClick={() => setTimetableModal(false)}>Cancel</Button>
            <Button loading={saving} onClick={saveTimetable}>Save Timetable</Button>
          </div>
        </Modal>
      )}
    </DashboardLayout>
  );
}
