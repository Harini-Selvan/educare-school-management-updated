import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { studentAPI, authAPI, classAPI } from '../../services/api';

export default function AdminStudents() {
  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [classes, setClasses] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const [form, setForm] = useState({
    name: '', dob: '', gender: '', contactInfo: '', program: '',
    studentEmail: '', studentPassword: '', parentEmail: '',
    enrollClassId: '',   // which class to auto-enroll into
  });
  const [editForm, setEditForm] = useState({
    name: '', dob: '', gender: '', contactInfo: '', program: '', parentEmail: '',
  });

  const loadAll = async () => {
    setLoading(true);
    try {
      const [sRes, tRes, cRes] = await Promise.all([
        studentAPI.getAll(),
        classAPI.getTeachers(),
        classAPI.getAll(),
      ]);
      const sData = sRes.data || [];
      const tData = tRes.data || [];
      const cData = cRes.data?.filter(c => c.status === 'ACTIVE') || [];
      setStudents(sData);
      setTeachers(tData);
      setClasses(cData);

      // Load ALL teacher-class assignments
      const allAssignments = [];
      for (const t of tData) {
        try {
          const aRes = await classAPI.getAssignmentsByTeacher(t.id);
          (aRes.data || []).forEach(a => {
            allAssignments.push({
              classId: String(a.classId),
              teacherId: String(t.id),
              teacherName: t.name,
            });
          });
        } catch {}
      }
      setAssignments(allAssignments);

      // Load enrollments by class (more efficient: N class calls vs M student calls)
      const allEnrollments = [];
      for (const cls of cData) {
        try {
          const eRes = await studentAPI.getEnrollmentsByClass(cls.id);
          (eRes.data || [])
            .filter(e => e.status === 'ACTIVE')
            .forEach(e => allEnrollments.push({
              studentId: String(e.studentId),
              classId: String(cls.id),
            }));
        } catch {}
      }
      setEnrollments(allEnrollments);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  // Get class name for this student
  const getStudentClass = (studentId) => {
    const enr = enrollments.find(e => e.studentId === String(studentId));
    if (!enr) return '—';
    const cls = classes.find(c => String(c.id) === enr.classId);
    return cls?.name || `Class #${enr.classId}`;
  };

  // Get teacher name for this student's class
  const getAssignedTeacher = (studentId) => {
    const enr = enrollments.find(e => e.studentId === String(studentId));
    if (!enr) return '—';
    const asgn = assignments.find(a => a.classId === enr.classId);
    return asgn ? asgn.teacherName : '—';
  };

  async function handleCreate(e) {
    e.preventDefault(); setSaving(true);
    const steps = [];
    try {
      // Step 1: Create student record
      const studentRes = await studentAPI.create({
        name: form.name, dob: form.dob, gender: form.gender,
        contactInfo: form.contactInfo, program: form.program, parentEmail: form.parentEmail,
      });
      const newStudentId = studentRes.data?.id;
      steps.push(`✅ Student created (ID: ${newStudentId})`);

      // Step 2: Create login account
      if (form.studentEmail && form.studentPassword) {
        try {
          await authAPI.register({
            name: form.name, email: form.studentEmail,
            password: form.studentPassword, phone: form.contactInfo, role: 'STUDENT',
          });
          steps.push(`✅ Login created (${form.studentEmail})`);
        } catch (err) {
          steps.push(`⚠️ Login: ${err.response?.data?.message || 'may already exist'}`);
        }
      }

      // Step 3: Link student to parent
      if (form.studentEmail && newStudentId) {
        try {
          await studentAPI.registerLink({
            studentId: Number(newStudentId),
            studentEmail: form.studentEmail,
            parentEmail: form.parentEmail,
          });
          steps.push(`✅ Parent link registered`);
        } catch (err) {
          steps.push(`⚠️ Link: ${err.response?.data?.message || 'error'}`);
        }
      }

      // Step 4: Auto-enroll into selected class
      if (form.enrollClassId && newStudentId) {
        try {
          await studentAPI.enroll({
            studentId: Number(newStudentId),
            classId: Number(form.enrollClassId),
          });
          const cls = classes.find(c => String(c.id) === String(form.enrollClassId));
          steps.push(`✅ Enrolled in ${cls?.name || 'class'}`);
        } catch (err) {
          steps.push(`⚠️ Enrollment: ${err.response?.data?.message || 'error'}`);
        }
      }

      setToast({ message: steps.join(' | '), type: 'success' });
      setModal(false);
      setForm({ name: '', dob: '', gender: '', contactInfo: '', program: '', studentEmail: '', studentPassword: '', parentEmail: '', enrollClassId: '' });
      loadAll();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error creating student', type: 'error' });
    } finally { setSaving(false); }
  }

  async function handleEdit(e) {
    e.preventDefault(); setSaving(true);
    try {
      await studentAPI.update(selectedStudent.id, {
        name: editForm.name, dob: editForm.dob, gender: editForm.gender,
        contactInfo: editForm.contactInfo, program: editForm.program,
        parentEmail: editForm.parentEmail,
      });
      setToast({ message: 'Student updated successfully!', type: 'success' });
      setEditModal(false); loadAll();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error', type: 'error' });
    } finally { setSaving(false); }
  }

  const columns = [
    {
      title: 'Student', key: 'name', render: (v, r) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: '50%', background: '#fff7ed', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 800, color: '#c2410c', flexShrink: 0 }}>{v?.charAt(0)}</div>
          <div>
            <div style={{ fontWeight: 600 }}>{v}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>ID: {r.id}</div>
          </div>
        </div>
      ),
    },
    {
      title: 'Class', key: 'id', render: v => (
        <span style={{ fontSize: 13, fontWeight: 500 }}>{getStudentClass(v)}</span>
      ),
    },
    {
      title: 'Teacher Assigned', key: 'id', render: v => (
        <span style={{ fontSize: 13, color: getAssignedTeacher(v) === '—' ? 'var(--text-muted)' : 'var(--text)', fontWeight: getAssignedTeacher(v) === '—' ? 400 : 600 }}>
          {getAssignedTeacher(v)}
        </span>
      ),
    },
    { title: 'Gender', key: 'gender' },
    { title: 'Date of Birth', key: 'dob' },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    {
      title: 'Actions', key: 'id', render: (v, r) => (
        <Button variant="ghost" size="sm" onClick={() => {
          setSelectedStudent(r);
          setEditForm({ name: r.name || '', dob: r.dob || '', gender: r.gender || '', contactInfo: r.contactInfo || '', program: r.program || '', parentEmail: r.parentEmail || '' });
          setEditModal(true);
        }}>✏️ Edit</Button>
      ),
    },
  ];

  return (
    <DashboardLayout title="Student Registry">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <Card title="All Students" subtitle={`${students.length} registered`}
        extra={<Button onClick={() => setModal(true)}>+ Register New Student</Button>}>
        <Table columns={columns} data={students} loading={loading} />
      </Card>

      {/* Register Student Modal */}
      <Modal open={modal} onClose={() => setModal(false)} title="Register New Student" width={560}>
        <form onSubmit={handleCreate}>
          {/* Personal Info */}
          <div style={{ background: 'var(--surface2)', borderRadius: 8, padding: '14px 16px', marginBottom: 14 }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Personal Information</p>
            <Input label="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required placeholder="e.g. Pragya Sharma" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <Input label="Date of Birth" type="date" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} />
              <Select label="Gender" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}
                placeholder="Select gender..."
                options={[{ value: 'MALE', label: 'Male' }, { value: 'FEMALE', label: 'Female' }, { value: 'OTHER', label: 'Other' }]} />
            </div>
            <Input label="Program / Grade" value={form.program} onChange={e => setForm({ ...form, program: e.target.value })} placeholder="Grade 7" />
            <Input label="Contact Info" value={form.contactInfo} onChange={e => setForm({ ...form, contactInfo: e.target.value })} placeholder="Phone number" />
          </div>

          {/* Class Enrollment */}
          <div style={{ background: '#f0fdf4', borderRadius: 8, padding: '14px 16px', marginBottom: 14, border: '1px solid #bbf7d0' }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#065f46', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Class Enrollment</p>
            <Select label="Enroll in Class" value={form.enrollClassId}
              onChange={e => setForm({ ...form, enrollClassId: e.target.value })}
              placeholder="Select class..."
              options={classes.map(c => {
                const asgn = assignments.find(a => a.classId === String(c.id));
                return { value: c.id, label: `${c.name}${asgn ? ' — Teacher: ' + asgn.teacherName : ''}` };
              })} />
            <p style={{ fontSize: 11, color: '#065f46', marginTop: -8 }}>
              The selected teacher will be automatically shown in the Teacher Assigned column.
            </p>
          </div>

          {/* Login Credentials */}
          <div style={{ background: '#eff6ff', borderRadius: 8, padding: '14px 16px', marginBottom: 14, border: '1px solid #bfdbfe' }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#1e40af', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Student Login Credentials</p>
            <Input label="Student Email" type="email" value={form.studentEmail} onChange={e => setForm({ ...form, studentEmail: e.target.value })} required placeholder="student@email.com" hint="Student uses this to login" />
            <Input label="Password" type="password" value={form.studentPassword} onChange={e => setForm({ ...form, studentPassword: e.target.value })} required placeholder="••••••••" hint="Min 6 characters" />
          </div>

          {/* Parent Info */}
          <div style={{ background: '#fdf4ff', borderRadius: 8, padding: '14px 16px', marginBottom: 20, border: '1px solid #e9d5ff' }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#7c3aed', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>Parent Information</p>
            <Input label="Parent Email" type="email" value={form.parentEmail} onChange={e => setForm({ ...form, parentEmail: e.target.value })} required placeholder="parent@email.com" hint="Parent uses this to view their child's data" />
          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Register Student</Button>
          </div>
        </form>
      </Modal>

      {/* Edit Student Modal */}
      {selectedStudent && (
        <Modal open={editModal} onClose={() => setEditModal(false)} title={`Edit Student — ${selectedStudent.name}`} width={520}>
          <form onSubmit={handleEdit}>
            <Input label="Full Name" value={editForm.name} onChange={e => setEditForm({ ...editForm, name: e.target.value })} required />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <Input label="Date of Birth" type="date" value={editForm.dob} onChange={e => setEditForm({ ...editForm, dob: e.target.value })} />
              <Select label="Gender" value={editForm.gender} onChange={e => setEditForm({ ...editForm, gender: e.target.value })}
                placeholder="Select gender..."
                options={[{ value: 'MALE', label: 'Male' }, { value: 'FEMALE', label: 'Female' }, { value: 'OTHER', label: 'Other' }]} />
            </div>
            <Input label="Class / Program" value={editForm.program} onChange={e => setEditForm({ ...editForm, program: e.target.value })} />
            <Input label="Contact Info" value={editForm.contactInfo} onChange={e => setEditForm({ ...editForm, contactInfo: e.target.value })} />
            <Input label="Parent Email" type="email" value={editForm.parentEmail} onChange={e => setEditForm({ ...editForm, parentEmail: e.target.value })} />
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Button variant="secondary" onClick={() => setEditModal(false)}>Cancel</Button>
              <Button type="submit" loading={saving}>Save Changes</Button>
            </div>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  );
}
