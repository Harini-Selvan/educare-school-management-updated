import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import StatCard from '../../components/common/StatCard';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { authAPI, studentAPI, classAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, students: 0, classes: 0, teachers: 0 });
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [u, s, c, t] = await Promise.all([
          authAPI.getUsers(),
          studentAPI.getAll(),
          classAPI.getAll(),
          classAPI.getTeachers(),
        ]);
        if (!cancelled) {
          setUsers(u.data || []);
          setStats({
            users: u.data?.length || 0,
            students: s.data?.length || 0,
            classes: c.data?.length || 0,
            teachers: t.data?.length || 0,
          });
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const roleCount = (role) => users.filter(u => u.role === role).length;

  // Setup checklist - helps admin understand what to do
  const setupSteps = [
    { label: 'Create Classes (e.g. 7A, 8B)', done: stats.classes > 0, link: '/admin/classes' },
    { label: 'Add Teacher Profiles', done: stats.teachers > 0, link: '/admin/teachers' },
    { label: 'Assign Teachers to Classes', done: false, link: '/admin/teachers' },
    { label: 'Register Students (auto-enrolls)', done: stats.students > 0, link: '/admin/students' },
  ];

  return (
    <DashboardLayout title="Admin Dashboard">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard title="Total Users" value={loading ? '...' : stats.users} icon="👥" color="var(--primary)" />
        <StatCard title="Students" value={loading ? '...' : stats.students} icon="🎓" color="var(--success)" />
        <StatCard title="Classes" value={loading ? '...' : stats.classes} icon="🏫" color="var(--warning)" />
        <StatCard title="Teachers" value={loading ? '...' : stats.teachers} icon="👨‍🏫" color="var(--purple)" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Recent Users */}
        <Card title="Recent Users" extra={<Button size="sm" onClick={() => navigate('/admin/users')}>Manage Users</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           users.slice(0, 8).map(u => (
            <div key={u.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--primary-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: 'var(--primary)' }}>
                  {u.name?.charAt(0)}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{u.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <Badge text={u.role} />
                <Badge text={u.status} />
              </div>
            </div>
          ))}
          {users.length === 0 && !loading && <p style={{ color: 'var(--text-muted)', fontSize: 13, padding: '12px 0' }}>No users registered yet.</p>}
        </Card>

        {/* User Distribution */}
        <Card title="User Distribution">
          {['ADMIN', 'TEACHER', 'STUDENT', 'PARENT', 'EXAM_COORDINATOR', 'AUDITOR'].map(role => (
            <div key={role} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <Badge text={role} />
              <span style={{ fontSize: 20, fontWeight: 800 }}>{roleCount(role)}</span>
            </div>
          ))}
        </Card>
      </div>

      {/* Setup Checklist */}
      <Card title="System Setup Checklist" subtitle="Complete these steps to get the system running">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 10 }}>
          {setupSteps.map((step, i) => (
            <div key={i} onClick={() => navigate(step.link)} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', borderRadius: 8, border: `1px solid ${step.done ? '#bbf7d0' : '#fde68a'}`, background: step.done ? '#f0fdf4' : '#fffbeb', cursor: 'pointer', transition: 'transform 0.1s' }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-1px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}>
              <span style={{ fontSize: 20 }}>{step.done ? '✅' : '⭕'}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: step.done ? '#065f46' : '#92400e' }}>{i + 1}. {step.label}</div>
                <div style={{ fontSize: 11, color: step.done ? '#059669' : '#d97706' }}>{step.done ? 'Done' : 'Click to go there →'}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 14, padding: '10px 14px', background: '#eff6ff', borderRadius: 8, border: '1px solid #bfdbfe', fontSize: 12, color: '#1e40af' }}>
          💡 <strong>Important order:</strong> Create class → Add teacher → Assign teacher to class → Register student (select class during registration to auto-enroll).
        </div>
      </Card>
    </DashboardLayout>
  );
}
