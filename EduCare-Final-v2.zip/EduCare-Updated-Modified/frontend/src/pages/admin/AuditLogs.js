import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import { authAPI } from '../../services/api';

export default function AdminAuditLogs() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await authAPI.getAuditLogs();
        if (!cancelled) setLogs(r.data || []);
      } catch (err) { /* ignore */ }
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const columns = [
    { title: 'User ID', key: 'userId' },
    { title: 'Action', key: 'action', render: v => <span style={{ fontWeight: 600, color: 'var(--primary)' }}>{v}</span> },
    { title: 'Resource Type', key: 'resourceType' },
    { title: 'Resource ID', key: 'resourceId' },
    { title: 'Details', key: 'details', render: v => <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{v}</span> },
    { title: 'Timestamp', key: 'timestamp', render: v => v ? new Date(v).toLocaleString() : '-' },
  ];

  return (
    <DashboardLayout title="Audit Logs">
      <Card title="System Audit Logs" subtitle={logs.length + " log entries"}>
        <Table columns={columns} data={logs} loading={loading} />
      </Card>
    </DashboardLayout>
  );
}
