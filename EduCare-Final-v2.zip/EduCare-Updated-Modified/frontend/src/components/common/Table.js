import React from 'react';

export default function Table({ columns, data, loading, emptyText = 'No data found' }) {
  if (loading) return (
    <div style={{ padding: '40px', textAlign: 'center' }}>
      <div style={{ width: 28, height: 28, border: '3px solid #e2e8f0', borderTopColor: '#1e40af', borderRadius: '50%', animation: 'spin 0.7s linear infinite', margin: '0 auto 12px' }} />
      <p style={{ fontSize: 13, color: '#94a3b8' }}>Loading data...</p>
    </div>
  );

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
        <thead>
          <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
            {columns.map((col, i) => (
              <th key={i} style={{
                padding: '10px 16px',
                textAlign: 'left',
                fontSize: 11,
                fontWeight: 700,
                color: '#64748b',
                textTransform: 'uppercase',
                letterSpacing: '0.6px',
                whiteSpace: 'nowrap',
              }}>
                {col.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {!data?.length ? (
            <tr>
              <td colSpan={columns.length} style={{ padding: '40px 16px', textAlign: 'center', color: '#94a3b8', fontSize: 13 }}>
                <div style={{ fontSize: 24, marginBottom: 8 }}>📭</div>
                {emptyText}
              </td>
            </tr>
          ) : data.map((row, i) => (
            <tr
              key={i}
              style={{ borderBottom: '1px solid #f1f5f9', transition: 'background 0.1s' }}
              onMouseEnter={e => e.currentTarget.style.background = '#fafafa'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              {columns.map((col, j) => (
                <td key={j} style={{ padding: '11px 16px', color: '#334155', verticalAlign: 'middle' }}>
                  {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
