import React from 'react';

export default function Card({ children, title, subtitle, extra, style = {}, bodyStyle = {}, noPadding }) {
  return (
    <div style={{
      background: '#fff',
      border: '1px solid #e2e8f0',
      borderRadius: 10,
      boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
      overflow: 'hidden',
      ...style,
    }}>
      {(title || extra) && (
        <div style={{
          padding: '14px 20px',
          borderBottom: '1px solid #f1f5f9',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: '#fff',
        }}>
          <div>
            {title && <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', letterSpacing: '-0.2px' }}>{title}</h3>}
            {subtitle && <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>{subtitle}</p>}
          </div>
          {extra && <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{extra}</div>}
        </div>
      )}
      <div style={{ padding: noPadding ? 0 : '20px', ...bodyStyle }}>
        {children}
      </div>
    </div>
  );
}
