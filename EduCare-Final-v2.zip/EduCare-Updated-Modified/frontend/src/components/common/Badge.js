import React from 'react';

const map = {
  ACTIVE:           { bg: '#d1fae5', color: '#065f46' },
  INACTIVE:         { bg: '#f1f5f9', color: '#475569' },
  SUSPENDED:        { bg: '#fee2e2', color: '#991b1b' },
  GRADUATED:        { bg: '#ede9fe', color: '#5b21b6' },
  PENDING:          { bg: '#fef3c7', color: '#78350f' },
  PRESENT:          { bg: '#d1fae5', color: '#065f46' },
  ABSENT:           { bg: '#fee2e2', color: '#991b1b' },
  LATE:             { bg: '#fef3c7', color: '#78350f' },
  EXCUSED:          { bg: '#e0e7ff', color: '#3730a3' },
  SUBMITTED:        { bg: '#dbeafe', color: '#1e40af' },
  MODERATED:        { bg: '#fef3c7', color: '#78350f' },
  FINAL:            { bg: '#d1fae5', color: '#065f46' },
  SCHEDULED:        { bg: '#dbeafe', color: '#1e40af' },
  ONGOING:          { bg: '#fef3c7', color: '#78350f' },
  COMPLETED:        { bg: '#d1fae5', color: '#065f46' },
  CANCELLED:        { bg: '#fee2e2', color: '#991b1b' },
  APPROVED:         { bg: '#d1fae5', color: '#065f46' },
  REJECTED:         { bg: '#fee2e2', color: '#991b1b' },
  DROPPED:          { bg: '#fee2e2', color: '#991b1b' },
  IN_PROGRESS:      { bg: '#cffafe', color: '#164e63' },
  ADMIN:            { bg: '#dbeafe', color: '#1e40af' },
  TEACHER:          { bg: '#d1fae5', color: '#065f46' },
  STUDENT:          { bg: '#fef3c7', color: '#78350f' },
  PARENT:           { bg: '#ede9fe', color: '#5b21b6' },
  EXAM_COORDINATOR: { bg: '#cffafe', color: '#164e63' },
  AUDITOR:          { bg: '#f1f5f9', color: '#334155' },
  ATTENDANCE:       { bg: '#d1fae5', color: '#065f46' },
  GRADE:            { bg: '#dbeafe', color: '#1e40af' },
  EVENT:            { bg: '#ede9fe', color: '#5b21b6' },
  GENERAL:          { bg: '#f1f5f9', color: '#334155' },
  UNREAD:           { bg: '#dbeafe', color: '#1e40af' },
  READ:             { bg: '#f1f5f9', color: '#64748b' },
};

export default function Badge({ text }) {
  const s = map[text] || { bg: '#f1f5f9', color: '#475569' };
  return (
    <span style={{
      background: s.bg, color: s.color,
      padding: '3px 9px',
      borderRadius: 5,
      fontSize: 11,
      fontWeight: 700,
      display: 'inline-block',
      whiteSpace: 'nowrap',
      letterSpacing: '0.2px',
    }}>
      {text?.replace('_', ' ')}
    </span>
  );
}
