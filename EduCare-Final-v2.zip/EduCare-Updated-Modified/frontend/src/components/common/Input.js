import React from 'react';

export default function Input({ label, error, style = {}, hint, ...props }) {
  return (
    <div style={{ marginBottom: 16, ...style }}>
      {label && (
        <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
          {label}
        </label>
      )}
      <input
        {...props}
        style={{
          width: '100%', padding: '9px 13px',
          border: `1.5px solid ${error ? '#dc2626' : '#e2e8f0'}`,
          borderRadius: 7, fontSize: 14,
          background: '#f8fafc', color: '#0f172a',
          outline: 'none', transition: 'border-color 0.12s, background 0.12s',
          boxSizing: 'border-box',
        }}
        onFocus={e => { e.target.style.borderColor = '#1e40af'; e.target.style.background = '#fff'; }}
        onBlur={e => { e.target.style.borderColor = error ? '#dc2626' : '#e2e8f0'; e.target.style.background = '#f8fafc'; }}
      />
      {hint && <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>{hint}</p>}
      {error && <p style={{ fontSize: 12, color: '#dc2626', marginTop: 4, fontWeight: 500 }}>{error}</p>}
    </div>
  );
}
