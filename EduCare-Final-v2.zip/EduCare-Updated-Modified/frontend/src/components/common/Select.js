import React from 'react';

export default function Select({ label, options = [], error, placeholder, style = {}, ...props }) {
  return (
    <div style={{ marginBottom: 16, ...style }}>
      {label && (
        <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
          {label}
        </label>
      )}
      <select
        {...props}
        style={{
          width: '100%', padding: '9px 13px',
          border: `1.5px solid ${error ? '#dc2626' : '#e2e8f0'}`,
          borderRadius: 7, fontSize: 14,
          background: '#f8fafc', color: '#0f172a',
          outline: 'none', cursor: 'pointer',
          boxSizing: 'border-box', transition: 'border-color 0.12s',
        }}
        onFocus={e => e.target.style.borderColor = '#1e40af'}
        onBlur={e => e.target.style.borderColor = error ? '#dc2626' : '#e2e8f0'}
      >
        {/* Only render placeholder if explicitly passed — no default "Select..." */}
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
      </select>
      {error && <p style={{ fontSize: 12, color: '#dc2626', marginTop: 4, fontWeight: 500 }}>{error}</p>}
    </div>
  );
}
