import React from 'react';

const variants = {
  primary:   { bg: '#1e40af', color: '#fff',     border: 'none',                       hover: '#1d4ed8' },
  secondary: { bg: '#f1f5f9', color: '#334155',  border: '1px solid #e2e8f0',          hover: '#e2e8f0' },
  danger:    { bg: '#dc2626', color: '#fff',     border: 'none',                       hover: '#b91c1c' },
  success:   { bg: '#059669', color: '#fff',     border: 'none',                       hover: '#047857' },
  ghost:     { bg: 'transparent', color: '#1e40af', border: '1px solid #1e40af30',     hover: '#eff6ff' },
  warning:   { bg: '#d97706', color: '#fff',     border: 'none',                       hover: '#b45309' },
};

const sizes = {
  sm: { padding: '5px 12px', fontSize: '12px', height: '30px' },
  md: { padding: '8px 18px', fontSize: '14px', height: '38px' },
  lg: { padding: '11px 24px', fontSize: '15px', height: '44px' },
};

export default function Button({ children, variant = 'primary', size = 'md', loading, disabled, onClick, type = 'button', style = {} }) {
  const v = variants[variant];
  const s = sizes[size];
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      style={{
        background: v.bg, color: v.color, border: v.border,
        ...s,
        borderRadius: 7,
        fontFamily: 'Outfit, sans-serif',
        fontWeight: 600,
        cursor: disabled || loading ? 'not-allowed' : 'pointer',
        opacity: disabled || loading ? 0.55 : 1,
        transition: 'all 0.12s ease',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '7px',
        whiteSpace: 'nowrap',
        ...style,
      }}
      onMouseEnter={e => { if (!disabled && !loading) e.currentTarget.style.background = v.hover; }}
      onMouseLeave={e => { if (!disabled && !loading) e.currentTarget.style.background = v.bg; }}
    >
      {loading && <span style={{ width: 13, height: 13, border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block', opacity: 0.7 }} />}
      {children}
    </button>
  );
}
