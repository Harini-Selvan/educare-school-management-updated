import React, { useEffect } from 'react';

const cfg = {
  success: { icon: '✓', bg: '#f0fdf4', border: '#bbf7d0', color: '#166534', iconBg: '#dcfce7' },
  error:   { icon: '✕', bg: '#fef2f2', border: '#fecaca', color: '#991b1b', iconBg: '#fee2e2' },
  info:    { icon: 'i', bg: '#eff6ff', border: '#bfdbfe', color: '#1e40af', iconBg: '#dbeafe' },
  warning: { icon: '!', bg: '#fffbeb', border: '#fde68a', color: '#78350f', iconBg: '#fef3c7' },
};

export default function Toast({ message, type = 'success', onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  const c = cfg[type];
  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
      background: c.bg,
      border: `1px solid ${c.border}`,
      borderRadius: 10,
      padding: '14px 16px',
      boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
      display: 'flex', alignItems: 'flex-start', gap: 12,
      animation: 'fadeIn 0.2s ease',
      minWidth: 280, maxWidth: 380,
    }}>
      <div style={{ width: 28, height: 28, borderRadius: 7, background: c.iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 800, color: c.color, flexShrink: 0 }}>
        {c.icon}
      </div>
      <div style={{ flex: 1, paddingTop: 2 }}>
        <p style={{ fontSize: 13, color: c.color, fontWeight: 600, lineHeight: 1.4 }}>{message}</p>
      </div>
      <button onClick={onClose} style={{ background: 'none', border: 'none', color: c.color, cursor: 'pointer', fontSize: 16, opacity: 0.6, padding: 0, lineHeight: 1 }}>×</button>
    </div>
  );
}
