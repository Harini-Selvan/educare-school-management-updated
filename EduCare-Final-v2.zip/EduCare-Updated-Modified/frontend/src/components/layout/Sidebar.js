import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const menuConfig = {
  ADMIN: {
    color: '#1e40af', bg: '#eff6ff',
    items: [
      { path: '/admin',              icon: '▪', label: 'Dashboard' },
      { path: '/admin/users',        icon: '▪', label: 'Registered Users' },
      { path: '/admin/classes',      icon: '▪', label: 'Classes' },
      { path: '/admin/teachers',     icon: '▪', label: 'Teachers' },
      { path: '/admin/students',     icon: '▪', label: 'Students' },
      { path: '/admin/enrollments',   icon: '▪', label: 'Enrollments' },
      { path: '/admin/tasks',        icon: '▪', label: 'Tasks' },
      { path: '/admin/profile',       icon: '▪', label: 'My Profile' },
    ]
  },
  TEACHER: {
    color: '#059669', bg: '#d1fae5',
    items: [
      { path: '/teacher',                icon: '▪', label: 'Dashboard' },
      { path: '/teacher/students',       icon: '▪', label: 'My Students' },
      { path: '/teacher/timetable',      icon: '▪', label: 'Timetable' },
      { path: '/teacher/attendance',     icon: '▪', label: 'Attendance' },
      { path: '/teacher/grades',         icon: '▪', label: 'Grades' },
      { path: '/teacher/messages',       icon: '▪', label: 'Messages' },
      { path: '/teacher/tasks',          icon: '▪', label: 'My Tasks' },
      { path: '/teacher/grade-requests',   icon: '▪', label: 'Grade Requests' },
    ]
  },
  STUDENT: {
    color: '#d97706', bg: '#fef3c7',
    items: [
      { path: '/student',                icon: '▪', label: 'Dashboard' },
      { path: '/student/profile',        icon: '▪', label: 'My Profile' },
      { path: '/student/attendance',     icon: '▪', label: 'My Attendance' },
      { path: '/student/timetable',      icon: '▪', label: 'Timetable' },
      { path: '/student/grades',         icon: '▪', label: 'My Grades' },
    ]
  },
  PARENT: {
    color: '#7c3aed', bg: '#ede9fe',
    items: [
      { path: '/parent',                icon: '▪', label: 'Dashboard' },
      { path: '/parent/attendance',     icon: '▪', label: 'Attendance' },
      { path: '/parent/grades',         icon: '▪', label: 'Grades' },
      { path: '/parent/messages',       icon: '▪', label: 'Messages' },
    ]
  },
  EXAM_COORDINATOR: {
    color: '#0891b2', bg: '#cffafe',
    items: [
      { path: '/coordinator',              icon: '▪', label: 'Dashboard' },
      { path: '/coordinator/exams',        icon: '▪', label: 'Exam Schedule' },
      { path: '/coordinator/tasks',        icon: '▪', label: 'My Tasks' },
      { path: '/coordinator/grade-requests', icon: '▪', label: 'Grade Requests' },
    ]
  },
  AUDITOR: {
    color: '#475569', bg: '#f1f5f9',
    items: [
      { path: '/auditor',           icon: '▪', label: 'Dashboard' },
      { path: '/auditor/audit-logs',icon: '▪', label: 'Audit Logs' },
    ]
  },
};

const roleLabels = {
  ADMIN: 'Administrator', TEACHER: 'Teacher', STUDENT: 'Student',
  PARENT: 'Parent', EXAM_COORDINATOR: 'Exam Coordinator', AUDITOR: 'Auditor',
};

export default function Sidebar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const config = menuConfig[user?.role] || menuConfig.ADMIN;
  const { color, items } = config;

  const isActive = (path) => {
    const base = `/${user?.role?.toLowerCase().replace('exam_coordinator', 'coordinator')}`;
    if (path === base) return location.pathname === path;
    return location.pathname.startsWith(path);
  };

  return (
    <aside style={{ width: 'var(--sidebar-width)', height: '100vh', position: 'fixed', left: 0, top: 0, background: 'var(--surface)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', zIndex: 100 }}>
      {/* Brand */}
      <div style={{ padding: '20px 20px 16px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, color: '#fff', fontWeight: 700 }}>E</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.3px' }}>EduCare</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 500 }}>School Management</div>
          </div>
        </div>
        <div style={{ background: color + '15', border: `1px solid ${color}30`, borderRadius: 6, padding: '6px 10px', fontSize: 11, fontWeight: 600, color, letterSpacing: '0.3px', textTransform: 'uppercase' }}>
          {roleLabels[user?.role]}
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, padding: '10px 8px', overflowY: 'auto' }}>
        {items.map(item => {
          const active = isActive(item.path);
          return (
            <button key={item.path} onClick={() => navigate(item.path)}
              style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', marginBottom: 2, background: active ? color + '12' : 'transparent', border: 'none', borderRadius: 7, cursor: 'pointer', textAlign: 'left', color: active ? color : 'var(--text-secondary)', fontWeight: active ? 600 : 400, fontSize: 14, transition: 'all 0.12s ease' }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--surface2)'; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: active ? color : 'var(--border-dark)', flexShrink: 0, transition: 'background 0.12s' }} />
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* User Info */}
      <div style={{ padding: '12px 12px 16px', borderTop: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 8px' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: color + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color, flexShrink: 0 }}>
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
          <div style={{ overflow: 'hidden', flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.name}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.email}</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
