import React, { useState, useEffect, useRef } from 'react';
import { notificationAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const roleProfilePaths = {
  ADMIN: '/admin/profile', TEACHER: '/teacher', STUDENT: '/student/profile',
  PARENT: '/parent', EXAM_COORDINATOR: '/coordinator', AUDITOR: '/auditor',
};

const roleColors = {
  ADMIN: '#1e40af', TEACHER: '#059669', STUDENT: '#d97706',
  PARENT: '#7c3aed', EXAM_COORDINATOR: '#0891b2', AUDITOR: '#475569',
};

export default function Header({ title }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [showNotif, setShowNotif] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const notifRef = useRef(null);
  const profileRef = useRef(null);

  useEffect(() => {
    notificationAPI.getMy().then(r => setNotifications(r.data || [])).catch(() => {});
  }, []);

  useEffect(() => {
    function handleClickOutside(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) setShowNotif(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setShowProfile(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unread = notifications.filter(n => n.status === 'UNREAD').length;
  const markRead = id => {
    notificationAPI.markRead(id).then(() => setNotifications(prev => prev.map(n => n.id === id ? { ...n, status: 'READ' } : n))).catch(() => {});
  };
  const accentColor = roleColors[user?.role] || '#1e40af';

  return (
    <header style={{ height: 'var(--header-height)', background: 'var(--surface)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', position: 'sticky', top: 0, zIndex: 50 }}>
      <h1 style={{ fontSize: 17, fontWeight: 700, color: 'var(--text)', letterSpacing: '-0.2px' }}>{title}</h1>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>

        {/* Notification Bell */}
        <div ref={notifRef} style={{ position: 'relative' }}>
          <button onClick={() => { setShowNotif(p => !p); setShowProfile(false); }}
            style={{ position: 'relative', width: 36, height: 36, background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, transition: 'all 0.12s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--surface3)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--surface2)'}>
            🔔
            {unread > 0 && (
              <span style={{ position: 'absolute', top: -4, right: -4, background: 'var(--danger)', color: '#fff', borderRadius: '50%', width: 17, height: 17, fontSize: 10, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid var(--surface)' }}>
                {unread > 9 ? '9+' : unread}
              </span>
            )}
          </button>

          {showNotif && (
            <div style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, boxShadow: '0 10px 30px rgba(0,0,0,0.12)', width: 340, maxHeight: 420, overflowY: 'auto', zIndex: 200 }}>
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 14, fontWeight: 700 }}>Notifications</span>
                {unread > 0 && <span style={{ fontSize: 11, background: 'var(--danger-light)', color: 'var(--danger)', padding: '2px 8px', borderRadius: 20, fontWeight: 700 }}>{unread} unread</span>}
              </div>
              {notifications.length === 0 ? (
                <div style={{ padding: '32px 16px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}><div style={{ fontSize: 28, marginBottom: 8 }}>🔔</div>No notifications yet</div>
              ) : notifications.slice(0, 15).map(n => (
                <div key={n.id} onClick={() => n.status === 'UNREAD' && markRead(n.id)}
                  style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', background: n.status === 'UNREAD' ? 'var(--primary-light)' : 'transparent', cursor: n.status === 'UNREAD' ? 'pointer' : 'default' }}>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 3 }}>
                    <span style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: 'var(--primary)', background: 'var(--primary-muted)', padding: '1px 6px', borderRadius: 4 }}>{n.category}</span>
                    {n.status === 'UNREAD' && <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--danger)' }}>NEW</span>}
                  </div>
                  <p style={{ fontSize: 13, color: 'var(--text)', fontWeight: n.status === 'UNREAD' ? 600 : 400, lineHeight: 1.4 }}>{n.message}</p>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>{n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Profile Dropdown */}
        <div ref={profileRef} style={{ position: 'relative' }}>
          <button onClick={() => { setShowProfile(p => !p); setShowNotif(false); }}
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px 6px 6px', background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 8, cursor: 'pointer', transition: 'all 0.12s' }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--surface3)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--surface2)'}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: accentColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff' }}>
              {user?.name?.charAt(0)?.toUpperCase()}
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', lineHeight: 1.2 }}>{user?.name?.split(' ')[0]}</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 500 }}>{user?.role?.replace('_', ' ')}</div>
            </div>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 2 }}>▾</span>
          </button>

          {showProfile && (
            <div style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, boxShadow: '0 10px 30px rgba(0,0,0,0.12)', width: 240, zIndex: 200, overflow: 'hidden' }}>
              {/* Profile header */}
              <div style={{ padding: '14px 16px', background: accentColor + '10', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: accentColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                    {user?.name?.charAt(0)?.toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>{user?.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{user?.email}</div>
                    <div style={{ fontSize: 11, color: accentColor, fontWeight: 600, marginTop: 2 }}>{user?.role?.replace('_', ' ')}</div>
                  </div>
                </div>
              </div>

              {/* Menu items */}
              <div style={{ padding: '6px' }}>
                <button onClick={() => { setShowProfile(false); navigate(roleProfilePaths[user?.role] || '/'); }}
                  style={{ width: '100%', padding: '10px 12px', background: 'none', border: 'none', borderRadius: 7, cursor: 'pointer', textAlign: 'left', fontSize: 13, fontWeight: 600, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: 8, transition: 'background 0.1s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                  👤 View Profile
                </button>
                <div style={{ height: 1, background: 'var(--border)', margin: '4px 0' }} />
                <button onClick={() => { setShowProfile(false); logout(); }}
                  style={{ width: '100%', padding: '10px 12px', background: 'none', border: 'none', borderRadius: 7, cursor: 'pointer', textAlign: 'left', fontSize: 13, fontWeight: 600, color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: 8, transition: 'background 0.1s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--danger-light)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                  🚪 Sign Out
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
}
