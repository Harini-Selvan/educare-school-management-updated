import axios from 'axios';

const BASE_URL = 'http://localhost:9090';
const api = axios.create({ baseURL: BASE_URL });

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  res => {
    // Auto-log every mutating API call for full audit trail visibility
    const method = (res.config?.method || '').toUpperCase();
    const url = res.config?.url || '';
    // Skip GETs, audit-log calls themselves, and login/register (login is logged server-side)
    const skip = ['GET', 'HEAD', 'OPTIONS'].includes(method)
      || url.includes('/audit-logs')
      || url.includes('/api/auth/login')
      || url.includes('/api/auth/register');

    if (!skip) {
      const userId = Number(localStorage.getItem('userId') || 0);
      const email = localStorage.getItem('email') || '';
      const name = localStorage.getItem('name') || email;
      const role = localStorage.getItem('role') || '';

      if (email) {
        // Non-blocking: fire-and-forget
        api.post('/api/audit-logs', {
          userId,
          userEmail: email,
          performedBy: name,
          action: method + ' ' + url,
          resourceType: (url.split('/')[2] || 'API').toUpperCase(),
          endpoint: url,
          httpMethod: method,
          details: role + ' performed ' + method + ' on ' + url,
        }).catch(() => {}); // silently ignore failures
      }
    }
    return res;
  },
  err => {
    if (err.response?.status === 401 && !window.location.href.includes('/login')) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export const authAPI = {
  login: d => api.post('/api/auth/login', d),
  register: d => api.post('/api/auth/register', d),
  getUsers: () => api.get('/api/users'),
  getUserById: id => api.get(`/api/users/${id}`),
  getUsersByRole: role => api.get(`/api/users/by-role?role=${role}`),
  updateUserStatus: (id, status) => api.patch(`/api/users/${id}/status?status=${status}`),
  createAuditLog: d => api.post('/api/audit-logs', d),
  getAuditLogs: () => api.get('/api/audit-logs'),
  getAuditLogsByUser: id => api.get(`/api/audit-logs/user/${id}`),
};

export const studentAPI = {
  create: d => api.post('/api/students', d),
  getAll: () => api.get('/api/students'),
  getById: id => api.get(`/api/students/${id}`),
  update: (id, d) => api.put(`/api/students/${id}`, d),
  updateStatus: (id, s) => api.patch(`/api/students/${id}/status?status=${s}`),
  getMyProfile: () => api.get('/api/students/my-profile'),
  getMyChildren: () => api.get('/api/students/my-children'),
  registerLink: d => api.post('/api/students/links', d),
  verifyLink: (studentId, email, role) => api.get(`/api/students/links/verify?studentId=${studentId}&email=${email}&role=${role}`),
  enroll: d => api.post('/api/enrollments', d),
  getEnrollmentsByStudent: id => api.get(`/api/enrollments/student/${id}`),
  getEnrollmentsByClass: id => api.get(`/api/enrollments/class/${id}`),
  updateEnrollmentStatus: (id, s) => api.patch(`/api/enrollments/${id}/status?status=${s}`),
};

export const classAPI = {
  create: d => api.post('/api/classes', d),
  getAll: () => api.get('/api/classes'),
  getById: id => api.get(`/api/classes/${id}`),
  update: (id, d) => api.put(`/api/classes/${id}`, d),
  updateStatus: (id, s) => api.patch(`/api/classes/${id}/status?status=${s}`),
  createTeacher: d => api.post('/api/teachers', d),
  getTeachers: () => api.get('/api/teachers'),
  getTeacherById: id => api.get(`/api/teachers/${id}`),
  assign: d => api.post('/api/teacher-assignments', d),
  getAssignmentsByClass: id => api.get(`/api/teacher-assignments/class/${id}`),
  getAssignmentsByTeacher: id => api.get(`/api/teacher-assignments/teacher/${id}`),
};

export const attendanceAPI = {
  record: d => api.post('/api/attendance', d),
  recordBatch: d => api.post('/api/attendance/batch', d),
  update: (id, d) => api.put(`/api/attendance/${id}`, d),
  getByStudent: id => api.get(`/api/attendance/student/${id}`),
  getByClassAndDate: (classId, date) => api.get(`/api/attendance/class/${classId}/date/${date}`),
  getSummary: id => api.get(`/api/attendance/summary/${id}`),
};

export const examAPI = {
  create: d => api.post('/api/exams', d),
  getAll: () => api.get('/api/exams'),
  getByClass: id => api.get(`/api/exams/class/${id}`),
  getById: id => api.get(`/api/exams/${id}`),
  updateStatus: (id, s) => api.patch(`/api/exams/${id}/status?status=${s}`),
  submitGrade: d => api.post('/api/grades', d),
  getGradesByExam: id => api.get(`/api/grades/exam/${id}`),
  getGradesByStudent: id => api.get(`/api/grades/student/${id}`),
  modifyGrade: (id, d) => api.put(`/api/grades/${id}/modify`, d),
  approveGradeChange: id => api.patch(`/api/grades/changes/${id}/approve`),
  getGradeHistory: id => api.get(`/api/grades/${id}/history`),
  raiseGradeRequest: d => api.post('/api/grade-requests', d),
  uploadEvidence: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/api/evidence/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
  },
  getPendingRequests: () => api.get('/api/grade-requests/pending'),
  getMyRequests: () => api.get('/api/grade-requests/my'),
  reviewRequest: (id, d) => api.patch(`/api/grade-requests/${id}/review`, d),
};

export const notificationAPI = {
  create: d => api.post('/api/notifications', d),
  getMy: () => api.get('/api/notifications/my'),
  markRead: id => api.patch(`/api/notifications/${id}/read`),
  sendMessage: d => api.post('/api/messages', d),
  getInbox: () => api.get('/api/messages/inbox'),
  getSent: () => api.get('/api/messages/sent'),
  createTask: d => api.post('/api/tasks', d),
  getAllTasks: () => api.get('/api/tasks'),
  getMyTasks: () => api.get('/api/tasks/my'),
  updateTaskStatus: (id, s) => api.patch(`/api/tasks/${id}/status?status=${s}`),
  getOverdueTasks: () => api.get('/api/tasks/overdue'),
};

export const reportAPI = {
  generate: d => api.post('/api/reports/generate', d),
  getAll: () => api.get('/api/reports'),
  getById: id => api.get(`/api/reports/${id}`),
  createKpi: d => api.post('/api/kpis', d),
  getKpis: () => api.get('/api/kpis'),
  updateKpiValue: (id, v) => api.patch(`/api/kpis/${id}/value?value=${v}`),
  createAuditPackage: d => api.post('/api/audit/packages', d),
  getAuditPackages: () => api.get('/api/audit/packages'),
};

export default api;
