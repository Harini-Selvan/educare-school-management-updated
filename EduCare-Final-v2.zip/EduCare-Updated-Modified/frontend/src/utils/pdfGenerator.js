// PDF Generator — uses browser's built-in print to PDF
// No external library needed

export function generateReportPDF(report, kpis = []) {
  const content = buildReportHTML(report, kpis);
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  iframe.contentDocument.open();
  iframe.contentDocument.write(content);
  iframe.contentDocument.close();
  setTimeout(() => {
    iframe.contentWindow.focus();
    iframe.contentWindow.print();
    setTimeout(() => document.body.removeChild(iframe), 1000);
  }, 500);
}

export function generateKpiPDF(kpis) {
  const content = buildKpiHTML(kpis);
  printHTML(content);
}

export function generateAuditPackagePDF(pkg) {
  const content = buildPackageHTML(pkg);
  printHTML(content);
}

function printHTML(content) {
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  iframe.contentDocument.open();
  iframe.contentDocument.write(content);
  iframe.contentDocument.close();
  setTimeout(() => {
    iframe.contentWindow.focus();
    iframe.contentWindow.print();
    setTimeout(() => document.body.removeChild(iframe), 1000);
  }, 500);
}

function buildReportHTML(report, kpis) {
  const params = (() => {
    try { return JSON.stringify(JSON.parse(report.parametersJson || '{}'), null, 2); }
    catch { return report.parametersJson || 'N/A'; }
  })();

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>EduCare Report — ${report.scope}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; padding: 40px; font-size: 14px; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 2px solid #1e40af; }
    .brand { display: flex; flex-direction: column; }
    .brand-name { font-size: 26px; font-weight: 800; color: #1e40af; letter-spacing: -0.5px; }
    .brand-sub { font-size: 11px; color: #64748b; font-weight: 500; text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }
    .report-meta { text-align: right; }
    .report-title { font-size: 20px; font-weight: 700; color: #0f172a; }
    .report-date { font-size: 12px; color: #64748b; margin-top: 4px; }
    .section { margin-bottom: 28px; }
    .section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: #64748b; margin-bottom: 12px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .info-row { display: flex; flex-direction: column; background: #f8fafc; border-radius: 6px; padding: 10px 14px; }
    .info-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #94a3b8; margin-bottom: 3px; }
    .info-value { font-size: 14px; font-weight: 600; color: #0f172a; }
    .badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; background: #dbeafe; color: #1e40af; }
    .params-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; font-family: 'Courier New', monospace; font-size: 12px; white-space: pre-wrap; color: #334155; }
    .kpi-table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    .kpi-table th { background: #1e40af; color: #fff; padding: 10px 14px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    .kpi-table td { padding: 10px 14px; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
    .kpi-table tr:nth-child(even) td { background: #f8fafc; }
    .progress-bar { background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden; }
    .progress-fill { height: 100%; border-radius: 4px; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; }
    @media print {
      body { padding: 20px; }
      @page { margin: 15mm; size: A4; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="brand">
      <div class="brand-name">EduCare</div>
      <div class="brand-sub">School Management System</div>
    </div>
    <div class="report-meta">
      <div class="report-title">${report.scope} Report</div>
      <div class="report-date">Generated: ${report.generatedAt ? new Date(report.generatedAt).toLocaleString() : new Date().toLocaleString()}</div>
      <div class="report-date" style="margin-top:4px">By: ${report.generatedBy}</div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Report Details</div>
    <div class="info-grid">
      <div class="info-row">
        <span class="info-label">Report ID</span>
        <span class="info-value">#${report.id}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Scope</span>
        <span class="info-value"><span class="badge">${report.scope}</span></span>
      </div>
      <div class="info-row">
        <span class="info-label">Generated By</span>
        <span class="info-value">${report.generatedBy}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Generated At</span>
        <span class="info-value">${report.generatedAt ? new Date(report.generatedAt).toLocaleString() : 'N/A'}</span>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Report Parameters</div>
    <div class="params-box">${params}</div>
  </div>

  ${kpis.length > 0 ? `
  <div class="section">
    <div class="section-title">KPI Summary</div>
    <table class="kpi-table">
      <thead>
        <tr><th>KPI Name</th><th>Current Value</th><th>Target</th><th>Progress</th><th>Period</th></tr>
      </thead>
      <tbody>
        ${kpis.map(k => `
        <tr>
          <td><strong>${k.name}</strong><br><span style="font-size:11px;color:#64748b">${k.definition || ''}</span></td>
          <td style="color:${k.currentValue >= k.target ? '#059669' : '#dc2626'};font-weight:700;font-size:16px">${k.currentValue}%</td>
          <td>${k.target}%</td>
          <td style="min-width:100px">
            <div class="progress-bar">
              <div class="progress-fill" style="width:${Math.min((k.currentValue/k.target)*100,100)}%;background:${k.currentValue >= k.target ? '#059669' : '#1e40af'}"></div>
            </div>
            <span style="font-size:11px;color:#64748b">${Math.round((k.currentValue/k.target)*100)}% of target</span>
          </td>
          <td>${k.reportingPeriod || '-'}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>` : ''}

  <div class="footer">
    <span>EduCare School Management System — Confidential</span>
    <span>Report ID: #${report.id} | ${report.scope} | ${new Date().toLocaleDateString()}</span>
  </div>
</body>
</html>`;
}

function buildKpiHTML(kpis) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>EduCare KPI Report</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; padding: 40px; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 2px solid #1e40af; }
    .brand-name { font-size: 26px; font-weight: 800; color: #1e40af; }
    .brand-sub { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; }
    .report-title { font-size: 20px; font-weight: 700; text-align: right; }
    .report-date { font-size: 12px; color: #64748b; text-align: right; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th { background: #1e40af; color: #fff; padding: 12px 16px; text-align: left; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    td { padding: 12px 16px; border-bottom: 1px solid #f1f5f9; font-size: 13px; vertical-align: middle; }
    tr:nth-child(even) td { background: #f8fafc; }
    .progress-bar { background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden; }
    .progress-fill { height: 100%; border-radius: 4px; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; }
    @media print { @page { margin: 15mm; size: A4; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="brand-name">EduCare</div>
      <div class="brand-sub">School Management System</div>
    </div>
    <div>
      <div class="report-title">KPI Performance Report</div>
      <div class="report-date">Generated: ${new Date().toLocaleString()}</div>
    </div>
  </div>
  <table>
    <thead>
      <tr><th>KPI Name</th><th>Definition</th><th>Current</th><th>Target</th><th>Progress</th><th>Period</th></tr>
    </thead>
    <tbody>
      ${kpis.map(k => `
      <tr>
        <td><strong>${k.name}</strong></td>
        <td style="font-size:12px;color:#64748b">${k.definition || '-'}</td>
        <td style="color:${k.currentValue >= k.target ? '#059669' : '#dc2626'};font-weight:800;font-size:18px">${k.currentValue}%</td>
        <td>${k.target}%</td>
        <td style="min-width:120px">
          <div class="progress-bar">
            <div class="progress-fill" style="width:${Math.min((k.currentValue/k.target)*100,100)}%;background:${k.currentValue >= k.target ? '#059669' : '#1e40af'}"></div>
          </div>
          <span style="font-size:11px;color:#64748b">${Math.round((k.currentValue/k.target)*100)}%</span>
        </td>
        <td>${k.reportingPeriod || '-'}</td>
      </tr>`).join('')}
    </tbody>
  </table>
  <div class="footer">
    <span>EduCare — Confidential</span>
    <span>KPI Report | ${new Date().toLocaleDateString()}</span>
  </div>
</body>
</html>`;
}

function buildPackageHTML(pkg) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>EduCare Audit Package</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; padding: 40px; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 2px solid #475569; }
    .brand-name { font-size: 26px; font-weight: 800; color: #475569; }
    .brand-sub { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px; }
    .section { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
    .section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; color: #64748b; margin-bottom: 12px; }
    .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
    .info-row:last-child { border-bottom: none; }
    .label { color: #64748b; font-weight: 500; }
    .value { font-weight: 700; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; }
    @media print { @page { margin: 15mm; size: A4; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <div class="brand-name">EduCare</div>
      <div class="brand-sub">School Management System</div>
    </div>
    <div style="text-align:right">
      <div style="font-size:20px;font-weight:700">Audit Package</div>
      <div style="font-size:12px;color:#64748b;margin-top:4px">${new Date().toLocaleString()}</div>
    </div>
  </div>
  <div class="section">
    <div class="section-title">Package Details</div>
    <div class="info-row"><span class="label">Package ID</span><span class="value">#${pkg.id}</span></div>
    <div class="info-row"><span class="label">Period Start</span><span class="value">${pkg.periodStart}</span></div>
    <div class="info-row"><span class="label">Period End</span><span class="value">${pkg.periodEnd}</span></div>
    <div class="info-row"><span class="label">Generated At</span><span class="value">${pkg.generatedAt ? new Date(pkg.generatedAt).toLocaleString() : 'N/A'}</span></div>
  </div>
  <div class="section">
    <div class="section-title">Contents</div>
    <pre style="font-family:Courier New,monospace;font-size:12px;white-space:pre-wrap;color:#334155">${(() => { try { return JSON.stringify(JSON.parse(pkg.contentsJson || '{}'), null, 2); } catch { return pkg.contentsJson || 'N/A'; } })()}</pre>
  </div>
  <div class="footer">
    <span>EduCare — Confidential Audit Document</span>
    <span>Audit Package #${pkg.id} | ${new Date().toLocaleDateString()}</span>
  </div>
</body>
</html>`;
}
