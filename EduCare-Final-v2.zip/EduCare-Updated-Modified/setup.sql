-- Run this in MySQL before starting the application
CREATE DATABASE IF NOT EXISTS auth_db;
CREATE DATABASE IF NOT EXISTS student_db;
CREATE DATABASE IF NOT EXISTS class_db;
CREATE DATABASE IF NOT EXISTS attendance_db;
CREATE DATABASE IF NOT EXISTS exam_db;
CREATE DATABASE IF NOT EXISTS notification_db;
CREATE DATABASE IF NOT EXISTS report_db;

-- After tables are created by Spring (spring.jpa.hibernate.ddl-auto=update),
-- run this migration to add new columns:

-- Audit log new columns (run after first startup)
ALTER TABLE auth_db.audit_logs 
  ADD COLUMN IF NOT EXISTS user_email VARCHAR(255),
  ADD COLUMN IF NOT EXISTS performed_by VARCHAR(255),
  ADD COLUMN IF NOT EXISTS endpoint VARCHAR(500),
  ADD COLUMN IF NOT EXISTS http_method VARCHAR(10);

-- Classes section column
ALTER TABLE class_db.classes
  ADD COLUMN IF NOT EXISTS section VARCHAR(50);

-- Grades evidenceUri column  
ALTER TABLE exam_db.grades
  ADD COLUMN IF NOT EXISTS evidence_uri VARCHAR(500);


-- Exam duration columns (from/to time)
ALTER TABLE exam_db.exams
  ADD COLUMN IF NOT EXISTS from_time DATETIME,
  ADD COLUMN IF NOT EXISTS to_time DATETIME;

SELECT 'All EduCare databases and schema migrations ready!' AS status;
