package com.educare.classservice.enums;
public enum AssignmentStatus { ACTIVE, INACTIVE }