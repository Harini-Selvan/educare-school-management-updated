package com.educare.classservice.entity;
import com.educare.classservice.enums.TeacherStatus;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "teachers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Teacher {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    private String department;
    private String contactInfo;
    private Long userId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private TeacherStatus status;
}