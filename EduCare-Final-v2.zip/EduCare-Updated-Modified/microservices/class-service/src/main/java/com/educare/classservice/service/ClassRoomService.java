package com.educare.classservice.service;
import com.educare.classservice.dto.request.ClassRoomRequest;
import com.educare.classservice.dto.response.ClassRoomResponse;
import com.educare.classservice.entity.ClassRoom;
import com.educare.classservice.enums.ClassStatus;
import com.educare.classservice.exception.ResourceNotFoundException;
import com.educare.classservice.repository.ClassRoomRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class ClassRoomService {
    private final ClassRoomRepository classRoomRepository;
    public ClassRoomResponse createClass(ClassRoomRequest req) {
        log.info("Creating class: {}", req.getName());
        ClassRoom saved = classRoomRepository.save(ClassRoom.builder()
                .name(req.getName()).section(req.getSection()).gradeLevel(req.getGradeLevel())
                .scheduleJson(req.getScheduleJson()).capacity(req.getCapacity())
                .status(ClassStatus.ACTIVE).build());
        log.info("Class created — id: {}", saved.getId());
        return toResponse(saved);
    }
    public List<ClassRoomResponse> getAllClasses() {
        return classRoomRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }
    public ClassRoomResponse getClassById(Long id) {
        return toResponse(classRoomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + id)));
    }
    public ClassRoomResponse updateClass(Long id, ClassRoomRequest req) {
        ClassRoom c = classRoomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + id));
        c.setName(req.getName()); c.setSection(req.getSection());
        c.setGradeLevel(req.getGradeLevel());
        c.setScheduleJson(req.getScheduleJson()); c.setCapacity(req.getCapacity());
        return toResponse(classRoomRepository.save(c));
    }
    public ClassRoomResponse updateStatus(Long id, ClassStatus status) {
        ClassRoom c = classRoomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + id));
        log.info("Class {} status: {} -> {}", id, c.getStatus(), status);
        c.setStatus(status);
        return toResponse(classRoomRepository.save(c));
    }
    public ClassRoom getClassEntityById(Long id) {
        return classRoomRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Class not found: " + id));
    }
    public ClassRoomResponse toResponse(ClassRoom c) {
        return ClassRoomResponse.builder().id(c.getId()).name(c.getName()).section(c.getSection())
                .gradeLevel(c.getGradeLevel()).scheduleJson(c.getScheduleJson())
                .capacity(c.getCapacity()).status(c.getStatus()).build();
    }
}
