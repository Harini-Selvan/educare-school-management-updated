package com.educare.classservice.service;
import com.educare.classservice.dto.request.TeacherRequest;
import com.educare.classservice.dto.response.TeacherResponse;
import com.educare.classservice.entity.Teacher;
import com.educare.classservice.enums.TeacherStatus;
import com.educare.classservice.exception.ResourceNotFoundException;
import com.educare.classservice.repository.TeacherRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class TeacherService {
    private final TeacherRepository teacherRepository;
    public TeacherResponse createTeacher(TeacherRequest req) {
        Teacher saved = teacherRepository.save(Teacher.builder().name(req.getName())
                .department(req.getDepartment()).contactInfo(req.getContactInfo())
                .userId(req.getUserId()).status(TeacherStatus.ACTIVE).build());
        log.info("Teacher registered — id: {}", saved.getId());
        return toResponse(saved);
    }
    public List<TeacherResponse> getAllTeachers() {
        return teacherRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }
    public TeacherResponse getTeacherById(Long id) {
        return toResponse(teacherRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + id)));
    }
    public TeacherResponse updateStatus(Long id, TeacherStatus status) {
        Teacher t = teacherRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + id));
        t.setStatus(status); return toResponse(teacherRepository.save(t));
    }
    public Teacher getTeacherEntityById(Long id) {
        return teacherRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + id));
    }
    private TeacherResponse toResponse(Teacher t) {
        return TeacherResponse.builder().id(t.getId()).name(t.getName()).department(t.getDepartment())
                .contactInfo(t.getContactInfo()).userId(t.getUserId()).status(t.getStatus()).build();
    }
}