package com.educare.classservice.controller;

import com.educare.classservice.dto.request.AssignmentRequest;
import com.educare.classservice.dto.response.AssignmentResponse;
import com.educare.classservice.enums.AssignmentStatus;
import com.educare.classservice.security.RoleValidator;
import com.educare.classservice.service.TeacherAssignmentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/teacher-assignments")
@RequiredArgsConstructor
public class TeacherAssignmentController {

    private final TeacherAssignmentService assignmentService;
    private final RoleValidator roleValidator;

    // ADMIN only can assign teachers
    @PostMapping
    public ResponseEntity<AssignmentResponse> assign(
            @Valid @RequestBody AssignmentRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(assignmentService.assign(req));
    }

    // ADMIN, TEACHER, AUDITOR can view assignments
    @GetMapping("/teacher/{teacherId}")
    public ResponseEntity<List<AssignmentResponse>> byTeacher(
            @PathVariable Long teacherId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "AUDITOR", "EXAM_COORDINATOR");
        return ResponseEntity.ok(assignmentService.getByTeacher(teacherId));
    }

    @GetMapping("/class/{classId}")
    public ResponseEntity<List<AssignmentResponse>> byClass(
            @PathVariable Long classId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "AUDITOR", "EXAM_COORDINATOR");
        return ResponseEntity.ok(assignmentService.getByClass(classId));
    }

    // ADMIN only can remove assignments
    @PatchMapping("/{id}/status")
    public ResponseEntity<AssignmentResponse> updateStatus(
            @PathVariable Long id, @RequestParam AssignmentStatus status, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(assignmentService.updateStatus(id, status));
    }
}