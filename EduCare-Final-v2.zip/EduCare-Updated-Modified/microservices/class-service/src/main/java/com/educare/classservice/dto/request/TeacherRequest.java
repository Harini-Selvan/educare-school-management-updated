package com.educare.classservice.dto.request;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class TeacherRequest {
    @NotBlank private String name;
    private String department;
    private String contactInfo;
    private Long userId;
}