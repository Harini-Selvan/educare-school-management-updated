package com.educare.classservice.dto.response;
import com.educare.classservice.enums.ClassStatus;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ClassRoomResponse {
    private Long id;
    private String name;
    private String section;
    private String gradeLevel;
    private String scheduleJson;
    private Integer capacity;
    private ClassStatus status;
}
