package com.educare.classservice.repository;
import com.educare.classservice.entity.ClassRoom;
import com.educare.classservice.enums.ClassStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ClassRoomRepository extends JpaRepository<ClassRoom, Long> {
    List<ClassRoom> findByStatus(ClassStatus status);
    List<ClassRoom> findByGradeLevel(String gradeLevel);
}