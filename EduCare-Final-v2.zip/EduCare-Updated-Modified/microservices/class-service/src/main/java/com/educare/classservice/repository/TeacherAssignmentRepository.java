package com.educare.classservice.repository;
import com.educare.classservice.entity.TeacherAssignment;
import com.educare.classservice.enums.AssignmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface TeacherAssignmentRepository extends JpaRepository<TeacherAssignment, Long> {
    List<TeacherAssignment> findByTeacherId(Long teacherId);
    List<TeacherAssignment> findByClassId(Long classId);
    Optional<TeacherAssignment> findByClassIdAndStatus(Long classId, AssignmentStatus status);
    boolean existsByTeacherIdAndClassIdAndStatus(Long teacherId, Long classId, AssignmentStatus status);
}