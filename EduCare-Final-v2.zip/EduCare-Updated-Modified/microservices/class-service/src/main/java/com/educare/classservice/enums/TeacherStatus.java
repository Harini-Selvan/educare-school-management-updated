package com.educare.classservice.enums;
public enum TeacherStatus { ACTIVE, INACTIVE, ON_LEAVE }