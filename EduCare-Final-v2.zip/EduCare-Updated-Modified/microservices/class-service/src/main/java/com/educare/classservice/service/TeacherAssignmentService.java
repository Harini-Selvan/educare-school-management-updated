package com.educare.classservice.service;
import com.educare.classservice.dto.request.AssignmentRequest;
import com.educare.classservice.dto.response.AssignmentResponse;
import com.educare.classservice.entity.TeacherAssignment;
import com.educare.classservice.enums.AssignmentStatus;
import com.educare.classservice.exception.*;
import com.educare.classservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class TeacherAssignmentService {
    private final TeacherAssignmentRepository assignmentRepository;
    private final TeacherRepository teacherRepository;
    private final ClassRoomRepository classRoomRepository;
    public AssignmentResponse assign(AssignmentRequest req) {
        if (!teacherRepository.existsById(req.getTeacherId()))
            throw new ResourceNotFoundException("Teacher not found: " + req.getTeacherId());
        if (!classRoomRepository.existsById(req.getClassId()))
            throw new ResourceNotFoundException("Class not found: " + req.getClassId());
        if (assignmentRepository.existsByTeacherIdAndClassIdAndStatus(req.getTeacherId(), req.getClassId(), AssignmentStatus.ACTIVE))
            throw new BadRequestException("Teacher already assigned to this class");
        TeacherAssignment saved = assignmentRepository.save(TeacherAssignment.builder()
                .teacherId(req.getTeacherId()).classId(req.getClassId())
                .assignedBy(req.getAssignedBy()).status(AssignmentStatus.ACTIVE).build());
        log.info("Teacher {} assigned to class {}", req.getTeacherId(), req.getClassId());
        return toResponse(saved);
    }
    public List<AssignmentResponse> getByTeacher(Long teacherId) {
        return assignmentRepository.findByTeacherId(teacherId).stream().map(this::toResponse).collect(Collectors.toList());
    }
    public List<AssignmentResponse> getByClass(Long classId) {
        return assignmentRepository.findByClassId(classId).stream().map(this::toResponse).collect(Collectors.toList());
    }
    public AssignmentResponse updateStatus(Long id, AssignmentStatus status) {
        TeacherAssignment a = assignmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Assignment not found: " + id));
        a.setStatus(status); return toResponse(assignmentRepository.save(a));
    }
    private AssignmentResponse toResponse(TeacherAssignment a) {
        return AssignmentResponse.builder().id(a.getId()).teacherId(a.getTeacherId()).classId(a.getClassId())
                .assignedBy(a.getAssignedBy()).assignedAt(a.getAssignedAt()).status(a.getStatus()).build();
    }
}