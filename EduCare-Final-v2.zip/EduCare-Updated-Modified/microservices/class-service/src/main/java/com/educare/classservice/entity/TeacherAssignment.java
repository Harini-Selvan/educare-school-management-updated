package com.educare.classservice.entity;
import com.educare.classservice.enums.AssignmentStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Entity @Table(name = "teacher_assignments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TeacherAssignment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long teacherId;
    @Column(nullable = false) private Long classId;
    private String assignedBy;
    @CreationTimestamp private LocalDateTime assignedAt;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private AssignmentStatus status;
}