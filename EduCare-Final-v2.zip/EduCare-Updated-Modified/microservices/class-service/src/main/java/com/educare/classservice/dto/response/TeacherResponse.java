package com.educare.classservice.dto.response;
import com.educare.classservice.enums.TeacherStatus;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TeacherResponse {
    private Long id;
    private String name;
    private String department;
    private String contactInfo;
    private Long userId;
    private TeacherStatus status;
}