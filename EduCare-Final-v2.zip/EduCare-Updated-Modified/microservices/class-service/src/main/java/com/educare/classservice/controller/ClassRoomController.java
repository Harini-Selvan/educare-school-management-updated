package com.educare.classservice.controller;

import com.educare.classservice.dto.request.ClassRoomRequest;
import com.educare.classservice.dto.response.ClassRoomResponse;
import com.educare.classservice.enums.ClassStatus;
import com.educare.classservice.repository.ClassRoomRepository;
import com.educare.classservice.security.RoleValidator;
import com.educare.classservice.service.ClassRoomService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/classes")
@RequiredArgsConstructor
public class ClassRoomController {

    private final ClassRoomService classRoomService;
    private final RoleValidator roleValidator;
    private final ClassRoomRepository classRoomRepository;

    // ADMIN only can create classes
    @PostMapping
    public ResponseEntity<ClassRoomResponse> create(
            @Valid @RequestBody ClassRoomRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(classRoomService.createClass(req));
    }

    // All roles can view classes
    @GetMapping
    public ResponseEntity<List<ClassRoomResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(classRoomService.getAllClasses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClassRoomResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(classRoomService.getClassById(id));
    }

    /**
     * INTERNAL endpoint — called by other microservices via Feign.
     * No role check — only for service-to-service validation.
     * Returns 200 true if exists, 404 if not.
     */
    @GetMapping("/internal/exists/{id}")
    public ResponseEntity<Boolean> existsById(@PathVariable Long id) {
        if (!classRoomRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(true);
    }

    // ADMIN only can update class
    @PutMapping("/{id}")
    public ResponseEntity<ClassRoomResponse> update(
            @PathVariable Long id, @Valid @RequestBody ClassRoomRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(classRoomService.updateClass(id, req));
    }

    // ADMIN only can change class status
    @PatchMapping("/{id}/status")
    public ResponseEntity<ClassRoomResponse> updateStatus(
            @PathVariable Long id, @RequestParam ClassStatus status,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(classRoomService.updateStatus(id, status));
    }
}