package com.educare.classservice.dto.request;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class ClassRoomRequest {
    @NotBlank private String name;
    private String section;
    private String gradeLevel;
    private String scheduleJson;
    private Integer capacity;
}
