package com.educare.classservice.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m){super(m);} }