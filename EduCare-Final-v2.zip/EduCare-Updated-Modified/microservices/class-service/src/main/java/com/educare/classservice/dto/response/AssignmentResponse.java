package com.educare.classservice.dto.response;
import com.educare.classservice.enums.AssignmentStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AssignmentResponse {
    private Long id;
    private Long teacherId;
    private Long classId;
    private String assignedBy;
    private LocalDateTime assignedAt;
    private AssignmentStatus status;
}