package com.educare.classservice.dto.request;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class AssignmentRequest {
    @NotNull private Long teacherId;
    @NotNull private Long classId;
    private String assignedBy;
}