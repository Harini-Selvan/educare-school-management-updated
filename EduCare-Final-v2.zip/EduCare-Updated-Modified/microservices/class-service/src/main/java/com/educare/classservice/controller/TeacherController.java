package com.educare.classservice.controller;

import com.educare.classservice.dto.request.TeacherRequest;
import com.educare.classservice.dto.response.TeacherResponse;
import com.educare.classservice.enums.TeacherStatus;
import com.educare.classservice.security.RoleValidator;
import com.educare.classservice.service.TeacherService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/teachers")
@RequiredArgsConstructor
public class TeacherController {

    private final TeacherService teacherService;
    private final RoleValidator roleValidator;

    // ADMIN only can register teacher profiles
    @PostMapping
    public ResponseEntity<TeacherResponse> create(
            @Valid @RequestBody TeacherRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(teacherService.createTeacher(req));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR can view teachers
    @GetMapping
    public ResponseEntity<List<TeacherResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(teacherService.getAllTeachers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TeacherResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(teacherService.getTeacherById(id));
    }

    // ADMIN only can change teacher status
    @PatchMapping("/{id}/status")
    public ResponseEntity<TeacherResponse> updateStatus(
            @PathVariable Long id, @RequestParam TeacherStatus status, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(teacherService.updateStatus(id, status));
    }
}