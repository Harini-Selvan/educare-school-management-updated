package com.educare.classservice.enums;
public enum ClassStatus { ACTIVE, INACTIVE, ARCHIVED }