package com.educare.classservice.entity;
import com.educare.classservice.enums.ClassStatus;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "classes")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ClassRoom {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    private String section;
    private String gradeLevel;
    @Column(columnDefinition = "TEXT") private String scheduleJson;
    private Integer capacity;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ClassStatus status;
}
