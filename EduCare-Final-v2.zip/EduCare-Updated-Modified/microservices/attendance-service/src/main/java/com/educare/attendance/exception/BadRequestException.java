package com.educare.attendance.exception;
public class BadRequestException extends RuntimeException { public BadRequestException(String m){super(m);} }