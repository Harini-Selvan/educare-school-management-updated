package com.educare.attendance.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.List;
@Data
public class BatchAttendanceRequest {
    @NotNull private Long classId;
    @NotNull private LocalDate date;
    private String recordedBy;
    @NotNull private List<AttendanceRequest> records;
}