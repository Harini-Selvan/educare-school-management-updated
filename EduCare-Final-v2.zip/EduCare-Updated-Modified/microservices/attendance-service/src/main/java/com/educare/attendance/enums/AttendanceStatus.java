package com.educare.attendance.enums;
public enum AttendanceStatus { PRESENT, ABSENT, LATE, EXCUSED }