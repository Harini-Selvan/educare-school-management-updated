package com.educare.attendance.exception;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String m){super(m);} }