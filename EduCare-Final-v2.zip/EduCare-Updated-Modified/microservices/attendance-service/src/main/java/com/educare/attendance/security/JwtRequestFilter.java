package com.educare.attendance.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    @Value("${application.jwt.secret}")
    private String secretKey;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String existingRole = request.getHeader("X-User-Role");
        String existingEmail = request.getHeader("X-User-Email");

        // If BOTH headers already set by gateway, pass through as-is
        if (existingRole != null && !existingRole.isBlank() &&
            existingEmail != null && !existingEmail.isBlank()) {
            filterChain.doFilter(request, response);
            return;
        }

        // Try to extract from JWT token (direct call or missing email header)
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            try {
                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(getSigningKey())
                        .build()
                        .parseClaimsJws(token)
                        .getBody();

                String email = claims.getSubject();
                String role = (String) claims.get("role");

                // Use existing headers if present, otherwise use JWT values
                String finalEmail = (existingEmail != null && !existingEmail.isBlank()) ? existingEmail : email;
                String finalRole = (existingRole != null && !existingRole.isBlank()) ? existingRole : role;

                HeaderAddingRequestWrapper wrappedRequest =
                        new HeaderAddingRequestWrapper(request, finalEmail, finalRole);
                filterChain.doFilter(wrappedRequest, response);
                return;
            } catch (JwtException | IllegalArgumentException e) {
                // Invalid token — pass through, controller will handle
            }
        }

        filterChain.doFilter(request, response);
    }

    private Key getSigningKey() {
        byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
        if (keyBytes.length < 32) {
            byte[] padded = new byte[32];
            System.arraycopy(keyBytes, 0, padded, 0, keyBytes.length);
            return Keys.hmacShaKeyFor(padded);
        }
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
