package com.educare.attendance.repository;
import com.educare.attendance.entity.AttendanceRecord;
import com.educare.attendance.enums.AttendanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {
    List<AttendanceRecord> findByStudentId(Long studentId);
    List<AttendanceRecord> findByClassIdAndDate(Long classId, LocalDate date);
    List<AttendanceRecord> findByStudentIdAndStatus(Long studentId, AttendanceStatus status);
    boolean existsByStudentIdAndClassIdAndDate(Long studentId, Long classId, LocalDate date);
    long countByStudentIdAndStatus(Long studentId, AttendanceStatus status);
    long countByStudentId(Long studentId);
}