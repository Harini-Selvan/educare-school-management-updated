package com.educare.attendance.dto.response;
import com.educare.attendance.enums.AttendanceStatus;
import lombok.*;
import java.time.LocalDate;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AttendanceResponse {
    private Long id;
    private Long studentId;
    private Long classId;
    private LocalDate date;
    private AttendanceStatus status;
    private String recordedBy;
    private String remarks;
}