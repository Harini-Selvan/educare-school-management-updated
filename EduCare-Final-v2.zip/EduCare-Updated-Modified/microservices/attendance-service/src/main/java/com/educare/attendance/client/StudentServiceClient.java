package com.educare.attendance.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "STUDENT-SERVICE")
public interface StudentServiceClient {

    /**
     * Internal endpoint — no auth required.
     * Returns 200 true if exists, 404 if not.
     */
    @GetMapping("/api/students/internal/exists/{id}")
    ResponseEntity<Boolean> existsById(@PathVariable Long id);

    @GetMapping("/api/students/links/verify")
    Boolean isLinkedToStudent(
            @RequestParam Long studentId,
            @RequestParam String email,
            @RequestParam String role);
}