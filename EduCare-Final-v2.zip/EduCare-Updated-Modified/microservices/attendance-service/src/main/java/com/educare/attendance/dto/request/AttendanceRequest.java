package com.educare.attendance.dto.request;
import com.educare.attendance.enums.AttendanceStatus;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
@Data
public class AttendanceRequest {
    @NotNull private Long studentId;
    @NotNull private Long classId;
    @NotNull private LocalDate date;
    @NotNull private AttendanceStatus status;
    private String recordedBy;
    private String remarks;
}