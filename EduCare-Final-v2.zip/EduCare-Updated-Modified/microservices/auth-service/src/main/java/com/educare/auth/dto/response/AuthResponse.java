package com.educare.auth.dto.response;

import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuthResponse {
    private Long id;          // userId — needed by frontend
    private String token;
    private String name;
    private String email;
    private String role;      // String not enum — frontend needs "ADMIN" not Role.ADMIN
    private String status;
    private String message;
}
