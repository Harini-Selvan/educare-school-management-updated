package com.educare.auth.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private Long userId;
    private String userEmail;
    private String performedBy;
    @Column(nullable = false) private String action;
    private String resourceType;
    private Long resourceId;
    @Column(columnDefinition = "TEXT") private String details;
    private String endpoint;
    private String httpMethod;
    @CreationTimestamp private LocalDateTime timestamp;
}
