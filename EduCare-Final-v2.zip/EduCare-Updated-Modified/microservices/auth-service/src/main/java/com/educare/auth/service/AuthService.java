package com.educare.auth.service;

import com.educare.auth.dto.request.*;
import com.educare.auth.dto.response.*;
import com.educare.auth.entity.AuditLog;
import com.educare.auth.entity.User;
import com.educare.auth.enums.UserStatus;
import com.educare.auth.exception.*;
import com.educare.auth.repository.AuditLogRepository;
import com.educare.auth.repository.UserRepository;
import com.educare.auth.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j @Service @RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuditLogRepository auditLogRepository;

    public AuthResponse register(RegisterRequest request) {
        log.info("Registration attempt — email: {}, role: {}", request.getEmail(), request.getRole());
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        User user = User.builder()
                .name(request.getName()).email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone()).role(request.getRole())
                .status(UserStatus.PENDING).build();
        User saved = userRepository.save(user);
        log.info("User registered — id: {}, email: {}", saved.getId(), saved.getEmail());
        return AuthResponse.builder()
                .id(saved.getId())
                .token(null)
                .name(saved.getName())
                .email(saved.getEmail())
                .role(saved.getRole().name())
                .status(saved.getStatus().name())
                .message("Registration successful! Please wait for admin approval before logging in.")
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt — email: {}", request.getEmail());
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));
        if (user.getStatus() == UserStatus.PENDING)
            throw new UnauthorizedException("Account pending admin approval");
        if (user.getStatus() == UserStatus.INACTIVE)
            throw new UnauthorizedException("Account deactivated. Contact admin.");
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword()))
            throw new UnauthorizedException("Invalid email or password");
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        log.info("Login successful — email: {}, role: {}", user.getEmail(), user.getRole());

        // Auto-record login event in audit trail
        try {
            auditLogRepository.save(AuditLog.builder()
                .userId(user.getId())
                .userEmail(user.getEmail())
                .performedBy(user.getName() != null ? user.getName() : user.getEmail())
                .action("LOGIN — " + user.getRole().name())
                .resourceType("AUTH")
                .resourceId(user.getId())
                .details("Successful login. Role: " + user.getRole().name())
                .endpoint("/api/auth/login")
                .httpMethod("POST")
                .build());
        } catch (Exception ex) {
            log.warn("Could not write login audit log: {}", ex.getMessage());
        }

        return AuthResponse.builder()
                .id(user.getId())
                .token(token)
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .status(user.getStatus().name())
                .message("Login successful")
                .build();
    }
}
