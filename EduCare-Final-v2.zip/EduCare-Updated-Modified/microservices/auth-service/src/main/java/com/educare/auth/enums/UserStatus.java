package com.educare.auth.enums;
public enum UserStatus { ACTIVE, PENDING, INACTIVE }
