package com.educare.auth.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditLogResponse {
    private Long id;
    private Long userId;
    private String userEmail;
    private String performedBy;
    private String action;
    private String resourceType;
    private Long resourceId;
    private String details;
    private String endpoint;
    private String httpMethod;
    private LocalDateTime timestamp;
}
