package com.educare.auth.controller;

import com.educare.auth.dto.response.UserResponse;
import com.educare.auth.enums.Role;
import com.educare.auth.enums.UserStatus;
import com.educare.auth.exception.UnauthorizedException;
import com.educare.auth.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    private void requireAnyRole(HttpServletRequest request, String... roles) {
        String role = request.getHeader("X-User-Role");
        if (role == null || role.isBlank()) throw new UnauthorizedException("Missing role — please login");
        for (String r : roles) { if (r.equals(role)) return; }
        throw new UnauthorizedException("Access denied. Required: " + String.join(" or ", roles) + ". Your role: " + role);
    }

    // ADMIN, EXAM_COORDINATOR, TEACHER can view all users
    @GetMapping
    public ResponseEntity<List<UserResponse>> getAll(HttpServletRequest request) {
        requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR", "TEACHER");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getById(@PathVariable Long id, HttpServletRequest request) {
        requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @GetMapping("/by-role")
    public ResponseEntity<List<UserResponse>> getByRole(@RequestParam Role role, HttpServletRequest request) {
        requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR", "TEACHER");
        return ResponseEntity.ok(userService.getUsersByRole(role));
    }

    // ADMIN only can change user status
    @PatchMapping("/{id}/status")
    public ResponseEntity<UserResponse> updateStatus(
            @PathVariable Long id, @RequestParam UserStatus status, HttpServletRequest request) {
        requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(userService.updateStatus(id, status));
    }
}