package com.educare.auth.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditLogRequest {
    @NotNull private Long userId;
    private String userEmail;
    private String performedBy;
    @NotBlank private String action;
    private String resourceType;
    private Long resourceId;
    private String details;
    private String endpoint;
    private String httpMethod;
}
