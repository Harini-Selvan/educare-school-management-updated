package com.educare.auth.controller;

import com.educare.auth.dto.request.AuditLogRequest;
import com.educare.auth.dto.response.AuditLogResponse;
import com.educare.auth.exception.UnauthorizedException;
import com.educare.auth.service.AuditLogService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
@RequiredArgsConstructor
public class AuditLogController {

    private final AuditLogService auditLogService;

    private void requireAnyRole(HttpServletRequest request, String... roles) {
        String role = request.getHeader("X-User-Role");
        if (role == null || role.isBlank()) throw new UnauthorizedException("Missing role — please login");
        for (String r : roles) { if (r.equals(role)) return; }
        throw new UnauthorizedException("Access denied. Required: " + String.join(" or ", roles) + ". Your role: " + role);
    }

    // Only ADMIN and authenticated backend services can create audit logs (AUDITOR cannot POST)
    @PostMapping
    public ResponseEntity<AuditLogResponse> log(
            @Valid @RequestBody AuditLogRequest req, HttpServletRequest request) {
        requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "STUDENT", "PARENT", "AUDITOR");
        return ResponseEntity.ok(auditLogService.log(req));
    }

    // AUDITOR can only GET — enforced here and at gateway level
    @GetMapping
    public ResponseEntity<List<AuditLogResponse>> getAll(HttpServletRequest request) {
        requireAnyRole(request, "AUDITOR", "ADMIN");
        return ResponseEntity.ok(auditLogService.getAll());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<AuditLogResponse>> byUser(
            @PathVariable Long userId, HttpServletRequest request) {
        requireAnyRole(request, "AUDITOR", "ADMIN");
        return ResponseEntity.ok(auditLogService.getByUser(userId));
    }

    @GetMapping("/resource")
    public ResponseEntity<List<AuditLogResponse>> byResource(
            @RequestParam String resourceType, @RequestParam Long resourceId,
            HttpServletRequest request) {
        requireAnyRole(request, "AUDITOR", "ADMIN");
        return ResponseEntity.ok(auditLogService.getByResource(resourceType, resourceId));
    }
}
