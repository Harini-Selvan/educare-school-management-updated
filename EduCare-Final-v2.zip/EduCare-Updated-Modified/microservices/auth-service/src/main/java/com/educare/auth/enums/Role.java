package com.educare.auth.enums;
public enum Role { ADMIN, TEACHER, PARENT, STUDENT, EXAM_COORDINATOR, AUDITOR }
