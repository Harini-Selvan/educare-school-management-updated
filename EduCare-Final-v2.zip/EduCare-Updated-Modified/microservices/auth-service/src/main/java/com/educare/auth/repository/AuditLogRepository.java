package com.educare.auth.repository;

import com.educare.auth.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findByUserId(Long userId);
    List<AuditLog> findByResourceTypeAndResourceId(String resourceType, Long resourceId);
    List<AuditLog> findAllByOrderByTimestampDesc();
}
