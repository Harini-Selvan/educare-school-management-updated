package com.educare.auth.repository;
import com.educare.auth.entity.User;
import com.educare.auth.enums.Role;
import com.educare.auth.enums.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    List<User> findByRole(Role role);
    List<User> findByStatus(UserStatus status);
}
