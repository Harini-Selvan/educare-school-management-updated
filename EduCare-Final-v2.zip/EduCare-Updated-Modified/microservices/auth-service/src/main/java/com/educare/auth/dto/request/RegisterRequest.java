package com.educare.auth.dto.request;
import com.educare.auth.enums.Role;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class RegisterRequest {
    @NotBlank private String name;
    @Email @NotBlank private String email;
    @NotBlank private String password;
    private String phone;
    @NotNull private Role role;
}
