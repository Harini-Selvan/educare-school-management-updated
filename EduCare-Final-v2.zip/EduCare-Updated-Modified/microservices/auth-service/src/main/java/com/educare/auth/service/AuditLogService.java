package com.educare.auth.service;

import com.educare.auth.dto.request.AuditLogRequest;
import com.educare.auth.dto.response.AuditLogResponse;
import com.educare.auth.entity.AuditLog;
import com.educare.auth.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogResponse log(AuditLogRequest req) {
        AuditLog saved = auditLogRepository.save(AuditLog.builder()
                .userId(req.getUserId())
                .userEmail(req.getUserEmail())
                .performedBy(req.getPerformedBy())
                .action(req.getAction())
                .resourceType(req.getResourceType())
                .resourceId(req.getResourceId())
                .details(req.getDetails())
                .endpoint(req.getEndpoint())
                .httpMethod(req.getHttpMethod())
                .build());
        log.info("Audit logged — user: {}, action: {}, endpoint: {} {}", 
                  req.getUserId(), req.getAction(), req.getHttpMethod(), req.getEndpoint());
        return toResponse(saved);
    }

    public List<AuditLogResponse> getByUser(Long userId) {
        return auditLogRepository.findByUserId(userId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<AuditLogResponse> getByResource(String resourceType, Long resourceId) {
        return auditLogRepository.findByResourceTypeAndResourceId(resourceType, resourceId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<AuditLogResponse> getAll() {
        return auditLogRepository.findAllByOrderByTimestampDesc()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private AuditLogResponse toResponse(AuditLog a) {
        return AuditLogResponse.builder()
                .id(a.getId())
                .userId(a.getUserId())
                .userEmail(a.getUserEmail())
                .performedBy(a.getPerformedBy())
                .action(a.getAction())
                .resourceType(a.getResourceType())
                .resourceId(a.getResourceId())
                .details(a.getDetails())
                .endpoint(a.getEndpoint())
                .httpMethod(a.getHttpMethod())
                .timestamp(a.getTimestamp())
                .build();
    }
}
