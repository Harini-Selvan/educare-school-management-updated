package com.educare.auth.config;

import com.educare.auth.entity.User;
import com.educare.auth.enums.Role;
import com.educare.auth.enums.UserStatus;
import com.educare.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Seed default admin if none exists
        if (!userRepository.existsByEmail("admin@educare.com")) {
            User admin = User.builder()
                    .name("EduCare Admin")
                    .email("admin@educare.com")
                    .password(passwordEncoder.encode("admin123"))
                    .role(Role.ADMIN)
                    .status(UserStatus.ACTIVE)
                    .build();
            userRepository.save(admin);
            log.info("Default admin created — email: admin@educare.com, password: admin123");
        }
    }
}
