package com.educare.student.controller;

import com.educare.student.dto.request.StudentRequest;
import com.educare.student.dto.response.StudentResponse;
import com.educare.student.enums.StudentStatus;
import com.educare.student.exception.UnauthorizedException;
import com.educare.student.repository.StudentRepository;
import com.educare.student.security.RoleValidator;
import com.educare.student.service.StudentLinkService;
import com.educare.student.service.StudentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;
    private final RoleValidator roleValidator;
    private final StudentLinkService studentLinkService;
    private final StudentRepository studentRepository;

    // ADMIN only can register students
    @PostMapping
    public ResponseEntity<StudentResponse> register(
            @Valid @RequestBody StudentRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(studentService.registerStudent(req));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR can view all students
    @GetMapping
    public ResponseEntity<List<StudentResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(studentService.getAllStudents());
    }

    /**
     * STUDENT calls this after login to get their own profile + studentId.
     * Email read from JWT — no parameter needed.
     * This solves the userId vs studentId mapping problem.
     */
    @GetMapping("/my-profile")
    public ResponseEntity<StudentResponse> getMyProfile(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "STUDENT");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(studentService.getMyProfile(email));
    }

    /**
     * PARENT calls this after login to get all their children's profiles.
     * Email read from JWT — no parameter needed.
     * Returns list of children linked to this parent.
     */
    @GetMapping("/my-children")
    public ResponseEntity<List<StudentResponse>> getMyChildren(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "PARENT");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(studentService.getMyChildren(email));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR → any student
    // PARENT → only their child, STUDENT → only themselves
    @GetMapping("/{id}")
    public ResponseEntity<StudentResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT",
                "EXAM_COORDINATOR", "AUDITOR");
        checkStudentAccess(request, id);
        return ResponseEntity.ok(studentService.getStudentById(id));
    }

    /**
     * INTERNAL endpoint — called by other microservices via Feign.
     * No role check — only for service-to-service validation.
     */
    @GetMapping("/internal/exists/{id}")
    public ResponseEntity<Boolean> existsById(@PathVariable Long id) {
        if (!studentRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(true);
    }

    // ADMIN only can update student info
    @PutMapping("/{id}")
    public ResponseEntity<StudentResponse> update(
            @PathVariable Long id, @Valid @RequestBody StudentRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(studentService.updateStudent(id, req));
    }

    // ADMIN only can change student status
    @PatchMapping("/{id}/status")
    public ResponseEntity<StudentResponse> updateStatus(
            @PathVariable Long id, @RequestParam StudentStatus status,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(studentService.updateStatus(id, status));
    }

    private void checkStudentAccess(HttpServletRequest request, Long studentId) {
        String role = roleValidator.getRole(request);
        if ("ADMIN".equals(role) || "TEACHER".equals(role) ||
            "EXAM_COORDINATOR".equals(role) || "AUDITOR".equals(role)) return;
        String email = roleValidator.getEmail(request);
        boolean linked = studentLinkService.isLinkedToStudent(studentId, email, role);
        if (!linked) throw new UnauthorizedException(
                "Access denied. You are not linked to student ID: " + studentId);
    }
}