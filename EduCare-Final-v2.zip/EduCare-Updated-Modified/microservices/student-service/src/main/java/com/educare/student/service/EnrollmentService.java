package com.educare.student.service;

import com.educare.student.client.ClassServiceClient;
import com.educare.student.dto.request.EnrollmentRequest;
import com.educare.student.dto.response.EnrollmentResponse;
import com.educare.student.entity.EnrollmentRecord;
import com.educare.student.enums.EnrollmentStatus;
import com.educare.student.exception.BadRequestException;
import com.educare.student.exception.ResourceNotFoundException;
import com.educare.student.repository.EnrollmentRepository;
import com.educare.student.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final ClassServiceClient classServiceClient;

    public EnrollmentResponse enroll(EnrollmentRequest req) {
        // Validate student exists locally (student-service owns this data)
        if (!studentRepository.existsById(req.getStudentId()))
            throw new ResourceNotFoundException("Student not found: " + req.getStudentId());

        // Validate class exists via internal Feign call (no auth needed)
        validateClassExists(req.getClassId());

        // Check duplicate enrollment
        if (enrollmentRepository.existsByStudentIdAndClassIdAndStatus(
                req.getStudentId(), req.getClassId(), EnrollmentStatus.ACTIVE))
            throw new BadRequestException("Student already enrolled in this class");

        EnrollmentRecord saved = enrollmentRepository.save(EnrollmentRecord.builder()
                .studentId(req.getStudentId()).classId(req.getClassId())
                .status(EnrollmentStatus.ACTIVE).build());

        log.info("Student {} enrolled in class {}", req.getStudentId(), req.getClassId());
        return toResponse(saved);
    }

    private void validateClassExists(Long classId) {
        try {
            ResponseEntity<Boolean> response = classServiceClient.existsById(classId);
            if (!response.getStatusCode().is2xxSuccessful())
                throw new ResourceNotFoundException("Class not found: " + classId);
        } catch (ResourceNotFoundException e) {
            throw e;
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg != null && (msg.contains("404") || msg.contains("Not Found")))
                throw new ResourceNotFoundException("Class not found: " + classId);
            log.error("Class validation failed for {}: {}", classId, msg);
            throw new BadRequestException("Cannot verify class ID: " + classId);
        }
    }

    public List<EnrollmentResponse> getEnrollmentsByStudent(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<EnrollmentResponse> getEnrollmentsByClass(Long classId) {
        return enrollmentRepository.findByClassId(classId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public EnrollmentResponse updateStatus(Long id, EnrollmentStatus status) {
        EnrollmentRecord record = enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found: " + id));
        record.setStatus(status);
        log.info("Enrollment {} status updated to {}", id, status);
        return toResponse(enrollmentRepository.save(record));
    }

    private EnrollmentResponse toResponse(EnrollmentRecord e) {
        return EnrollmentResponse.builder()
                .id(e.getId()).studentId(e.getStudentId())
                .classId(e.getClassId()).enrolledAt(e.getEnrolledAt())
                .status(e.getStatus()).build();
    }
}