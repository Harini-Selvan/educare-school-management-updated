package com.educare.student.enums;
public enum Gender { MALE, FEMALE, OTHER }