package com.educare.student.controller;

import com.educare.student.dto.request.EnrollmentRequest;
import com.educare.student.dto.response.EnrollmentResponse;
import com.educare.student.enums.EnrollmentStatus;
import com.educare.student.security.RoleValidator;
import com.educare.student.service.EnrollmentService;
import com.educare.student.service.StudentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
@RequiredArgsConstructor
public class EnrollmentController {

    private final EnrollmentService enrollmentService;
    private final StudentService studentService;
    private final RoleValidator roleValidator;

    // ADMIN only can enroll students
    @PostMapping
    public ResponseEntity<EnrollmentResponse> enroll(
            @Valid @RequestBody EnrollmentRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(enrollmentService.enroll(req));
    }

    // ADMIN, TEACHER, PARENT, AUDITOR, STUDENT can view enrollments
    // STUDENT can only view their own enrollments (ownership enforced)
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<EnrollmentResponse>> byStudent(
            @PathVariable Long studentId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "AUDITOR", "STUDENT");

        // STUDENT role — verify they are only accessing their own data
        if ("STUDENT".equals(roleValidator.getRole(request))) {
            studentService.verifyStudentOwnership(studentId, roleValidator.getEmail(request));
        }

        return ResponseEntity.ok(enrollmentService.getEnrollmentsByStudent(studentId));
    }

    @GetMapping("/class/{classId}")
    public ResponseEntity<List<EnrollmentResponse>> byClass(
            @PathVariable Long classId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(enrollmentService.getEnrollmentsByClass(classId));
    }

    // ADMIN only can change enrollment status
    @PatchMapping("/{id}/status")
    public ResponseEntity<EnrollmentResponse> updateStatus(
            @PathVariable Long id, @RequestParam EnrollmentStatus status, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(enrollmentService.updateStatus(id, status));
    }
}
