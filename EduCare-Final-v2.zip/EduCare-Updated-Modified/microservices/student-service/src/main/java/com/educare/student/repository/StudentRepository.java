package com.educare.student.repository;

import com.educare.student.entity.Student;
import com.educare.student.enums.StudentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    List<Student> findByStatus(StudentStatus status);
    List<Student> findByProgram(String program);

    /**
     * Find student by their login email (stored in student_links table).
     * Uses native SQL because StudentLink has no JPA relationship with Student.
     */
    @Query(value = "SELECT s.* FROM students s " +
                   "INNER JOIN student_links sl ON s.id = sl.student_id " +
                   "WHERE sl.student_email = :email LIMIT 1",
           nativeQuery = true)
    Optional<Student> findByStudentEmail(@Param("email") String email);

    /**
     * Find all students linked to a parent email.
     * Uses native SQL for same reason.
     */
    @Query(value = "SELECT s.* FROM students s " +
                   "INNER JOIN student_links sl ON s.id = sl.student_id " +
                   "WHERE sl.parent_email = :email",
           nativeQuery = true)
    List<Student> findByParentEmail(@Param("email") String email);
}
