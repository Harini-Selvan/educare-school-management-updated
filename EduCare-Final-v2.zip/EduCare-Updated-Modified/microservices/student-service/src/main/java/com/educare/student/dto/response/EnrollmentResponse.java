package com.educare.student.dto.response;
import com.educare.student.enums.EnrollmentStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class EnrollmentResponse {
    private Long id;
    private Long studentId;
    private Long classId;
    private LocalDateTime enrolledAt;
    private EnrollmentStatus status;
}