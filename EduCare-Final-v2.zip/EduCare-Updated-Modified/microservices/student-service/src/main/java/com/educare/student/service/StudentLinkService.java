package com.educare.student.service;

import com.educare.student.entity.StudentLink;
import com.educare.student.exception.BadRequestException;
import com.educare.student.repository.StudentLinkRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class StudentLinkService {

    private final StudentLinkRepository studentLinkRepository;

    public boolean isLinkedToStudent(Long studentId, String email, String role) {
        if ("PARENT".equals(role))
            return studentLinkRepository.existsByStudentIdAndParentEmail(studentId, email);
        if ("STUDENT".equals(role))
            return studentLinkRepository.existsByStudentIdAndStudentEmail(studentId, email);
        return false;
    }

    public StudentLink register(Long studentId, String studentEmail, String parentEmail) {
        // Prevent duplicate links — same student already linked to same parent
        if (studentLinkRepository.existsByStudentIdAndParentEmailAndStudentEmail(
                studentId, parentEmail, studentEmail)) {
            throw new BadRequestException(
                "Student " + studentId + " is already linked to parent " + parentEmail);
        }

        return studentLinkRepository.save(StudentLink.builder()
                .studentId(studentId)
                .studentEmail(studentEmail)
                .parentEmail(parentEmail)
                .build());
    }
}
