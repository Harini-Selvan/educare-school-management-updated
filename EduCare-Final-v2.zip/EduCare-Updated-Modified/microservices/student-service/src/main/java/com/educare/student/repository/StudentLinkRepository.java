package com.educare.student.repository;

import com.educare.student.entity.StudentLink;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentLinkRepository extends JpaRepository<StudentLink, Long> {
    boolean existsByStudentIdAndParentEmail(Long studentId, String parentEmail);
    boolean existsByStudentIdAndStudentEmail(Long studentId, String studentEmail);
    boolean existsByStudentIdAndParentEmailAndStudentEmail(Long studentId, String parentEmail, String studentEmail);
}
