package com.educare.student.dto.response;
import com.educare.student.enums.*;
import lombok.*;
import java.time.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class StudentResponse {
    private Long id;
    private String name;
    private LocalDate dob;
    private Gender gender;
    private String contactInfo;
    private String program;
    private String parentEmail;
    private StudentStatus status;
    private LocalDateTime createdAt;
}