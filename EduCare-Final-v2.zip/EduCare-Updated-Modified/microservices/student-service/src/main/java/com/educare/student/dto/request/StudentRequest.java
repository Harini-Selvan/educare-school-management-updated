package com.educare.student.dto.request;
import com.educare.student.enums.Gender;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.time.LocalDate;
@Data
public class StudentRequest {
    @NotBlank private String name;
    private LocalDate dob;
    private Gender gender;
    private String contactInfo;
    private String program;
    private String parentEmail;
}