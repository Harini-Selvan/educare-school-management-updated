package com.educare.student.enums;
public enum EnrollmentStatus { ACTIVE, DROPPED, COMPLETED }