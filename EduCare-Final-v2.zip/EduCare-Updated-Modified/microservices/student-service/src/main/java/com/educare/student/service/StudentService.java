package com.educare.student.service;

import com.educare.student.dto.request.StudentRequest;
import com.educare.student.dto.response.StudentResponse;
import com.educare.student.entity.Student;
import com.educare.student.enums.StudentStatus;
import com.educare.student.exception.ResourceNotFoundException;
import com.educare.student.exception.UnauthorizedException;
import com.educare.student.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentResponse registerStudent(StudentRequest req) {
        log.info("Registering student: {}", req.getName());
        Student saved = studentRepository.save(Student.builder()
                .name(req.getName()).dob(req.getDob()).gender(req.getGender())
                .contactInfo(req.getContactInfo()).program(req.getProgram())
                .parentEmail(req.getParentEmail()).status(StudentStatus.ACTIVE).build());
        log.info("Student registered — id: {}", saved.getId());
        return toResponse(saved);
    }

    public List<StudentResponse> getAllStudents() {
        return studentRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    public StudentResponse getStudentById(Long id) {
        return toResponse(studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id)));
    }

    /**
     * Called by STUDENT role — returns their own profile.
     * Email comes from JWT header — no studentId needed.
     */
    public StudentResponse getMyProfile(String studentEmail) {
        Student student = studentRepository.findByStudentEmail(studentEmail)
                .orElseThrow(() -> new ResourceNotFoundException(
                    "Student profile not found for email: " + studentEmail +
                    ". Please ask admin to register your student link."));
        return toResponse(student);
    }

    /**
     * Called by PARENT role — returns all their children.
     * Email comes from JWT header — no studentId needed.
     */
    public List<StudentResponse> getMyChildren(String parentEmail) {
        return studentRepository.findByParentEmail(parentEmail)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Verifies that the given studentId belongs to the given email.
     * Used by STUDENT role to prevent accessing another student's data.
     */
    public void verifyStudentOwnership(Long studentId, String email) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));
        // Check via student_links — findByStudentEmail joins student_links
        studentRepository.findByStudentEmail(email)
                .filter(s -> s.getId().equals(studentId))
                .orElseThrow(() -> new UnauthorizedException(
                    "Access denied — studentId " + studentId + " does not belong to your account"));
    }

    public StudentResponse updateStudent(Long id, StudentRequest req) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
        student.setName(req.getName()); student.setDob(req.getDob());
        student.setGender(req.getGender()); student.setContactInfo(req.getContactInfo());
        student.setProgram(req.getProgram()); student.setParentEmail(req.getParentEmail());
        log.info("Student updated — id: {}", id);
        return toResponse(studentRepository.save(student));
    }

    public StudentResponse updateStatus(Long id, StudentStatus status) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
        log.info("Student {} status: {} -> {}", id, student.getStatus(), status);
        student.setStatus(status);
        return toResponse(studentRepository.save(student));
    }

    public Student getStudentEntityById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
    }

    public StudentResponse toResponse(Student s) {
        return StudentResponse.builder()
                .id(s.getId()).name(s.getName()).dob(s.getDob())
                .gender(s.getGender()).contactInfo(s.getContactInfo())
                .program(s.getProgram()).parentEmail(s.getParentEmail())
                .status(s.getStatus()).createdAt(s.getCreatedAt()).build();
    }
}
