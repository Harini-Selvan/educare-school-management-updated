package com.educare.student.controller;

import com.educare.student.entity.StudentLink;
import com.educare.student.security.RoleValidator;
import com.educare.student.service.StudentLinkService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students/links")
@RequiredArgsConstructor
public class StudentLinkController {

    private final StudentLinkService studentLinkService;
    private final RoleValidator roleValidator;

    @Data
    static class StudentLinkRequest {
        @NotNull Long studentId;
        @NotBlank @Email String studentEmail;
        @NotBlank @Email String parentEmail;
    }

    // ADMIN registers the link once — used by all services
    @PostMapping
    public ResponseEntity<StudentLink> register(
            @Valid @RequestBody StudentLinkRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(studentLinkService.register(
                req.getStudentId(), req.getStudentEmail(), req.getParentEmail()));
    }

    /**
     * Called internally by attendance-service and exam-service via Feign.
     * Returns true if the email is linked to the studentId for the given role.
     * No auth required — internal service-to-service call only.
     */
    @GetMapping("/verify")
    public ResponseEntity<Boolean> verify(
            @RequestParam Long studentId,
            @RequestParam String email,
            @RequestParam String role) {
        boolean linked = studentLinkService.isLinkedToStudent(studentId, email, role);
        return ResponseEntity.ok(linked);
    }
}