package com.educare.student.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CLASS-SERVICE")
public interface ClassServiceClient {

    /**
     * Internal endpoint — no auth required.
     * Returns 200 if exists, 404 if not.
     */
    @GetMapping("/api/classes/internal/exists/{id}")
    ResponseEntity<Boolean> existsById(@PathVariable Long id);
}