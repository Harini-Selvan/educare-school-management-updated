package com.educare.student.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "student_links",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_student_parent",
        columnNames = {"studentId", "parentEmail"}
    ))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class StudentLink {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long studentId;
    @Column(nullable = false) private String studentEmail;
    @Column(nullable = false) private String parentEmail;
}
