package com.educare.student.repository;
import com.educare.student.entity.EnrollmentRecord;
import com.educare.student.enums.EnrollmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EnrollmentRepository extends JpaRepository<EnrollmentRecord, Long> {
    List<EnrollmentRecord> findByStudentId(Long studentId);
    List<EnrollmentRecord> findByClassId(Long classId);
    List<EnrollmentRecord> findByStudentIdAndStatus(Long studentId, EnrollmentStatus status);
    boolean existsByStudentIdAndClassIdAndStatus(Long studentId, Long classId, EnrollmentStatus status);
}