package com.educare.student.entity;
import com.educare.student.enums.*;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.*;
@Entity @Table(name = "students")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    private LocalDate dob;
    @Enumerated(EnumType.STRING) private Gender gender;
    private String contactInfo;
    private String program;
    private String parentEmail;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private StudentStatus status;
    @CreationTimestamp private LocalDateTime createdAt;
}