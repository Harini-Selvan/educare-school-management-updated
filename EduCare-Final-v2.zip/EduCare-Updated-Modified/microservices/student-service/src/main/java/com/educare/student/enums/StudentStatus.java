package com.educare.student.enums;
public enum StudentStatus { ACTIVE, INACTIVE, GRADUATED, SUSPENDED }