package com.educare.student.entity;
import com.educare.student.enums.EnrollmentStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Entity @Table(name = "enrollment_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EnrollmentRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long studentId;
    @Column(nullable = false) private Long classId;
    @CreationTimestamp private LocalDateTime enrolledAt;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private EnrollmentStatus status;
}