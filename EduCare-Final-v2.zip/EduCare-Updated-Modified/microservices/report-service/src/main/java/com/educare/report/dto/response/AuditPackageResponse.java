package com.educare.report.dto.response;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditPackageResponse { private Long id; private LocalDate periodStart; private LocalDate periodEnd; private String contentsJson; private LocalDateTime generatedAt; private String packageUri; }