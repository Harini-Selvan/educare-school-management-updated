package com.educare.report.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class KpiRequest {
    @NotBlank private String name;
    private String definition;
    private Double target;
    private Double currentValue;
    private String reportingPeriod;
}