package com.educare.report.entity;
import com.educare.report.enums.ReportScope;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Entity @Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ReportScope scope;
    @Column(columnDefinition = "TEXT") private String parametersJson;
    @Column(columnDefinition = "TEXT") private String metricsJson;
    private String generatedBy;
    @CreationTimestamp private LocalDateTime generatedAt;
    private String reportUri;
}