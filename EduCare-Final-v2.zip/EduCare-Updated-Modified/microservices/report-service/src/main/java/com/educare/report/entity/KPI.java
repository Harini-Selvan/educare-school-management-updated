package com.educare.report.entity;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "kpis")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class KPI {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    private String definition;
    private Double target;
    private Double currentValue;
    private String reportingPeriod;
}