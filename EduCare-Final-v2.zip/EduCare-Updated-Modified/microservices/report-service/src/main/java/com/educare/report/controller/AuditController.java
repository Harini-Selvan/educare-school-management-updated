package com.educare.report.controller;

import com.educare.report.dto.request.AuditPackageRequest;
import com.educare.report.dto.response.AuditPackageResponse;
import com.educare.report.security.RoleValidator;
import com.educare.report.service.AuditService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/audit")
@RequiredArgsConstructor
public class AuditController {

    private final AuditService auditService;
    private final RoleValidator roleValidator;

    // ADMIN, AUDITOR can generate audit packages
    @PostMapping("/packages")
    public ResponseEntity<AuditPackageResponse> generate(
            @Valid @RequestBody AuditPackageRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(auditService.generatePackage(req));
    }

    // ADMIN, AUDITOR can view all audit packages
    @GetMapping("/packages")
    public ResponseEntity<List<AuditPackageResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(auditService.getAllPackages());
    }

    @GetMapping("/packages/{id}")
    public ResponseEntity<AuditPackageResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(auditService.getById(id));
    }
}