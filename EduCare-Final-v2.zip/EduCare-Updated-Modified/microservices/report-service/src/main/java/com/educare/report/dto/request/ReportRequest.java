package com.educare.report.dto.request;
import com.educare.report.enums.ReportScope;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ReportRequest {
    @NotNull private ReportScope scope;
    private String parametersJson;
    private String generatedBy;
}