package com.educare.report.service;
import com.educare.report.dto.request.AuditPackageRequest;
import com.educare.report.dto.response.AuditPackageResponse;
import com.educare.report.entity.AuditPackage;
import com.educare.report.exception.ResourceNotFoundException;
import com.educare.report.repository.AuditPackageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class AuditService {
    private final AuditPackageRepository auditPackageRepository;
    public AuditPackageResponse generatePackage(AuditPackageRequest req) {
        AuditPackage saved = auditPackageRepository.save(AuditPackage.builder()
                .periodStart(req.getPeriodStart()).periodEnd(req.getPeriodEnd())
                .contentsJson(req.getContentsJson() != null ? req.getContentsJson() : "{}")
                .packageUri("/audit/" + req.getPeriodStart() + "_" + req.getPeriodEnd() + ".zip").build());
        log.info("Audit package generated — period: {} to {}", req.getPeriodStart(), req.getPeriodEnd());
        return toResponse(saved);
    }
    public List<AuditPackageResponse> getAllPackages() {
        return auditPackageRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }
    public AuditPackageResponse getById(Long id) {
        return toResponse(auditPackageRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Audit package not found: " + id)));
    }
    private AuditPackageResponse toResponse(AuditPackage a) {
        return AuditPackageResponse.builder().id(a.getId()).periodStart(a.getPeriodStart()).periodEnd(a.getPeriodEnd())
                .contentsJson(a.getContentsJson()).generatedAt(a.getGeneratedAt()).packageUri(a.getPackageUri()).build();
    }
}