package com.educare.report.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import java.util.*;

/**
 * Wraps HttpServletRequest to inject X-User-Email and X-User-Role headers
 * when request comes directly to this service (not through gateway)
 */
public class HeaderAddingRequestWrapper extends HttpServletRequestWrapper {

    private final Map<String, String> extraHeaders = new HashMap<>();

    public HeaderAddingRequestWrapper(HttpServletRequest request, String email, String role) {
        super(request);
        if (email != null) extraHeaders.put("x-user-email", email);
        if (role  != null) extraHeaders.put("x-user-role",  role);
    }

    @Override
    public String getHeader(String name) {
        String lower = name.toLowerCase();
        if (extraHeaders.containsKey(lower)) {
            return extraHeaders.get(lower);
        }
        return super.getHeader(name);
    }

    @Override
    public Enumeration<String> getHeaders(String name) {
        String lower = name.toLowerCase();
        if (extraHeaders.containsKey(lower)) {
            return Collections.enumeration(Collections.singletonList(extraHeaders.get(lower)));
        }
        return super.getHeaders(name);
    }

    @Override
    public Enumeration<String> getHeaderNames() {
        List<String> names = Collections.list(super.getHeaderNames());
        names.addAll(extraHeaders.keySet());
        return Collections.enumeration(names);
    }
}
