package com.educare.report.controller;

import com.educare.report.dto.request.KpiRequest;
import com.educare.report.dto.response.KpiResponse;
import com.educare.report.security.RoleValidator;
import com.educare.report.service.KpiService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/kpis")
@RequiredArgsConstructor
public class KpiController {

    private final KpiService kpiService;
    private final RoleValidator roleValidator;

    // ADMIN and AUDITOR can create KPIs
    @PostMapping
    public ResponseEntity<KpiResponse> create(
            @Valid @RequestBody KpiRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(kpiService.createKpi(req));
    }

    // ADMIN and AUDITOR can view KPIs
    @GetMapping
    public ResponseEntity<List<KpiResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(kpiService.getAllKpis());
    }

    // ADMIN and AUDITOR can update KPI value
    @PatchMapping("/{id}/value")
    public ResponseEntity<KpiResponse> updateValue(
            @PathVariable Long id, @RequestParam Double value, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(kpiService.updateValue(id, value));
    }
}
