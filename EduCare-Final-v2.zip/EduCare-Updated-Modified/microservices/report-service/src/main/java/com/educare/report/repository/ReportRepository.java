package com.educare.report.repository;
import com.educare.report.entity.Report;
import com.educare.report.enums.ReportScope;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ReportRepository extends JpaRepository<Report, Long> { List<Report> findByScope(ReportScope scope); }