package com.educare.report.service;
import com.educare.report.dto.request.KpiRequest;
import com.educare.report.dto.response.KpiResponse;
import com.educare.report.entity.KPI;
import com.educare.report.exception.ResourceNotFoundException;
import com.educare.report.repository.KpiRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class KpiService {
    private final KpiRepository kpiRepository;
    public KpiResponse createKpi(KpiRequest req) {
        return toResponse(kpiRepository.save(KPI.builder().name(req.getName()).definition(req.getDefinition())
                .target(req.getTarget()).currentValue(req.getCurrentValue()).reportingPeriod(req.getReportingPeriod()).build()));
    }
    public List<KpiResponse> getAllKpis() {
        return kpiRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }
    public KpiResponse updateValue(Long id, Double value) {
        KPI kpi = kpiRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("KPI not found: " + id));
        kpi.setCurrentValue(value); return toResponse(kpiRepository.save(kpi));
    }
    private KpiResponse toResponse(KPI k) {
        return KpiResponse.builder().id(k.getId()).name(k.getName()).definition(k.getDefinition())
                .target(k.getTarget()).currentValue(k.getCurrentValue()).reportingPeriod(k.getReportingPeriod()).build();
    }
}