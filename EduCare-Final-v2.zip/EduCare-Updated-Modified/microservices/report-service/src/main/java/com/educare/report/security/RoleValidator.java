package com.educare.report.security;

import com.educare.report.exception.UnauthorizedException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class RoleValidator {

    public String getRole(HttpServletRequest request) {
        String role = request.getHeader("X-User-Role");
        if (role == null || role.isBlank()) {
            throw new UnauthorizedException("Missing role — please login first");
        }
        return role;
    }

    public String getEmail(HttpServletRequest request) {
        String email = request.getHeader("X-User-Email");
        if (email == null || email.isBlank()) {
            throw new UnauthorizedException("Missing user info — please login first");
        }
        return email;
    }

    public void requireAnyRole(HttpServletRequest request, String... allowedRoles) {
        String role = getRole(request);
        List<String> allowed = Arrays.asList(allowedRoles);
        if (!allowed.contains(role)) {
            throw new UnauthorizedException(
                "Access denied. Required: " + String.join(" or ", allowed) + ". Your role: " + role
            );
        }
    }
}