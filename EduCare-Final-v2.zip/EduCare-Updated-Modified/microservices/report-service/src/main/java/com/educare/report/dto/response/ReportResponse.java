package com.educare.report.dto.response;
import com.educare.report.enums.ReportScope;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ReportResponse { private Long id; private ReportScope scope; private String parametersJson; private String metricsJson; private String generatedBy; private LocalDateTime generatedAt; private String reportUri; }