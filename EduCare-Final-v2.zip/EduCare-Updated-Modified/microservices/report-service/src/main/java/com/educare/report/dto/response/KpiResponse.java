package com.educare.report.dto.response;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class KpiResponse { private Long id; private String name; private String definition; private Double target; private Double currentValue; private String reportingPeriod; }