package com.educare.report.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
@Data
public class AuditPackageRequest {
    @NotNull private LocalDate periodStart;
    @NotNull private LocalDate periodEnd;
    private String contentsJson;
}