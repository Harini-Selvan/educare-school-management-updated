package com.educare.report.enums;
public enum ReportScope { ENROLLMENT, ATTENDANCE, GRADES, KPI }