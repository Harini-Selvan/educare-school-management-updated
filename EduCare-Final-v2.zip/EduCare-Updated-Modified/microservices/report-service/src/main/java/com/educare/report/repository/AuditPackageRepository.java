package com.educare.report.repository;
import com.educare.report.entity.AuditPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
public interface AuditPackageRepository extends JpaRepository<AuditPackage, Long> { List<AuditPackage> findByPeriodStartGreaterThanEqual(LocalDate from); }