package com.educare.report.controller;

import com.educare.report.dto.request.ReportRequest;
import com.educare.report.dto.response.ReportResponse;
import com.educare.report.security.RoleValidator;
import com.educare.report.service.ReportService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;
    private final RoleValidator roleValidator;

    // ADMIN, AUDITOR can generate reports
    @PostMapping("/generate")
    public ResponseEntity<ReportResponse> generate(
            @Valid @RequestBody ReportRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(reportService.generateReport(req));
    }

    // ADMIN, AUDITOR, EXAM_COORDINATOR can view reports
    @GetMapping
    public ResponseEntity<List<ReportResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR", "EXAM_COORDINATOR");
        return ResponseEntity.ok(reportService.getAllReports());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReportResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR", "EXAM_COORDINATOR");
        return ResponseEntity.ok(reportService.getById(id));
    }
}