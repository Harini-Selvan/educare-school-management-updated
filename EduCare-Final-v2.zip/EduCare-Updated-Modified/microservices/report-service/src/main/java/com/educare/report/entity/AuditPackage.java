package com.educare.report.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity @Table(name = "audit_packages")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditPackage {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private LocalDate periodStart;
    @Column(nullable = false) private LocalDate periodEnd;
    @Column(columnDefinition = "TEXT") private String contentsJson;
    @CreationTimestamp private LocalDateTime generatedAt;
    private String packageUri;
}