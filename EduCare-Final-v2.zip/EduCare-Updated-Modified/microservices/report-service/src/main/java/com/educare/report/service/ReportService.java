package com.educare.report.service;
import com.educare.report.dto.request.ReportRequest;
import com.educare.report.dto.response.ReportResponse;
import com.educare.report.entity.Report;
import com.educare.report.exception.ResourceNotFoundException;
import com.educare.report.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class ReportService {
    private final ReportRepository reportRepository;
    public ReportResponse generateReport(ReportRequest req) {
        Report saved = reportRepository.save(Report.builder().scope(req.getScope())
                .parametersJson(req.getParametersJson()).metricsJson("{}")
                .generatedBy(req.getGeneratedBy()).reportUri("/reports/" + req.getScope().name().toLowerCase() + "_" + System.currentTimeMillis() + ".json").build());
        log.info("Report generated — scope: {}, id: {}", req.getScope(), saved.getId());
        return toResponse(saved);
    }
    public List<ReportResponse> getAllReports() {
        return reportRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }
    public ReportResponse getById(Long id) {
        return toResponse(reportRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Report not found: " + id)));
    }
    private ReportResponse toResponse(Report r) {
        return ReportResponse.builder().id(r.getId()).scope(r.getScope()).parametersJson(r.getParametersJson())
                .metricsJson(r.getMetricsJson()).generatedBy(r.getGeneratedBy()).generatedAt(r.getGeneratedAt()).reportUri(r.getReportUri()).build();
    }
}