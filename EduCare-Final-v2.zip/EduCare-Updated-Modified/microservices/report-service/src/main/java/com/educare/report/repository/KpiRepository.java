package com.educare.report.repository;
import com.educare.report.entity.KPI;
import org.springframework.data.jpa.repository.JpaRepository;
public interface KpiRepository extends JpaRepository<KPI, Long> {}