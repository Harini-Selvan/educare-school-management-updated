package com.educare.exam.dto.response;
import com.educare.exam.enums.GradeStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class GradeResponse {
    private Long id;
    private Long studentId;
    private String studentName;
    private Long examId;
    private String examName;
    private String subject;
    private Double gradeValue;
    private String submittedBy;
    private LocalDateTime submittedAt;
    private GradeStatus status;
    private String remarks;
    private String evidenceUri;
}
