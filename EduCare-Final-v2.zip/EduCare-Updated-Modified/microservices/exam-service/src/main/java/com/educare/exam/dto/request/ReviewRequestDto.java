package com.educare.exam.dto.request;

import com.educare.exam.enums.GradeChangeRequestStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReviewRequestDto {
    @NotNull  private GradeChangeRequestStatus status;  // APPROVED or REJECTED
    @NotBlank private String reviewRemarks;
}