package com.educare.exam.dto.response;
import com.educare.exam.enums.ExamStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ExamResponse {
    private Long id;
    private Long classId;
    private String subject;
    private LocalDateTime scheduledAt;
    private LocalDateTime fromTime;
    private LocalDateTime toTime;
    private ExamStatus status;
    private Integer totalMarks;
    private Integer passingMarks;
}
