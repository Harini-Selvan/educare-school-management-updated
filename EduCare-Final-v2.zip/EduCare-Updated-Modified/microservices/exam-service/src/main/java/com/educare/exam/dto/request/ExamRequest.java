package com.educare.exam.dto.request;
import com.educare.exam.enums.ExamStatus;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;
@Data
public class ExamRequest {
    @NotNull private Long classId;
    @NotBlank private String subject;
    private LocalDateTime scheduledAt;
    private LocalDateTime fromTime;
    private LocalDateTime toTime;
    private Integer totalMarks;
    private Integer passingMarks;
}
