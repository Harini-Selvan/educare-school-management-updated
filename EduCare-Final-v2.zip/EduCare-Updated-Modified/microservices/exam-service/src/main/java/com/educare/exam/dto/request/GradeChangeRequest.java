package com.educare.exam.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class GradeChangeRequest {
    @NotNull private Double newValue;
    @NotBlank private String changedBy;
    @NotBlank private String reason;
    private String evidenceUri;
}