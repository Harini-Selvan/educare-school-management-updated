package com.educare.exam.enums;
public enum GradeStatus { SUBMITTED, MODERATED, FINAL }