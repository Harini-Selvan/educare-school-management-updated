package com.educare.exam.service;

import com.educare.exam.client.StudentServiceClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class StudentLinkService {

    private final StudentServiceClient studentServiceClient;

    public boolean isLinkedToStudent(Long studentId, String email, String role) {
        try {
            Boolean result = studentServiceClient.isLinkedToStudent(studentId, email, role);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            log.warn("Could not verify student link: {}", e.getMessage());
            return false;
        }
    }
}