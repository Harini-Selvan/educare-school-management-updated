package com.educare.exam.controller;

import com.educare.exam.dto.request.ExamRequest;
import com.educare.exam.dto.response.ExamResponse;
import com.educare.exam.enums.ExamStatus;
import com.educare.exam.security.RoleValidator;
import com.educare.exam.service.ExamService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/exams")
@RequiredArgsConstructor
public class ExamController {

    private final ExamService examService;
    private final RoleValidator roleValidator;

    @PostMapping
    public ResponseEntity<ExamResponse> create(
            @Valid @RequestBody ExamRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR");
        return ResponseEntity.ok(examService.createExam(req));
    }

    @GetMapping
    public ResponseEntity<List<ExamResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(examService.getAll());
    }

    @GetMapping("/class/{classId}")
    public ResponseEntity<List<ExamResponse>> byClass(
            @PathVariable Long classId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(examService.getByClass(classId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExamResponse> getById(
            @PathVariable Long id, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(examService.getById(id));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ExamResponse> updateStatus(
            @PathVariable Long id, @RequestParam ExamStatus status, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR");
        return ResponseEntity.ok(examService.updateStatus(id, status));
    }
}
