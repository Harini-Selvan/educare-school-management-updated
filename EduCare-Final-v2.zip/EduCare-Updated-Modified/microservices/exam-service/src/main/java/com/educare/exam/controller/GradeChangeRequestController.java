package com.educare.exam.controller;

import com.educare.exam.dto.request.GradeChangeRequestDto;
import com.educare.exam.dto.request.ReviewRequestDto;
import com.educare.exam.dto.response.GradeChangeRequestResponse;
import com.educare.exam.security.RoleValidator;
import com.educare.exam.service.GradeChangeRequestService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/grade-requests")
@RequiredArgsConstructor
public class GradeChangeRequestController {

    private final GradeChangeRequestService requestService;
    private final RoleValidator roleValidator;

    /**
     * TEACHER raises a grade change request with evidence.
     * Goes to Exam Coordinator for review.
     */
    @PostMapping
    public ResponseEntity<GradeChangeRequestResponse> raise(
            @Valid @RequestBody GradeChangeRequestDto dto,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "TEACHER");
        String teacherEmail = roleValidator.getEmail(request);
        return ResponseEntity.ok(requestService.raiseRequest(dto, teacherEmail));
    }

    /**
     * EXAM_COORDINATOR views all pending requests waiting for review.
     */
    @GetMapping("/pending")
    public ResponseEntity<List<GradeChangeRequestResponse>> pending(
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR");
        return ResponseEntity.ok(requestService.getPendingRequests());
    }

    /**
     * TEACHER views their own submitted requests and their status.
     */
    @GetMapping("/my")
    public ResponseEntity<List<GradeChangeRequestResponse>> myRequests(
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "TEACHER");
        String teacherEmail = roleValidator.getEmail(request);
        return ResponseEntity.ok(requestService.getMyRequests(teacherEmail));
    }

    /**
     * View all requests for a specific grade — ADMIN, EXAM_COORDINATOR, AUDITOR.
     */
    @GetMapping("/grade/{gradeId}")
    public ResponseEntity<List<GradeChangeRequestResponse>> byGrade(
            @PathVariable Long gradeId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(requestService.getRequestsByGrade(gradeId));
    }

    /**
     * EXAM_COORDINATOR approves or rejects a request.
     * If approved → grade updated automatically.
     */
    @PatchMapping("/{requestId}/review")
    public ResponseEntity<GradeChangeRequestResponse> review(
            @PathVariable Long requestId,
            @Valid @RequestBody ReviewRequestDto dto,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR");
        String coordinatorEmail = roleValidator.getEmail(request);
        return ResponseEntity.ok(requestService.reviewRequest(requestId, dto, coordinatorEmail));
    }
}