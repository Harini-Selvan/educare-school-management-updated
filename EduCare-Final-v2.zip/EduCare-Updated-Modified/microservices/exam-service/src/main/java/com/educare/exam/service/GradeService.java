package com.educare.exam.service;

import com.educare.exam.client.StudentServiceClient;
import com.educare.exam.dto.request.GradeChangeRequest;
import com.educare.exam.dto.request.GradeRequest;
import com.educare.exam.dto.response.GradeChangeResponse;
import com.educare.exam.dto.response.GradeResponse;
import com.educare.exam.entity.Grade;
import com.educare.exam.entity.GradeChange;
import com.educare.exam.enums.GradeChangeStatus;
import com.educare.exam.enums.GradeStatus;
import com.educare.exam.exception.BadRequestException;
import com.educare.exam.exception.ResourceNotFoundException;
import com.educare.exam.repository.ExamRepository;
import com.educare.exam.repository.GradeChangeRepository;
import com.educare.exam.repository.GradeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class GradeService {

    private final GradeRepository gradeRepository;
    private final GradeChangeRepository gradeChangeRepository;
    private final ExamRepository examRepository;
    private final StudentServiceClient studentServiceClient;

    public GradeResponse submitGrade(GradeRequest req) {
        if (!examRepository.existsById(req.getExamId()))
            throw new ResourceNotFoundException("Exam not found: " + req.getExamId());

        validateStudentExists(req.getStudentId());

        gradeRepository.findByStudentIdAndExamId(req.getStudentId(), req.getExamId())
                .ifPresent(g -> { throw new BadRequestException(
                        "Grade already submitted for this student in this exam"); });

        Grade saved = gradeRepository.save(Grade.builder()
                .studentId(req.getStudentId()).examId(req.getExamId())
                .gradeValue(req.getGradeValue()).submittedBy(req.getSubmittedBy())
                .remarks(req.getRemarks()).evidenceUri(req.getEvidenceUri()).status(GradeStatus.SUBMITTED).build());

        log.info("Grade submitted — student: {}, exam: {}, value: {}",
                req.getStudentId(), req.getExamId(), req.getGradeValue());
        return toGradeResponse(saved);
    }

    private void validateStudentExists(Long studentId) {
        try {
            ResponseEntity<Boolean> response = studentServiceClient.existsById(studentId);
            if (!response.getStatusCode().is2xxSuccessful())
                throw new ResourceNotFoundException("Student not found: " + studentId);
        } catch (ResourceNotFoundException e) {
            throw e;
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg != null && (msg.contains("404") || msg.contains("Not Found")))
                throw new ResourceNotFoundException("Student not found: " + studentId);
            log.error("Student validation failed for {}: {}", studentId, msg);
            throw new BadRequestException("Cannot verify student ID: " + studentId);
        }
    }

    public List<GradeResponse> getByExam(Long examId) {
        return gradeRepository.findByExamId(examId)
                .stream().map(this::toGradeResponse).collect(Collectors.toList());
    }

    public List<GradeResponse> getByStudent(Long studentId) {
        return gradeRepository.findByStudentId(studentId)
                .stream().map(this::toGradeResponse).collect(Collectors.toList());
    }

    public GradeResponse modifyGrade(Long gradeId, GradeChangeRequest req) {
        Grade grade = gradeRepository.findById(gradeId)
                .orElseThrow(() -> new ResourceNotFoundException("Grade not found: " + gradeId));
        double oldValue = grade.getGradeValue();
        gradeChangeRepository.save(GradeChange.builder()
                .gradeId(gradeId).oldValue(oldValue).newValue(req.getNewValue())
                .changedBy(req.getChangedBy()).reason(req.getReason())
                .evidenceUri(req.getEvidenceUri()).status(GradeChangeStatus.PENDING).build());
        grade.setGradeValue(req.getNewValue());
        grade.setStatus(GradeStatus.MODERATED);
        log.info("Grade {} modified: {} -> {} by {}", gradeId, oldValue, req.getNewValue(), req.getChangedBy());
        return toGradeResponse(gradeRepository.save(grade));
    }

    public GradeResponse approveGradeChange(Long changeId) {
        GradeChange change = gradeChangeRepository.findById(changeId)
                .orElseThrow(() -> new ResourceNotFoundException("Grade change not found: " + changeId));
        change.setStatus(GradeChangeStatus.APPROVED);
        gradeChangeRepository.save(change);
        Grade grade = gradeRepository.findById(change.getGradeId())
                .orElseThrow(() -> new ResourceNotFoundException("Grade not found: " + change.getGradeId()));
        grade.setStatus(GradeStatus.FINAL);
        log.info("Grade change {} approved", changeId);
        return toGradeResponse(gradeRepository.save(grade));
    }

    public List<GradeChangeResponse> getGradeHistory(Long gradeId) {
        return gradeChangeRepository.findByGradeIdOrderByChangedAtDesc(gradeId)
                .stream().map(this::toChangeResponse).collect(Collectors.toList());
    }

    private GradeResponse toGradeResponse(Grade g) {
        String examSubject = examRepository.findById(g.getExamId())
                .map(e -> e.getSubject()).orElse(null);
        return GradeResponse.builder().id(g.getId())
                .studentId(g.getStudentId()).examId(g.getExamId())
                .examName(examSubject).subject(examSubject)
                .gradeValue(g.getGradeValue()).submittedBy(g.getSubmittedBy())
                .submittedAt(g.getSubmittedAt()).status(g.getStatus())
                .remarks(g.getRemarks()).evidenceUri(g.getEvidenceUri()).build();
    }

    private GradeChangeResponse toChangeResponse(GradeChange c) {
        return GradeChangeResponse.builder().id(c.getId())
                .gradeId(c.getGradeId()).oldValue(c.getOldValue())
                .newValue(c.getNewValue()).changedBy(c.getChangedBy())
                .changedAt(c.getChangedAt()).reason(c.getReason())
                .evidenceUri(c.getEvidenceUri()).status(c.getStatus()).build();
    }
}