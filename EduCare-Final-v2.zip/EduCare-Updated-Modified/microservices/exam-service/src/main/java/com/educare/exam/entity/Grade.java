package com.educare.exam.entity;
import com.educare.exam.enums.GradeStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Entity @Table(name = "grades")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Grade {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long studentId;
    @Column(nullable = false) private Long examId;
    private Double gradeValue;
    private String submittedBy;
    @CreationTimestamp private LocalDateTime submittedAt;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private GradeStatus status;
    private String remarks;
    private String evidenceUri;
}
