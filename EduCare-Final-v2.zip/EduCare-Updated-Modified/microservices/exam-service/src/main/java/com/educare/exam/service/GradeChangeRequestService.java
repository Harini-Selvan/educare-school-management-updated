package com.educare.exam.service;

import com.educare.exam.dto.request.GradeChangeRequestDto;
import com.educare.exam.dto.request.ReviewRequestDto;
import com.educare.exam.dto.response.GradeChangeRequestResponse;
import com.educare.exam.entity.Grade;
import com.educare.exam.entity.GradeChange;
import com.educare.exam.entity.GradeChangeRequest;
import com.educare.exam.enums.GradeChangeRequestStatus;
import com.educare.exam.enums.GradeChangeStatus;
import com.educare.exam.enums.GradeStatus;
import com.educare.exam.exception.BadRequestException;
import com.educare.exam.exception.ResourceNotFoundException;
import com.educare.exam.repository.GradeChangeRepository;
import com.educare.exam.repository.GradeChangeRequestRepository;
import com.educare.exam.repository.GradeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class GradeChangeRequestService {

    private final GradeChangeRequestRepository requestRepository;
    private final GradeRepository gradeRepository;
    private final GradeChangeRepository gradeChangeRepository;

    /**
     * TEACHER raises a grade change request with proof.
     * Status starts as PENDING — coordinator must review.
     */
    public GradeChangeRequestResponse raiseRequest(
            GradeChangeRequestDto dto, String teacherEmail) {

        Grade grade = gradeRepository.findById(dto.getGradeId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Grade not found: " + dto.getGradeId()));

        // Auto-fill studentId/examId from grade record if not provided
        Long studentId = (dto.getStudentId() != null) ? dto.getStudentId() : grade.getStudentId();
        Long examId = (dto.getExamId() != null) ? dto.getExamId() : grade.getExamId();
        String evidenceUri = (dto.getEvidenceUri() != null) ? dto.getEvidenceUri() : "";

        GradeChangeRequest saved = requestRepository.save(
                GradeChangeRequest.builder()
                        .gradeId(dto.getGradeId())
                        .studentId(studentId)
                        .examId(examId)
                        .currentValue(grade.getGradeValue())
                        .requestedValue(dto.getRequestedValue())
                        .requestedBy(teacherEmail)
                        .reason(dto.getReason())
                        .evidenceUri(evidenceUri)
                        .status(GradeChangeRequestStatus.PENDING)
                        .build());

        log.info("Grade change request raised — gradeId: {}, teacher: {}, requested: {}",
                dto.getGradeId(), teacherEmail, dto.getRequestedValue());

        return toResponse(saved);
    }

    /**
     * Get all PENDING requests — Exam Coordinator reviews these.
     */
    public List<GradeChangeRequestResponse> getPendingRequests() {
        return requestRepository.findByStatus(GradeChangeRequestStatus.PENDING)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Get all requests raised by a specific teacher.
     */
    public List<GradeChangeRequestResponse> getMyRequests(String teacherEmail) {
        return requestRepository.findByRequestedBy(teacherEmail)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Get all requests for a specific grade.
     */
    public List<GradeChangeRequestResponse> getRequestsByGrade(Long gradeId) {
        return requestRepository.findByGradeId(gradeId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * EXAM_COORDINATOR reviews request — approves or rejects.
     * If APPROVED → grade is updated automatically + GradeChange audit record created.
     * If REJECTED → grade stays unchanged.
     */
    public GradeChangeRequestResponse reviewRequest(
            Long requestId, ReviewRequestDto dto, String coordinatorEmail) {

        GradeChangeRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Grade change request not found: " + requestId));

        if (request.getStatus() != GradeChangeRequestStatus.PENDING) {
            throw new BadRequestException(
                    "Request already reviewed. Status: " + request.getStatus());
        }

        if (dto.getStatus() == GradeChangeRequestStatus.PENDING) {
            throw new BadRequestException("Review status must be APPROVED or REJECTED");
        }

        request.setStatus(dto.getStatus());
        request.setReviewedBy(coordinatorEmail);
        request.setReviewRemarks(dto.getReviewRemarks());
        request.setReviewedAt(LocalDateTime.now());

        if (dto.getStatus() == GradeChangeRequestStatus.APPROVED) {
            // Update the actual grade
            Grade grade = gradeRepository.findById(request.getGradeId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Grade not found: " + request.getGradeId()));

            double oldValue = grade.getGradeValue();
            grade.setGradeValue(request.getRequestedValue());
            grade.setStatus(GradeStatus.MODERATED);
            gradeRepository.save(grade);

            // Create audit record in GradeChange table
            gradeChangeRepository.save(GradeChange.builder()
                    .gradeId(request.getGradeId())
                    .oldValue(oldValue)
                    .newValue(request.getRequestedValue())
                    .changedBy(coordinatorEmail)
                    .reason("Approved teacher request: " + request.getReason())
                    .evidenceUri(request.getEvidenceUri())
                    .status(GradeChangeStatus.APPROVED)
                    .build());

            log.info("Grade change APPROVED — gradeId: {}, {} -> {} by {}",
                    request.getGradeId(), oldValue,
                    request.getRequestedValue(), coordinatorEmail);
        } else {
            log.info("Grade change REJECTED — gradeId: {}, by {}",
                    request.getGradeId(), coordinatorEmail);
        }

        return toResponse(requestRepository.save(request));
    }

    private GradeChangeRequestResponse toResponse(GradeChangeRequest r) {
        return GradeChangeRequestResponse.builder()
                .id(r.getId()).gradeId(r.getGradeId())
                .studentId(r.getStudentId()).examId(r.getExamId())
                .currentValue(r.getCurrentValue())
                .requestedValue(r.getRequestedValue())
                .requestedBy(r.getRequestedBy()).reason(r.getReason())
                .evidenceUri(r.getEvidenceUri()).status(r.getStatus())
                .reviewedBy(r.getReviewedBy()).reviewRemarks(r.getReviewRemarks())
                .requestedAt(r.getRequestedAt()).reviewedAt(r.getReviewedAt())
                .build();
    }
}