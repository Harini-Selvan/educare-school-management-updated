package com.educare.exam.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class GradeChangeRequestDto {
    @NotNull  private Long gradeId;
    private Long studentId;   // optional - service gets it from grade record
    private Long examId;      // optional - service gets it from grade record
    @NotNull  private Double requestedValue;
    @NotBlank private String reason;
    private String evidenceUri;
    private String requestedBy; // optional - controller sets from JWT
}
