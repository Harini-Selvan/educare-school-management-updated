package com.educare.exam.enums;
public enum GradeChangeStatus { PENDING, APPROVED, REJECTED }
