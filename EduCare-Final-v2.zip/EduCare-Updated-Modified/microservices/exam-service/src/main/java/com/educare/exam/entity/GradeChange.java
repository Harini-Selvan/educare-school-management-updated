package com.educare.exam.entity;

import com.educare.exam.enums.GradeChangeStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "grade_changes")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class GradeChange {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private Long gradeId;
    private Double oldValue;
    private Double newValue;
    private String changedBy;
    @CreationTimestamp private LocalDateTime changedAt;
    private String reason;
    private String evidenceUri;
    @Enumerated(EnumType.STRING) @Column(nullable = false)
    private GradeChangeStatus status;
}
