package com.educare.exam.repository;
import com.educare.exam.entity.GradeChange;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface GradeChangeRepository extends JpaRepository<GradeChange, Long> {
    List<GradeChange> findByGradeIdOrderByChangedAtDesc(Long gradeId);
}