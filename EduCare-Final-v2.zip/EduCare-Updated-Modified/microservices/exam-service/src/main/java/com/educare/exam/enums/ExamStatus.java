package com.educare.exam.enums;
public enum ExamStatus { SCHEDULED, ONGOING, COMPLETED, CANCELLED }