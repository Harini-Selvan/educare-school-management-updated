package com.educare.exam.entity;
import com.educare.exam.enums.ExamStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name = "exams")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Exam {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private Long classId;
    @Column(nullable = false) private String subject;
    private LocalDateTime scheduledAt;
    private LocalDateTime fromTime;
    private LocalDateTime toTime;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ExamStatus status;
    private Integer totalMarks;
    private Integer passingMarks;
}
