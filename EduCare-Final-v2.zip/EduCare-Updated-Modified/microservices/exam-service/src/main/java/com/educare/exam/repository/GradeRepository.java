package com.educare.exam.repository;
import com.educare.exam.entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByExamId(Long examId);
    List<Grade> findByStudentId(Long studentId);
    Optional<Grade> findByStudentIdAndExamId(Long studentId, Long examId);
}