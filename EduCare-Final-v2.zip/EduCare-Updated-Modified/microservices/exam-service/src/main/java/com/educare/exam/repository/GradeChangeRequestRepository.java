package com.educare.exam.repository;

import com.educare.exam.entity.GradeChangeRequest;
import com.educare.exam.enums.GradeChangeRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GradeChangeRequestRepository extends JpaRepository<GradeChangeRequest, Long> {
    List<GradeChangeRequest> findByStatus(GradeChangeRequestStatus status);
    List<GradeChangeRequest> findByRequestedBy(String requestedBy);
    List<GradeChangeRequest> findByGradeId(Long gradeId);
}