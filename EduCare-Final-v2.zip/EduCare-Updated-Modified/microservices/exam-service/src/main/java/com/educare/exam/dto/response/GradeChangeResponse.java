package com.educare.exam.dto.response;

import com.educare.exam.enums.GradeChangeStatus;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class GradeChangeResponse {
    private Long id;
    private Long gradeId;
    private Double oldValue;
    private Double newValue;
    private String changedBy;
    private LocalDateTime changedAt;
    private String reason;
    private String evidenceUri;
    private GradeChangeStatus status;
}
