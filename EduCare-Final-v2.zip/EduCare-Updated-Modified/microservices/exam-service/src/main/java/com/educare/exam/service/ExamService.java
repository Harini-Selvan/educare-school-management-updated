package com.educare.exam.service;
import com.educare.exam.dto.request.ExamRequest;
import com.educare.exam.dto.response.ExamResponse;
import com.educare.exam.entity.Exam;
import com.educare.exam.enums.ExamStatus;
import com.educare.exam.exception.ResourceNotFoundException;
import com.educare.exam.repository.ExamRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class ExamService {
    private final ExamRepository examRepository;

    public ExamResponse createExam(ExamRequest req) {
        LocalDateTime scheduledAt = req.getFromTime() != null ? req.getFromTime() : req.getScheduledAt();
        ExamStatus initialStatus = computeStatus(scheduledAt);
        Exam saved = examRepository.save(Exam.builder()
                .classId(req.getClassId()).subject(req.getSubject())
                .scheduledAt(scheduledAt)
                .fromTime(req.getFromTime())
                .toTime(req.getToTime())
                .totalMarks(req.getTotalMarks())
                .passingMarks(req.getPassingMarks()).status(initialStatus).build());
        log.info("Exam scheduled — id: {}, subject: {}, status: {}", saved.getId(), saved.getSubject(), saved.getStatus());
        return toResponse(saved);
    }

    public List<ExamResponse> getAll() {
        return examRepository.findAll().stream()
                .map(this::syncStatus).map(this::toResponse).collect(Collectors.toList());
    }

    public List<ExamResponse> getByClass(Long classId) {
        return examRepository.findByClassId(classId).stream()
                .map(this::syncStatus).map(this::toResponse).collect(Collectors.toList());
    }

    public ExamResponse getById(Long id) {
        Exam exam = examRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + id));
        return toResponse(syncStatus(exam));
    }

    public ExamResponse updateStatus(Long id, ExamStatus status) {
        Exam exam = examRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + id));
        exam.setStatus(status);
        return toResponse(examRepository.save(exam));
    }

    private ExamStatus computeStatus(LocalDateTime scheduledAt) {
        if (scheduledAt == null) return ExamStatus.SCHEDULED;
        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(scheduledAt)) return ExamStatus.SCHEDULED;
        if (now.isAfter(scheduledAt.plusHours(3))) return ExamStatus.COMPLETED;
        return ExamStatus.ONGOING;
    }

    private Exam syncStatus(Exam exam) {
        ExamStatus computed = computeStatus(exam.getScheduledAt());
        if (exam.getStatus() != computed) {
            exam.setStatus(computed);
            examRepository.save(exam);
        }
        return exam;
    }

    public ExamResponse toResponse(Exam e) {
        return ExamResponse.builder().id(e.getId()).classId(e.getClassId()).subject(e.getSubject())
                .scheduledAt(e.getScheduledAt())
                .fromTime(e.getFromTime())
                .toTime(e.getToTime())
                .status(e.getStatus())
                .totalMarks(e.getTotalMarks()).passingMarks(e.getPassingMarks()).build();
    }
}
