package com.educare.exam.repository;
import com.educare.exam.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByClassId(Long classId);
}