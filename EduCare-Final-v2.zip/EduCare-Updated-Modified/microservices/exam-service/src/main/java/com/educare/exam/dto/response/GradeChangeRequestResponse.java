package com.educare.exam.dto.response;

import com.educare.exam.enums.GradeChangeRequestStatus;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class GradeChangeRequestResponse {
    private Long id;
    private Long gradeId;
    private Long studentId;
    private Long examId;
    private Double currentValue;
    private Double requestedValue;
    private String requestedBy;
    private String reason;
    private String evidenceUri;
    private GradeChangeRequestStatus status;
    private String reviewedBy;
    private String reviewRemarks;
    private LocalDateTime requestedAt;
    private LocalDateTime reviewedAt;
}