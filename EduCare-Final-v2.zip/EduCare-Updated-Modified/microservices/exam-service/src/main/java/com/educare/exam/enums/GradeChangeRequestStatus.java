package com.educare.exam.enums;
public enum GradeChangeRequestStatus {
    PENDING,    // Teacher submitted, waiting for coordinator review
    APPROVED,   // Coordinator approved — grade updated
    REJECTED    // Coordinator rejected — grade unchanged
}