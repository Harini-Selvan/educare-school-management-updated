package com.educare.exam.entity;

import com.educare.exam.enums.GradeChangeRequestStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "grade_change_requests")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class GradeChangeRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private Long gradeId;
    @Column(nullable = false) private Long studentId;
    @Column(nullable = false) private Long examId;

    private Double currentValue;
    @Column(nullable = false) private Double requestedValue;

    @Column(nullable = false) private String requestedBy;       // teacher email
    @Column(nullable = false) private String reason;
    @Column(nullable = false) private String evidenceUri;       // proof uploaded by teacher

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) private GradeChangeRequestStatus status;

    private String reviewedBy;       // coordinator email who approved/rejected
    private String reviewRemarks;    // coordinator's comment

    @CreationTimestamp private LocalDateTime requestedAt;
    private LocalDateTime reviewedAt;
}