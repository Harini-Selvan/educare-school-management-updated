package com.educare.exam.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class GradeRequest {
    @NotNull private Long studentId;
    @NotNull private Long examId;
    @NotNull private Double gradeValue;
    private String submittedBy;
    private String remarks;
    private String evidenceUri;
}
