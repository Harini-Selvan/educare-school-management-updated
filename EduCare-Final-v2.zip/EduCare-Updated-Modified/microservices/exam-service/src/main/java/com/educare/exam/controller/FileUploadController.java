package com.educare.exam.controller;

import com.educare.exam.security.RoleValidator;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/evidence")
@RequiredArgsConstructor
@Slf4j
public class FileUploadController {

    private final RoleValidator roleValidator;
    private static final Path UPLOAD_DIR = Paths.get(System.getProperty("user.home"), "educare-uploads", "evidence");

    private void ensureUploadDir() throws IOException {
        if (!Files.exists(UPLOAD_DIR)) {
            Files.createDirectories(UPLOAD_DIR);
        }
    }

    /**
     * Upload evidence PDF — only TEACHER can upload
     */
    @PostMapping("/upload")
    public ResponseEntity<Map<String, String>> upload(
            @RequestParam("file") MultipartFile file,
            HttpServletRequest request) throws IOException {

        roleValidator.requireAnyRole(request, "TEACHER", "ADMIN");
        ensureUploadDir();

        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "File is empty"));
        }

        String originalName = file.getOriginalFilename();
        String extension = (originalName != null && originalName.contains("."))
                ? originalName.substring(originalName.lastIndexOf('.'))
                : ".pdf";
        String filename = UUID.randomUUID() + extension;
        Path targetPath = UPLOAD_DIR.resolve(filename);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        log.info("Evidence file uploaded: {}", filename);
        String fileUrl = "/api/evidence/" + filename;
        return ResponseEntity.ok(Map.of("url", fileUrl, "filename", filename));
    }

    /**
     * Serve uploaded evidence file — accessible by TEACHER, EXAM_COORDINATOR, ADMIN
     */
    @GetMapping("/{filename:.+}")
    public ResponseEntity<Resource> serveFile(
            @PathVariable String filename,
            HttpServletRequest request) {

        roleValidator.requireAnyRole(request, "TEACHER", "EXAM_COORDINATOR", "ADMIN", "AUDITOR");

        try {
            Path filePath = UPLOAD_DIR.resolve(filename).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                return ResponseEntity.notFound().build();
            }

            String contentType = "application/pdf";
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + filename + "\"")
                    .body(resource);
        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
