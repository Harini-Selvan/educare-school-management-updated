package com.educare.exam.controller;

import com.educare.exam.dto.request.GradeChangeRequest;
import com.educare.exam.dto.request.GradeRequest;
import com.educare.exam.dto.response.GradeChangeResponse;
import com.educare.exam.dto.response.GradeResponse;
import com.educare.exam.exception.UnauthorizedException;
import com.educare.exam.security.RoleValidator;
import com.educare.exam.service.GradeService;
import com.educare.exam.service.StudentLinkService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/grades")
@RequiredArgsConstructor
public class GradeController {

    private final GradeService gradeService;
    private final RoleValidator roleValidator;
    private final StudentLinkService studentLinkService;

    // ADMIN, TEACHER, EXAM_COORDINATOR can submit grades
    @PostMapping
    public ResponseEntity<GradeResponse> submit(
            @Valid @RequestBody GradeRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR");
        return ResponseEntity.ok(gradeService.submitGrade(req));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR can view all grades for an exam
    @GetMapping("/exam/{examId}")
    public ResponseEntity<List<GradeResponse>> byExam(
            @PathVariable Long examId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(gradeService.getByExam(examId));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR → any student
    // STUDENT and PARENT → only their own / their child's grades
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<GradeResponse>> byStudent(
            @PathVariable Long studentId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "STUDENT", "PARENT", "EXAM_COORDINATOR", "AUDITOR");
        checkStudentAccess(request, studentId);
        return ResponseEntity.ok(gradeService.getByStudent(studentId));
    }

    // Only ADMIN can directly modify grades
    // EXAM_COORDINATOR must use the grade change request approval workflow
    @PutMapping("/{gradeId}/modify")
    public ResponseEntity<GradeResponse> modify(
            @PathVariable Long gradeId,
            @Valid @RequestBody GradeChangeRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(gradeService.modifyGrade(gradeId, req));
    }

    // ADMIN, EXAM_COORDINATOR can approve grade changes
    @PatchMapping("/changes/{changeId}/approve")
    public ResponseEntity<GradeResponse> approveChange(
            @PathVariable Long changeId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR");
        return ResponseEntity.ok(gradeService.approveGradeChange(changeId));
    }

    // ADMIN, EXAM_COORDINATOR, AUDITOR can view grade history
    @GetMapping("/{gradeId}/history")
    public ResponseEntity<List<GradeChangeResponse>> history(
            @PathVariable Long gradeId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(gradeService.getGradeHistory(gradeId));
    }

    private void checkStudentAccess(HttpServletRequest request, Long studentId) {
        String role = roleValidator.getRole(request);
        if ("ADMIN".equals(role) || "TEACHER".equals(role) ||
            "EXAM_COORDINATOR".equals(role) || "AUDITOR".equals(role)) {
            return;
        }
        String email = roleValidator.getEmail(request);
        boolean linked = studentLinkService.isLinkedToStudent(studentId, email, role);
        if (!linked) {
            throw new UnauthorizedException(
                "Access denied. You are not linked to student ID: " + studentId
            );
        }
    }
}