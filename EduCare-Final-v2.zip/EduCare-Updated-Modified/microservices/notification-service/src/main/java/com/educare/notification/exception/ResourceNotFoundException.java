package com.educare.notification.exception;
public class ResourceNotFoundException extends RuntimeException {public ResourceNotFoundException(String m){super(m);}}