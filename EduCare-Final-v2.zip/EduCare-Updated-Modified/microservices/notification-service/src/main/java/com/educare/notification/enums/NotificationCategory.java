package com.educare.notification.enums;
public enum NotificationCategory { ATTENDANCE, GRADE, EVENT, GENERAL }