package com.educare.notification.controller;

import com.educare.notification.dto.request.NotificationRequest;
import com.educare.notification.dto.response.NotificationResponse;
import com.educare.notification.security.RoleValidator;
import com.educare.notification.service.NotificationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;
    private final RoleValidator roleValidator;

    // ADMIN, TEACHER, EXAM_COORDINATOR can create notifications
    @PostMapping
    public ResponseEntity<NotificationResponse> create(
            @Valid @RequestBody NotificationRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR");
        return ResponseEntity.ok(notificationService.createNotification(req));
    }

    /**
     * Returns ONLY the logged-in user's own notifications.
     * userId is read from X-User-Email → looked up internally.
     * No userId in URL — nobody can read someone else's notifications.
     */
    @GetMapping("/my")
    public ResponseEntity<List<NotificationResponse>> myNotifications(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR", "AUDITOR");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(notificationService.getMyNotifications(email));
    }

    // Mark as read — user can only mark their own
    @PatchMapping("/{id}/read")
    public ResponseEntity<NotificationResponse> markRead(
            @PathVariable Long id,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(notificationService.markAsRead(id));
    }
}
