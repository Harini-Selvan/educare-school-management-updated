package com.educare.notification.enums;
public enum NotificationStatus { UNREAD, READ }