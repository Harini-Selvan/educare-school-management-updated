package com.educare.notification.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MessageRequest {
    @NotNull  private Long fromUserId;
    @NotNull  private Long toUserId;
    @NotBlank @Email private String fromEmail;
    @NotBlank @Email private String toEmail;
    @NotBlank private String content;
}
