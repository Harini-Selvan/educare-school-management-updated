package com.educare.notification.repository;

import com.educare.notification.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {
    // Used for inbox — messages received by this email
    List<Message> findByToEmail(String toEmail);
    // Used for sent — messages sent by this email
    List<Message> findByFromEmail(String fromEmail);
    // Keep these for backward compatibility
    List<Message> findByToUserId(Long toUserId);
    List<Message> findByFromUserId(Long fromUserId);
}
