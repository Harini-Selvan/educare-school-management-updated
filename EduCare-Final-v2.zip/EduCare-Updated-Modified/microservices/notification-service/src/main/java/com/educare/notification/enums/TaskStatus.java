package com.educare.notification.enums;
public enum TaskStatus { PENDING, IN_PROGRESS, COMPLETED, OVERDUE }