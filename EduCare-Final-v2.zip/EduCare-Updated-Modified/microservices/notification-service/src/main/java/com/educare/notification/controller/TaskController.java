package com.educare.notification.controller;

import com.educare.notification.dto.request.TaskRequest;
import com.educare.notification.dto.response.TaskResponse;
import com.educare.notification.enums.TaskStatus;
import com.educare.notification.security.RoleValidator;
import com.educare.notification.service.TaskService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;
    private final RoleValidator roleValidator;

    // ADMIN can create tasks assigned to teachers or exam coordinators
    @PostMapping
    public ResponseEntity<TaskResponse> create(
            @Valid @RequestBody TaskRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(taskService.createTask(req));
    }

    // ADMIN can view all tasks
    @GetMapping
    public ResponseEntity<List<TaskResponse>> getAll(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN");
        return ResponseEntity.ok(taskService.getAllTasks());
    }

    // Returns only the logged-in user's own tasks
    @GetMapping("/my")
    public ResponseEntity<List<TaskResponse>> myTasks(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(taskService.getMyTasks(email));
    }

    // Users can update status of tasks assigned to them — marks as Completed in Admin view
    @PatchMapping("/{id}/status")
    public ResponseEntity<TaskResponse> updateStatus(
            @PathVariable Long id, @RequestParam TaskStatus status,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR");
        return ResponseEntity.ok(taskService.updateStatus(id, status));
    }

    // ADMIN can view overdue tasks
    @GetMapping("/overdue")
    public ResponseEntity<List<TaskResponse>> overdue(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "AUDITOR");
        return ResponseEntity.ok(taskService.getOverdueTasks());
    }
}
