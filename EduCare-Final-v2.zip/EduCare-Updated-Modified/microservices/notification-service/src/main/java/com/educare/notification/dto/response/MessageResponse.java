package com.educare.notification.dto.response;

import com.educare.notification.enums.MessageStatus;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class MessageResponse {
    private Long id;
    private Long fromUserId;
    private Long toUserId;
    private String fromEmail;
    private String toEmail;
    private String content;
    private MessageStatus status;
    private LocalDateTime sentAt;
}
