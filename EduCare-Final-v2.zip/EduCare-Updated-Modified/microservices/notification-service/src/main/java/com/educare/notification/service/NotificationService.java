package com.educare.notification.service;

import com.educare.notification.dto.request.NotificationRequest;
import com.educare.notification.dto.response.NotificationResponse;
import com.educare.notification.entity.Notification;
import com.educare.notification.enums.NotificationStatus;
import com.educare.notification.exception.ResourceNotFoundException;
import com.educare.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationResponse createNotification(NotificationRequest req) {
        Notification saved = notificationRepository.save(Notification.builder()
                .userId(req.getUserId())
                .recipientEmail(req.getRecipientEmail())
                .entityId(req.getEntityId())
                .message(req.getMessage())
                .category(req.getCategory())
                .status(NotificationStatus.UNREAD).build());
        log.info("Notification created — user: {}, category: {}", req.getUserId(), req.getCategory());
        return toResponse(saved);
    }

    /**
     * Returns ONLY the logged-in user's notifications.
     * Uses email from JWT header — no userId in URL.
     */
    public List<NotificationResponse> getMyNotifications(String email) {
        return notificationRepository.findByRecipientEmail(email)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public NotificationResponse markAsRead(Long id) {
        Notification n = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id));
        n.setStatus(NotificationStatus.READ);
        return toResponse(notificationRepository.save(n));
    }

    private NotificationResponse toResponse(Notification n) {
        return NotificationResponse.builder()
                .id(n.getId()).userId(n.getUserId())
                .recipientEmail(n.getRecipientEmail())
                .entityId(n.getEntityId()).message(n.getMessage())
                .category(n.getCategory()).status(n.getStatus())
                .createdAt(n.getCreatedAt()).build();
    }
}
