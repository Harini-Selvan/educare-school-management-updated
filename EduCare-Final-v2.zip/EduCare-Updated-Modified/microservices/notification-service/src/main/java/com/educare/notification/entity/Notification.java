package com.educare.notification.entity;

import com.educare.notification.enums.NotificationCategory;
import com.educare.notification.enums.NotificationStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    @Column(nullable = false) private String recipientEmail;
    private Long entityId;
    @Column(nullable = false, columnDefinition = "TEXT") private String message;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private NotificationCategory category;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private NotificationStatus status;
    @CreationTimestamp private LocalDateTime createdAt;
}
