package com.educare.notification.entity;

import com.educare.notification.enums.TaskStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "tasks")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Task {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private Long assignedTo;
    @Column(nullable = false) private String assignedToEmail;
    private Long relatedEntityId;
    @Column(nullable = false, columnDefinition = "TEXT") private String description;
    private LocalDate dueDate;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private TaskStatus status;
}
