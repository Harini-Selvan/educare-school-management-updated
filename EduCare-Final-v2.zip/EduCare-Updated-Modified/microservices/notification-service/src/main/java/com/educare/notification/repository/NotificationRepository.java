package com.educare.notification.repository;

import com.educare.notification.entity.Notification;
import com.educare.notification.enums.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByRecipientEmail(String recipientEmail);
    List<Notification> findByRecipientEmailAndStatus(String recipientEmail, NotificationStatus status);
    List<Notification> findByUserId(Long userId);
}
