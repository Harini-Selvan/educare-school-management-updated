package com.educare.notification.repository;

import com.educare.notification.entity.Task;
import com.educare.notification.enums.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByAssignedTo(Long assignedTo);
    List<Task> findByAssignedToEmail(String assignedToEmail);
    List<Task> findByStatus(TaskStatus status);
    List<Task> findByDueDateBeforeAndStatusNot(LocalDate date, TaskStatus status);
}
