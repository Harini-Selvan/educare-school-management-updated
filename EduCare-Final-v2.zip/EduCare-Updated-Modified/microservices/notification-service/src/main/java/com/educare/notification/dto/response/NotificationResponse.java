package com.educare.notification.dto.response;

import com.educare.notification.enums.NotificationCategory;
import com.educare.notification.enums.NotificationStatus;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NotificationResponse {
    private Long id;
    private Long userId;
    private String recipientEmail;
    private Long entityId;
    private String message;
    private NotificationCategory category;
    private NotificationStatus status;
    private LocalDateTime createdAt;
}
