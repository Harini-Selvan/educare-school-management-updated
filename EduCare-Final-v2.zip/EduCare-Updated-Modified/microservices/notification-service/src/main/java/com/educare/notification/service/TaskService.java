package com.educare.notification.service;

import com.educare.notification.dto.request.TaskRequest;
import com.educare.notification.dto.response.TaskResponse;
import com.educare.notification.entity.Task;
import com.educare.notification.enums.TaskStatus;
import com.educare.notification.exception.ResourceNotFoundException;
import com.educare.notification.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskResponse createTask(TaskRequest req) {
        Task saved = taskRepository.save(Task.builder()
                .assignedTo(req.getAssignedTo())
                .assignedToEmail(req.getAssignedToEmail())
                .relatedEntityId(req.getRelatedEntityId())
                .description(req.getDescription())
                .dueDate(req.getDueDate())
                .status(TaskStatus.PENDING).build());
        log.info("Task created — assignedTo: {} ({})", req.getAssignedTo(), req.getAssignedToEmail());
        return toResponse(saved);
    }

    /** Returns ALL tasks — ADMIN only */
    public List<TaskResponse> getAllTasks() {
        return taskRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    /** Returns only tasks assigned to the logged-in user */
    public List<TaskResponse> getMyTasks(String loggedInEmail) {
        return taskRepository.findByAssignedToEmail(loggedInEmail)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /** Updates task status — auto-updates to COMPLETED in Admin view when teacher marks done */
    public TaskResponse updateStatus(Long id, TaskStatus status) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + id));
        log.info("Task {} status: {} -> {}", id, task.getStatus(), status);
        task.setStatus(status);
        return toResponse(taskRepository.save(task));
    }

    public List<TaskResponse> getOverdueTasks() {
        return taskRepository.findByDueDateBeforeAndStatusNot(LocalDate.now(), TaskStatus.COMPLETED)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private TaskResponse toResponse(Task t) {
        return TaskResponse.builder()
                .id(t.getId()).assignedTo(t.getAssignedTo())
                .assignedToEmail(t.getAssignedToEmail())
                .relatedEntityId(t.getRelatedEntityId())
                .description(t.getDescription())
                .dueDate(t.getDueDate()).status(t.getStatus()).build();
    }
}
