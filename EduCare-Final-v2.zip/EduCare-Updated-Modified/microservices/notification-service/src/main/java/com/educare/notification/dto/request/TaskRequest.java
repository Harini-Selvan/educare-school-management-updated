package com.educare.notification.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class TaskRequest {
    @NotNull  private Long assignedTo;
    @NotBlank @Email private String assignedToEmail;
    private Long relatedEntityId;
    @NotBlank private String description;
    private LocalDate dueDate;
}
