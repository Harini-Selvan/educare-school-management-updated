package com.educare.notification.enums;
public enum MessageStatus { SENT, READ }