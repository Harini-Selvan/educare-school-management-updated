package com.educare.notification.dto.response;

import com.educare.notification.enums.TaskStatus;
import lombok.*;
import java.time.LocalDate;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TaskResponse {
    private Long id;
    private Long assignedTo;
    private String assignedToEmail;
    private Long relatedEntityId;
    private String description;
    private LocalDate dueDate;
    private TaskStatus status;
}
