package com.educare.notification.dto.request;

import com.educare.notification.enums.NotificationCategory;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull  private Long userId;
    @NotBlank @Email private String recipientEmail;
    private Long entityId;
    @NotBlank private String message;
    @NotNull  private NotificationCategory category;
}
