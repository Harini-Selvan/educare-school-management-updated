package com.educare.notification.service;

import com.educare.notification.dto.request.MessageRequest;
import com.educare.notification.dto.response.MessageResponse;
import com.educare.notification.entity.Message;
import com.educare.notification.enums.MessageStatus;
import com.educare.notification.repository.MessageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MessageService {

    private final MessageRepository messageRepository;

    public MessageResponse sendMessage(MessageRequest req) {
        Message saved = messageRepository.save(Message.builder()
                .fromUserId(req.getFromUserId())
                .toUserId(req.getToUserId())
                .fromEmail(req.getFromEmail())
                .toEmail(req.getToEmail())
                .content(req.getContent())
                .status(MessageStatus.SENT).build());
        log.info("Message sent — from: {} ({}), to: {} ({})",
                req.getFromUserId(), req.getFromEmail(),
                req.getToUserId(), req.getToEmail());
        return toResponse(saved);
    }

    /**
     * Returns ONLY messages received by the logged-in user's email.
     * Email comes from X-User-Email header set by JwtRequestFilter.
     * No URL parameter — users cannot snoop on others.
     */
    public List<MessageResponse> getMyInbox(String loggedInEmail) {
        return messageRepository.findByToEmail(loggedInEmail)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Returns ONLY messages sent by the logged-in user's email.
     * Email comes from X-User-Email header set by JwtRequestFilter.
     * No URL parameter — users cannot snoop on others.
     */
    public List<MessageResponse> getMySent(String loggedInEmail) {
        return messageRepository.findByFromEmail(loggedInEmail)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private MessageResponse toResponse(Message m) {
        return MessageResponse.builder()
                .id(m.getId())
                .fromUserId(m.getFromUserId())
                .toUserId(m.getToUserId())
                .fromEmail(m.getFromEmail())
                .toEmail(m.getToEmail())
                .content(m.getContent())
                .status(m.getStatus())
                .sentAt(m.getSentAt()).build();
    }
}
