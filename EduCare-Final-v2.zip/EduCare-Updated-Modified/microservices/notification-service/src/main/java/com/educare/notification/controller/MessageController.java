package com.educare.notification.controller;

import com.educare.notification.dto.request.MessageRequest;
import com.educare.notification.dto.response.MessageResponse;
import com.educare.notification.security.RoleValidator;
import com.educare.notification.service.MessageService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;
    private final RoleValidator roleValidator;

    // ADMIN, TEACHER, PARENT can send messages
    @PostMapping
    public ResponseEntity<MessageResponse> send(
            @Valid @RequestBody MessageRequest req,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT");
        return ResponseEntity.ok(messageService.sendMessage(req));
    }

    /**
     * Returns ONLY the logged-in user's own inbox.
     * Email is read from X-User-Email header (set by JwtRequestFilter).
     * No userId in URL — nobody can read someone else's inbox.
     */
    @GetMapping("/inbox")
    public ResponseEntity<List<MessageResponse>> inbox(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(messageService.getMyInbox(email));
    }

    /**
     * Returns ONLY the logged-in user's own sent messages.
     * Email is read from X-User-Email header (set by JwtRequestFilter).
     * No userId in URL — nobody can read someone else's sent messages.
     */
    @GetMapping("/sent")
    public ResponseEntity<List<MessageResponse>> sent(HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR");
        String email = roleValidator.getEmail(request);
        return ResponseEntity.ok(messageService.getMySent(email));
    }
}
