-- ============================================
-- EduCare Sample Data
-- Passwords are all: password123
-- BCrypt hash of 'password123'
-- ============================================

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE audit_logs;
TRUNCATE TABLE tasks;
TRUNCATE TABLE audit_packages;
TRUNCATE TABLE kpis;
TRUNCATE TABLE reports;
TRUNCATE TABLE messages;
TRUNCATE TABLE notifications;
TRUNCATE TABLE grade_changes;
TRUNCATE TABLE grades;
TRUNCATE TABLE exams;
TRUNCATE TABLE attendance_records;
TRUNCATE TABLE teacher_assignments;
TRUNCATE TABLE enrollment_records;
TRUNCATE TABLE teachers;
TRUNCATE TABLE classes;
TRUNCATE TABLE students;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- Users (password = 'password123' for all)
-- ============================================
INSERT INTO users (name, role, email, phone, password, status) VALUES
('Super Admin',       'ADMIN',            'admin@educare.com',       '9000000001', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Principal Sharma',  'ADMIN',            'principal@educare.com',   '9000000002', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Mr. Ravi Kumar',    'TEACHER',          'ravi@educare.com',        '9000000003', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Ms. Priya Nair',    'TEACHER',          'priya@educare.com',       '9000000004', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Mr. Suresh Das',    'TEACHER',          'suresh@educare.com',      '9000000005', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Arjun Reddy',       'STUDENT',          'arjun@educare.com',       '9000000006', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Sneha Iyer',        'STUDENT',          'sneha@educare.com',       '9000000007', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Kiran Patel',       'STUDENT',          'kiran@educare.com',       '9000000008', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Divya Menon',       'STUDENT',          'divya@educare.com',       '9000000009', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Rahul Verma',       'STUDENT',          'rahul@educare.com',       '9000000010', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Mrs. Lakshmi',      'PARENT',           'lakshmi@gmail.com',       '9000000011', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Mr. Patel Sr.',     'PARENT',           'patelsr@gmail.com',       '9000000012', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Exam Coord Anita',  'EXAM_COORDINATOR', 'anita@educare.com',       '9000000013', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE'),
('Auditor Bose',      'AUDITOR',          'auditor@educare.com',     '9000000014', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iYqiSfFSdZ8oH.3l5OT7GCDHFa2C', 'ACTIVE');

-- ============================================
-- Students
-- ============================================
INSERT INTO students (name, dob, gender, contact_info, program, status) VALUES
('Arjun Reddy',  '2005-03-15', 'MALE',   '{"phone":"9000000006","address":"Hyderabad"}', 'Science',   'ACTIVE'),
('Sneha Iyer',   '2005-07-22', 'FEMALE', '{"phone":"9000000007","address":"Chennai"}',   'Commerce',  'ACTIVE'),
('Kiran Patel',  '2006-01-10', 'MALE',   '{"phone":"9000000008","address":"Ahmedabad"}', 'Science',   'ACTIVE'),
('Divya Menon',  '2005-11-05', 'FEMALE', '{"phone":"9000000009","address":"Kochi"}',     'Arts',      'ACTIVE'),
('Rahul Verma',  '2006-06-18', 'MALE',   '{"phone":"9000000010","address":"Delhi"}',     'Commerce',  'ACTIVE');

-- ============================================
-- Classes
-- ============================================
INSERT INTO classes (name, grade_level, schedule_json, capacity, status) VALUES
('Class 10-A Science',  'Grade 10', '{"mon":"09:00","tue":"10:00","wed":"09:00","thu":"10:00","fri":"09:00"}', 40, 'ACTIVE'),
('Class 10-B Commerce', 'Grade 10', '{"mon":"11:00","tue":"09:00","wed":"11:00","thu":"09:00","fri":"11:00"}', 40, 'ACTIVE'),
('Class 11-A Science',  'Grade 11', '{"mon":"08:00","tue":"08:00","wed":"08:00","thu":"08:00","fri":"08:00"}', 35, 'ACTIVE');

-- ============================================
-- Teachers
-- ============================================
INSERT INTO teachers (name, department, contact_info, status) VALUES
('Mr. Ravi Kumar',  'Physics',    '{"phone":"9000000003","email":"ravi@educare.com"}',   'ACTIVE'),
('Ms. Priya Nair',  'Mathematics','{"phone":"9000000004","email":"priya@educare.com"}',  'ACTIVE'),
('Mr. Suresh Das',  'Commerce',   '{"phone":"9000000005","email":"suresh@educare.com"}', 'ACTIVE');

-- ============================================
-- Teacher Assignments
-- ============================================
INSERT INTO teacher_assignments (teacher_id, class_id, assigned_by, status) VALUES
(1, 1, 1, 'ACTIVE'),
(2, 1, 1, 'ACTIVE'),
(2, 3, 1, 'ACTIVE'),
(3, 2, 1, 'ACTIVE');

-- ============================================
-- Enrollment Records
-- ============================================
INSERT INTO enrollment_records (student_id, class_id, status) VALUES
(1, 1, 'ENROLLED'),
(2, 2, 'ENROLLED'),
(3, 1, 'ENROLLED'),
(4, 3, 'ENROLLED'),
(5, 2, 'ENROLLED');

-- ============================================
-- Attendance Records
-- ============================================
INSERT INTO attendance_records (student_id, class_id, date, status, recorded_by) VALUES
(1, 1, CURDATE() - INTERVAL 4 DAY, 'PRESENT', 3),
(1, 1, CURDATE() - INTERVAL 3 DAY, 'PRESENT', 3),
(1, 1, CURDATE() - INTERVAL 2 DAY, 'ABSENT',  3),
(1, 1, CURDATE() - INTERVAL 1 DAY, 'PRESENT', 3),
(2, 2, CURDATE() - INTERVAL 4 DAY, 'PRESENT', 5),
(2, 2, CURDATE() - INTERVAL 3 DAY, 'LATE',    5),
(2, 2, CURDATE() - INTERVAL 2 DAY, 'PRESENT', 5),
(3, 1, CURDATE() - INTERVAL 2 DAY, 'PRESENT', 3),
(3, 1, CURDATE() - INTERVAL 1 DAY, 'ABSENT',  3);

-- ============================================
-- Exams
-- ============================================
INSERT INTO exams (class_id, scheduled_at, subject, status) VALUES
(1, NOW() + INTERVAL 7 DAY,  'Physics Mid-Term',     'SCHEDULED'),
(1, NOW() + INTERVAL 14 DAY, 'Mathematics Mid-Term', 'SCHEDULED'),
(2, NOW() + INTERVAL 10 DAY, 'Accountancy Mid-Term', 'SCHEDULED'),
(3, NOW() - INTERVAL 5 DAY,  'Physics Unit Test',    'COMPLETED');

-- ============================================
-- Grades (for the completed exam)
-- ============================================
INSERT INTO grades (student_id, exam_id, grade_value, submitted_by, status) VALUES
(4, 4, 88.50, 3, 'PUBLISHED');

-- ============================================
-- Notifications
-- ============================================
INSERT INTO notifications (user_id, entity_id, message, category, status) VALUES
(6,  1, 'Your attendance has been marked for today.',        'ATTENDANCE', 'UNREAD'),
(6,  1, 'Physics Mid-Term exam scheduled for next week.',    'GRADE',      'UNREAD'),
(7,  2, 'Your attendance record has been updated.',          'ATTENDANCE', 'READ'),
(11, 1, 'Arjun was absent recently. Please check attendance records.', 'ATTENDANCE', 'UNREAD');

-- ============================================
-- Messages
-- ============================================
INSERT INTO messages (from_user_id, to_user_id, content, status) VALUES
(3,  11, 'Dear Parent, Arjun was absent yesterday. Please let us know the reason.', 'SENT'),
(11, 3,  'Thank you for informing. He was unwell. Will submit medical certificate.', 'READ'),
(4,  12, 'Kiran has been performing very well in Mathematics. Keep it up!',          'SENT');

-- ============================================
-- Tasks
-- ============================================
INSERT INTO tasks (assigned_to, description, due_date, status) VALUES
(3, 'Submit mid-term exam paper for Physics Class 10-A',          CURDATE() + INTERVAL 3 DAY,  'PENDING'),
(4, 'Update grades for Mathematics Unit Test',                    CURDATE() + INTERVAL 2 DAY,  'PENDING'),
(1, 'Generate Q1 attendance compliance report for all classes',   CURDATE() + INTERVAL 7 DAY,  'PENDING'),
(13,'Finalize exam schedule for Grade 11 final exams',            CURDATE() + INTERVAL 14 DAY, 'PENDING');

-- ============================================
-- KPIs
-- ============================================
INSERT INTO kpis (name, definition, target, current_value, reporting_period) VALUES
('Attendance Rate',          'Percentage of students present on average per day', 95.00, 87.50, 'Q1-2024'),
('Grade Pass Rate',          'Percentage of students scoring above 60%',          90.00, 82.00, 'Q1-2024'),
('Enrollment Completion',    'Percentage of enrolled students still active',       98.00, 96.00, 'Q1-2024'),
('Parent Engagement Rate',   'Percentage of parents who logged in this month',    70.00, 45.00, 'Q1-2024');

-- ============================================
-- Audit Log (initial entries)
-- ============================================
INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details) VALUES
(1, 'SYSTEM_INIT', 'SYSTEM', NULL, 'EduCare system initialized with sample data'),
(1, 'CREATE',      'CLASS',  1,    'Created class: Class 10-A Science'),
(1, 'CREATE',      'CLASS',  2,    'Created class: Class 10-B Commerce'),
(1, 'ASSIGN',      'TEACHER_ASSIGNMENT', 1, 'Assigned Mr. Ravi Kumar to Class 10-A');
