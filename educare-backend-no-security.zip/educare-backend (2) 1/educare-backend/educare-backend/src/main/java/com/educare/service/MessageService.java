package com.educare.service;

import com.educare.dto.request.MessageRequest;
import com.educare.dto.response.MessageResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Message;
import com.educare.model.User;
import com.educare.repository.MessageRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MessageService {

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;

    public List<MessageResponse> getInbox(Long userId) {
        return messageRepository.findAllMessagesForUser(userId)
            .stream().map(MessageResponse::from).toList();
    }

    public List<MessageResponse> getConversation(Long userId1, Long userId2) {
        return messageRepository.findConversation(userId1, userId2)
            .stream().map(MessageResponse::from).toList();
    }

    public MessageResponse sendMessage(MessageRequest request, User fromUser) {
        User toUser = userRepository.findById(request.getToUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User", request.getToUserId()));
        Message message = Message.builder()
            .fromUser(fromUser)
            .toUser(toUser)
            .content(request.getContent())
            .status(Message.MessageStatus.SENT)
            .build();
        return MessageResponse.from(messageRepository.save(message));
    }

    public MessageResponse markAsRead(Long id) {
        Message message = messageRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Message", id));
        message.setStatus(Message.MessageStatus.READ);
        return MessageResponse.from(messageRepository.save(message));
    }

    public void deleteMessage(Long id) {
        Message message = messageRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Message", id));
        message.setStatus(Message.MessageStatus.DELETED);
        messageRepository.save(message);
    }
}
