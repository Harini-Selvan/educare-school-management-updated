package com.educare.service;

import com.educare.dto.request.TaskRequest;
import com.educare.dto.response.TaskResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Task;
import com.educare.model.User;
import com.educare.repository.TaskRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public List<TaskResponse> getTasksByUser(Long userId) {
        return taskRepository.findByAssignedToUserId(userId)
            .stream().map(TaskResponse::from).toList();
    }

    public List<TaskResponse> getMyPendingTasks(Long userId) {
        return taskRepository.findByAssignedToUserIdAndStatus(userId, Task.TaskStatus.PENDING)
            .stream().map(TaskResponse::from).toList();
    }

    public List<TaskResponse> getOverdueTasks() {
        return taskRepository.findByDueDateBeforeAndStatusNot(LocalDate.now(), Task.TaskStatus.COMPLETED)
            .stream().map(TaskResponse::from).toList();
    }

    public TaskResponse createTask(TaskRequest request) {
        User assignedTo = userRepository.findById(request.getAssignedToUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User", request.getAssignedToUserId()));
        Task task = Task.builder()
            .assignedTo(assignedTo)
            .description(request.getDescription())
            .dueDate(request.getDueDate())
            .relatedEntityId(request.getRelatedEntityId())
            .status(Task.TaskStatus.PENDING)
            .build();
        return TaskResponse.from(taskRepository.save(task));
    }

    public TaskResponse updateTaskStatus(Long id, Task.TaskStatus status) {
        Task task = taskRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Task", id));
        task.setStatus(status);
        return TaskResponse.from(taskRepository.save(task));
    }

    public void deleteTask(Long id) {
        if (!taskRepository.existsById(id))
            throw new ResourceNotFoundException("Task", id);
        taskRepository.deleteById(id);
    }
}
