package com.educare.service;

import com.educare.dto.request.StudentRequest;
import com.educare.dto.response.StudentResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Student;
import com.educare.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public List<StudentResponse> getAllStudents() {
        return studentRepository.findAll().stream().map(StudentResponse::from).toList();
    }

    public StudentResponse getStudentById(Long id) {
        return StudentResponse.from(findById(id));
    }

    public StudentResponse createStudent(StudentRequest request) {
        Student student = Student.builder()
            .name(request.getName())
            .dob(request.getDob())
            .gender(request.getGender())
            .contactInfo(request.getContactInfo())
            .program(request.getProgram())
            .status(request.getStatus() != null ? request.getStatus() : Student.StudentStatus.ACTIVE)
            .build();
        return StudentResponse.from(studentRepository.save(student));
    }

    public StudentResponse updateStudent(Long id, StudentRequest request) {
        Student student = findById(id);
        if (request.getName() != null) student.setName(request.getName());
        if (request.getDob() != null) student.setDob(request.getDob());
        if (request.getGender() != null) student.setGender(request.getGender());
        if (request.getContactInfo() != null) student.setContactInfo(request.getContactInfo());
        if (request.getProgram() != null) student.setProgram(request.getProgram());
        if (request.getStatus() != null) student.setStatus(request.getStatus());
        return StudentResponse.from(studentRepository.save(student));
    }

    public void deleteStudent(Long id) {
        Student student = findById(id);
        student.setStatus(Student.StudentStatus.INACTIVE);
        studentRepository.save(student);
    }

    public List<StudentResponse> searchStudents(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name)
            .stream().map(StudentResponse::from).toList();
    }

    public Student findById(Long id) {
        return studentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Student", id));
    }
}
