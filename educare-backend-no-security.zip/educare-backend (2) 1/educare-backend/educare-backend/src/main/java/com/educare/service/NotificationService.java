package com.educare.service;

import com.educare.dto.request.NotificationRequest;
import com.educare.dto.response.NotificationResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Notification;
import com.educare.model.User;
import com.educare.repository.NotificationRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public List<NotificationResponse> getByUser(Long userId) {
        return notificationRepository.findByUserUserId(userId)
            .stream().map(NotificationResponse::from).toList();
    }

    public List<NotificationResponse> getUnreadByUser(Long userId) {
        return notificationRepository.findByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD)
            .stream().map(NotificationResponse::from).toList();
    }

    public long countUnread(Long userId) {
        return notificationRepository.countByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
    }

    public NotificationResponse createNotification(NotificationRequest request) {
        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
        Notification notification = Notification.builder()
            .user(user)
            .message(request.getMessage())
            .category(request.getCategory() != null ? request.getCategory() : Notification.NotificationCategory.GENERAL)
            .entityId(request.getEntityId())
            .status(Notification.NotificationStatus.UNREAD)
            .build();
        return NotificationResponse.from(notificationRepository.save(notification));
    }

    public NotificationResponse markAsRead(Long id) {
        Notification n = notificationRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Notification", id));
        n.setStatus(Notification.NotificationStatus.READ);
        return NotificationResponse.from(notificationRepository.save(n));
    }

    public void markAllAsRead(Long userId) {
        List<Notification> unread = notificationRepository
            .findByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
        unread.forEach(n -> n.setStatus(Notification.NotificationStatus.READ));
        notificationRepository.saveAll(unread);
    }
}
