package com.educare.dto.request;

import com.educare.model.Notification;
import com.educare.model.User;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class NotificationRequest {

    // For single-user notification
    private Long userId;

    @NotBlank(message = "Message is required")
    private String message;

    // Title/Subject of notification
    private String title;

    private Notification.NotificationCategory category;
    private Long entityId;

    // For broadcast to a specific role (STUDENT, TEACHER, PARENT, etc.)
    // Leave null to broadcast to ALL users
    private User.Role targetRole;
}
