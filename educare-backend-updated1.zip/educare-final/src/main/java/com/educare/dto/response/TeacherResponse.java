package com.educare.dto.response;

import com.educare.model.Teacher;
import lombok.*;

@Data @Builder @AllArgsConstructor @NoArgsConstructor
public class TeacherResponse {
    private Long teacherId;
    private String name;
    private String department;
    private String contactInfo;
    private String email;
    private Long userId;
    private Teacher.TeacherStatus status;

    public static TeacherResponse from(Teacher t) {
        return TeacherResponse.builder()
            .teacherId(t.getTeacherId())
            .name(t.getName())
            .department(t.getDepartment())
            .contactInfo(t.getContactInfo())
            .email(t.getEmail())
            .userId(t.getUser() != null ? t.getUser().getUserId() : null)
            .status(t.getStatus())
            .build();
    }
}
