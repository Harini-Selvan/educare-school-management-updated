package com.educare.dto.response;

import com.educare.model.Notification;
import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NotificationResponse {
    private Long notificationId;
    private Long userId;
    private String userName;
    private Long sentByUserId;
    private String sentByName;
    private Long entityId;
    private String title;
    private String message;
    private Notification.NotificationCategory category;
    private Notification.NotificationStatus status;
    private String targetRole;
    private Boolean isBroadcast;
    private LocalDateTime createdAt;

    public static NotificationResponse from(Notification n) {
        return NotificationResponse.builder()
            .notificationId(n.getNotificationId())
            .userId(n.getUser().getUserId())
            .userName(n.getUser().getName())
            .sentByUserId(n.getSentBy() != null ? n.getSentBy().getUserId() : null)
            .sentByName(n.getSentBy() != null ? n.getSentBy().getName() : null)
            .entityId(n.getEntityId())
            .title(n.getTitle())
            .message(n.getMessage())
            .category(n.getCategory())
            .status(n.getStatus())
            .targetRole(n.getTargetRole())
            .isBroadcast(n.getIsBroadcast())
            .createdAt(n.getCreatedAt())
            .build();
    }
}
