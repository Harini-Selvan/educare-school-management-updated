package com.educare.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${app.mail.from}")
    private String fromEmail;

    @Value("${app.school.name}")
    private String schoolName;

    // ============================================
    // Send user credentials email (Admin use only)
    // ============================================
    public void sendUserCredentials(String toEmail, String userName, String password, String role) {
        String subject = schoolName + " - Your Account Credentials";
        String body = """
                Welcome to %s, %s!

                Your account has been created. Here are your login credentials:

                Email    : %s
                Password : %s
                Role     : %s

                Please change your password after first login.
                If you have any issues, contact your school administrator.

                - %s Team
                """.formatted(schoolName, userName, toEmail, password, role, schoolName);

        sendEmail(toEmail, subject, body);
    }

    // ============================================
    // Send teacher message to parent via email
    // ============================================
    public void sendTeacherMessageToParent(String parentEmail, String parentName,
                                            String teacherName, String studentName,
                                            String subject, String messageContent) {
        String emailSubject = schoolName + " - Message from Teacher: " + subject;
        String body = """
                Dear %s,

                You have received a message from %s regarding your child %s:

                --------------------------------------------------
                %s
                --------------------------------------------------

                Please login to the parent portal to view more details.
                Portal: http://localhost:3000

                - %s Team
                """.formatted(parentName, teacherName, studentName, messageContent, schoolName);

        sendEmail(parentEmail, emailSubject, body);
    }

    // ============================================
    // Send notification email (used by all 3 admin notification endpoints)
    // ============================================
    public void sendNotificationEmail(String toEmail, String userName, String title, String message) {
        String subject = schoolName + " - " + (title != null ? title : "New Notification");
        String body = """
                Dear %s,

                %s

                --------------------------------------------------
                %s
                --------------------------------------------------

                Login to your portal to view more details.
                Portal: http://localhost:3000

                - %s Team
                """.formatted(userName, title != null ? title : "You have a new notification", message, schoolName);

        sendEmail(toEmail, subject, body);
    }

    // ============================================
    // Broadcast email - delegates to sendNotificationEmail
    // ============================================
    public void sendBroadcastEmail(String toEmail, String userName, String title, String message) {
        sendNotificationEmail(toEmail, userName, title, message);
    }

    // ============================================
    // Core plain text email sender
    // ============================================
    public void sendEmail(String to, String subject, String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            mailSender.send(message);
            log.info("Email sent successfully to: {}", to);
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage());
            // Log but don't throw - email failure should not break the main flow
        }
    }
}
