package com.educare.service;

import com.educare.dto.request.LoginRequest;
import com.educare.dto.request.RegisterRequest;
import com.educare.dto.response.AuthResponse;
import com.educare.exception.BadRequestException;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.AuditLog;
import com.educare.model.User;
import com.educare.repository.AuditLogRepository;
import com.educare.repository.UserRepository;
import com.educare.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * IAM — Authentication Service.
 *
 * Login uses Spring Security's AuthenticationManager (backed by DaoAuthenticationProvider
 * + UserDetailsServiceImpl) so the full Spring Security IAM pipeline is exercised:
 * - Credentials validation via PasswordEncoder
 * - Account status checks (enabled, non-locked, non-expired) via UserDetails
 * - Audit trail written on every login
 *
 * Register is ADMIN ONLY — enforced both here and via @PreAuthorize on the controller.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final EmailService emailService;
    private final AuthenticationManager authenticationManager;

    // ============================================
    // Login — any user (public endpoint)
    // Uses Spring Security AuthenticationManager for proper IAM flow
    // ============================================
    public AuthResponse login(LoginRequest request) {
        try {
            // This triggers DaoAuthenticationProvider → UserDetailsServiceImpl → User (UserDetails)
            // It checks: credentials, isEnabled(), isAccountNonLocked(), isAccountNonExpired()
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    request.getEmail(),
                    request.getPassword()
                )
            );

            User user = (User) authentication.getPrincipal();

            // Append-only audit log
            auditLogRepository.save(AuditLog.builder()
                .user(user)
                .action("LOGIN")
                .resourceType("AUTH")
                .details("User logged in successfully")
                .build());

            String token = jwtUtil.generateToken(user);

            return AuthResponse.builder()
                .token(token)
                .type("Bearer")
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .build();

        } catch (DisabledException e) {
            throw new BadRequestException("Account is inactive. Contact administrator.");
        } catch (LockedException e) {
            throw new BadRequestException("Account is suspended. Contact administrator.");
        } catch (BadCredentialsException e) {
            throw new BadRequestException("Invalid email or password.");
        }
    }

    // ============================================
    // Register — ADMIN ONLY
    // @PreAuthorize("hasRole('ADMIN')") on controller + role check here = double guard
    // Admin registers users and optionally sends credentials via email
    // ============================================
    public AuthResponse registerByAdmin(RegisterRequest request, User adminUser) {
        // Double-check: only admin can call this (controller also enforces via @PreAuthorize)
        if (adminUser == null || adminUser.getRole() != User.Role.ADMIN) {
            throw new BadRequestException("Only administrators can register new users.");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        String rawPassword = request.getPassword();

        User user = User.builder()
            .name(request.getName())
            .email(request.getEmail())
            .password(passwordEncoder.encode(rawPassword))
            .role(request.getRole())
            .phone(request.getPhone())
            .status(User.UserStatus.ACTIVE)
            .build();

        User saved = userRepository.save(user);

        // Audit log
        auditLogRepository.save(AuditLog.builder()
            .user(adminUser)
            .action("REGISTER_USER")
            .resourceType("USER")
            .resourceId(saved.getUserId())
            .details("Admin " + adminUser.getName() + " registered new user: "
                + saved.getEmail() + " with role: " + saved.getRole())
            .build());

        // Send credentials email to new user if requested
        if (request.isSendCredentialsEmail()) {
            try {
                emailService.sendUserCredentials(
                    saved.getEmail(),
                    saved.getName(),
                    rawPassword,
                    saved.getRole().name()
                );
                log.info("Credentials email sent to: {}", saved.getEmail());
            } catch (Exception e) {
                log.warn("Could not send credentials email to {}: {}", saved.getEmail(), e.getMessage());
            }
        }

        log.info("Admin {} registered new user {} with role {}",
            adminUser.getUserId(), saved.getEmail(), saved.getRole());

        String token = jwtUtil.generateToken(saved);

        return AuthResponse.builder()
            .token(token)
            .type("Bearer")
            .userId(saved.getUserId())
            .name(saved.getName())
            .email(saved.getEmail())
            .role(saved.getRole())
            .build();
    }
}
