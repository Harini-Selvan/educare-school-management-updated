package com.educare.service;

import com.educare.dto.response.UserResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.User;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(UserResponse::from).toList();
    }

    public UserResponse getUserById(Long id) {
        return UserResponse.from(findById(id));
    }

    public List<UserResponse> getUsersByRole(User.Role role) {
        return userRepository.findByRole(role).stream().map(UserResponse::from).toList();
    }

    public UserResponse updateUserStatus(Long id, User.UserStatus status) {
        User user = findById(id);
        user.setStatus(status);
        return UserResponse.from(userRepository.save(user));
    }

    public UserResponse updateUser(Long id, String name, String phone) {
        User user = findById(id);
        if (name != null) user.setName(name);
        if (phone != null) user.setPhone(phone);
        return UserResponse.from(userRepository.save(user));
    }

    public User findById(Long id) {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }
}
