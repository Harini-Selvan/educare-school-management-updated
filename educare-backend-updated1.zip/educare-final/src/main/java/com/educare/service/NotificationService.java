package com.educare.service;

import com.educare.dto.request.NotificationRequest;
import com.educare.dto.response.NotificationResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Notification;
import com.educare.model.User;
import com.educare.repository.NotificationRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final EmailService emailService;

    // ============================================
    // Get notifications for a specific user
    // ============================================
    public List<NotificationResponse> getByUser(Long userId) {
        return notificationRepository.findByUserUserId(userId)
            .stream().map(NotificationResponse::from).toList();
    }

    public List<NotificationResponse> getUnreadByUser(Long userId) {
        return notificationRepository.findByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD)
            .stream().map(NotificationResponse::from).toList();
    }

    public long countUnread(Long userId) {
        return notificationRepository.countByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
    }

    // ============================================
    // Admin: Send notification to a single user
    // Sends in-app notification + email
    // ============================================
    public NotificationResponse sendToUser(NotificationRequest request, User adminUser) {
        User targetUser = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));

        Notification.NotificationCategory category =
            request.getCategory() != null ? request.getCategory() : Notification.NotificationCategory.GENERAL;

        Notification notification = Notification.builder()
            .user(targetUser)
            .sentBy(adminUser)
            .title(request.getTitle())
            .message(request.getMessage())
            .category(category)
            .entityId(request.getEntityId())
            .isBroadcast(false)
            .status(Notification.NotificationStatus.UNREAD)
            .build();

        NotificationResponse response = NotificationResponse.from(notificationRepository.save(notification));

        // Send email to the individual user
        try {
            emailService.sendNotificationEmail(
                targetUser.getEmail(),
                targetUser.getName(),
                request.getTitle() != null ? request.getTitle() : "New Notification",
                request.getMessage()
            );
            log.info("Email sent to user {} for individual notification", targetUser.getUserId());
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", targetUser.getEmail(), e.getMessage());
        }

        log.info("Admin {} sent notification + email to user {}", adminUser.getUserId(), targetUser.getUserId());
        return response;
    }

    // ============================================
    // Admin: Broadcast notification to ALL users
    // Sends in-app notification + email to everyone
    // ============================================
    public List<NotificationResponse> broadcastToAll(NotificationRequest request, User adminUser) {
        List<User> allUsers = userRepository.findAll();
        List<NotificationResponse> responses = new ArrayList<>();

        Notification.NotificationCategory category =
            request.getCategory() != null ? request.getCategory() : Notification.NotificationCategory.ANNOUNCEMENT;

        for (User targetUser : allUsers) {
            // Skip the admin themselves
            if (targetUser.getUserId().equals(adminUser.getUserId())) continue;

            Notification notification = Notification.builder()
                .user(targetUser)
                .sentBy(adminUser)
                .title(request.getTitle())
                .message(request.getMessage())
                .category(category)
                .entityId(request.getEntityId())
                .isBroadcast(true)
                .targetRole("ALL")
                .status(Notification.NotificationStatus.UNREAD)
                .build();

            responses.add(NotificationResponse.from(notificationRepository.save(notification)));

            // Send email to each user
            try {
                emailService.sendNotificationEmail(
                    targetUser.getEmail(),
                    targetUser.getName(),
                    request.getTitle() != null ? request.getTitle() : "School Announcement",
                    request.getMessage()
                );
            } catch (Exception e) {
                log.error("Failed to send email to {}: {}", targetUser.getEmail(), e.getMessage());
            }
        }

        log.info("Admin {} broadcast notification + email to {} users", adminUser.getUserId(), responses.size());
        return responses;
    }

    // ============================================
    // Admin: Broadcast notification to all users of a specific role
    // Sends in-app notification + email to all users of that role
    // ============================================
    public List<NotificationResponse> broadcastToRole(NotificationRequest request, User adminUser, User.Role role) {
        List<User> usersOfRole = userRepository.findByRole(role);
        List<NotificationResponse> responses = new ArrayList<>();

        Notification.NotificationCategory category =
            request.getCategory() != null ? request.getCategory() : Notification.NotificationCategory.ANNOUNCEMENT;

        for (User targetUser : usersOfRole) {
            Notification notification = Notification.builder()
                .user(targetUser)
                .sentBy(adminUser)
                .title(request.getTitle())
                .message(request.getMessage())
                .category(category)
                .entityId(request.getEntityId())
                .isBroadcast(true)
                .targetRole(role.name())
                .status(Notification.NotificationStatus.UNREAD)
                .build();

            responses.add(NotificationResponse.from(notificationRepository.save(notification)));

            // Send email to each user of that role
            try {
                emailService.sendNotificationEmail(
                    targetUser.getEmail(),
                    targetUser.getName(),
                    request.getTitle() != null ? request.getTitle() : "School Announcement",
                    request.getMessage()
                );
            } catch (Exception e) {
                log.error("Failed to send email to {}: {}", targetUser.getEmail(), e.getMessage());
            }
        }

        log.info("Admin {} broadcast to role {} - {} users notified via in-app + email",
            adminUser.getUserId(), role, responses.size());
        return responses;
    }

    // ============================================
    // Mark notification as read
    // ============================================
    public NotificationResponse markAsRead(Long id) {
        Notification n = notificationRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Notification", id));
        n.setStatus(Notification.NotificationStatus.READ);
        return NotificationResponse.from(notificationRepository.save(n));
    }

    public void markAllAsRead(Long userId) {
        List<Notification> unread = notificationRepository
            .findByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
        unread.forEach(n -> n.setStatus(Notification.NotificationStatus.READ));
        notificationRepository.saveAll(unread);
    }
}
