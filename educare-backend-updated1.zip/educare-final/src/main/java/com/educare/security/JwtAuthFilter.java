package com.educare.security;

import com.educare.model.User;
import com.educare.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;

/**
 * IAM — JWT Authentication Filter.
 * Intercepts every request, validates the JWT Bearer token,
 * loads the User (which implements UserDetails) and sets
 * the authentication in the SecurityContext.
 *
 * Only ACTIVE users pass; SUSPENDED/INACTIVE accounts are rejected.
 */
@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        final String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);

        try {
            String email = jwtUtil.extractEmail(token);

            if (email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                Optional<User> userOpt = userRepository.findByEmail(email);

                if (userOpt.isPresent()) {
                    User user = userOpt.get();

                    // Validate token AND check account is ACTIVE (not suspended/inactive)
                    if (jwtUtil.isTokenValid(token, email)
                            && user.isEnabled()
                            && user.isAccountNonLocked()) {

                        // Use authorities from UserDetails (User.getAuthorities())
                        UsernamePasswordAuthenticationToken authToken =
                                new UsernamePasswordAuthenticationToken(
                                        user,
                                        null,
                                        user.getAuthorities()   // ROLE_ADMIN, ROLE_TEACHER, etc.
                                );
                        authToken.setDetails(
                                new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(authToken);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("JWT authentication failed: " + e.getMessage());
            // Do not set auth — request proceeds as anonymous and will be rejected by filter chain
        }

        filterChain.doFilter(request, response);
    }
}
