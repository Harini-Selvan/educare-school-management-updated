package com.educare.repository;

import com.educare.model.TeacherAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeacherAssignmentRepository extends JpaRepository<TeacherAssignment, Long> {
    List<TeacherAssignment> findByTeacherTeacherId(Long teacherId);
    List<TeacherAssignment> findBySchoolClassClassId(Long classId);
    List<TeacherAssignment> findByStatus(TeacherAssignment.AssignStatus status);
    boolean existsByTeacherTeacherIdAndSchoolClassClassIdAndStatus(
        Long teacherId, Long classId, TeacherAssignment.AssignStatus status);
}
