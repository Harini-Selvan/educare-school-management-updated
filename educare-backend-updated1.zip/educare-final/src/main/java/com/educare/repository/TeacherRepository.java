package com.educare.repository;

import com.educare.model.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Long> {
    List<Teacher> findByStatus(Teacher.TeacherStatus status);
    List<Teacher> findByDepartment(String department);
    List<Teacher> findByNameContainingIgnoreCase(String name);
}
