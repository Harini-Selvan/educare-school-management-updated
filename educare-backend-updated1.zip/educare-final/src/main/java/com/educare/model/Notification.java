package com.educare.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "notification_id")
    private Long notificationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Who sent this notification (admin)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sent_by")
    private User sentBy;

    @Column(name = "entity_id")
    private Long entityId;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String message;

    // Title/Subject of notification
    @Column(name = "title", length = 255)
    private String title;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private NotificationCategory category = NotificationCategory.GENERAL;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private NotificationStatus status = NotificationStatus.UNREAD;

    // Target role - if admin sends to all of a role
    @Column(name = "target_role", length = 50)
    private String targetRole;

    // Whether this was a broadcast (sent to all or all of a role)
    @Column(name = "is_broadcast")
    @Builder.Default
    private Boolean isBroadcast = false;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public enum NotificationCategory {
        ATTENDANCE, GRADE, EVENT, GENERAL, ANNOUNCEMENT
    }

    public enum NotificationStatus {
        UNREAD, READ, ARCHIVED
    }
}
