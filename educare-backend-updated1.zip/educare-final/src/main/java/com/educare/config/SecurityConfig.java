package com.educare.config;

import com.educare.security.JwtAuthFilter;
import com.educare.security.UserDetailsServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final UserDetailsServiceImpl userDetailsService;

    /** Public endpoints — no token required */
    private static final String[] PUBLIC_URLS = {
        "/api/auth/login",
        "/swagger-ui/**",
        "/swagger-ui.html",
        "/api-docs/**",
        "/v3/api-docs/**"
    };

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(daoAuthenticationProvider())
            .authorizeHttpRequests(auth -> auth
                // Public
                .requestMatchers(PUBLIC_URLS).permitAll()

                // ── ADMIN ONLY ─────────────────────────────────────────────
                // Register users — ADMIN ONLY (also enforced via @PreAuthorize)
                .requestMatchers("/api/auth/register").hasRole("ADMIN")
                // User management — ADMIN ONLY
                .requestMatchers("/api/users/**").hasRole("ADMIN")
                // Teacher assignments — ADMIN ONLY
                .requestMatchers("/api/teacher-assignments/**").hasRole("ADMIN")
                // Audit / KPI — ADMIN + AUDITOR
                .requestMatchers("/api/audit-packages/**").hasAnyRole("ADMIN", "AUDITOR")
                .requestMatchers("/api/audit-logs/**").hasAnyRole("ADMIN", "AUDITOR")
                .requestMatchers("/api/kpis/**").hasAnyRole("ADMIN", "AUDITOR")
                // Reports — ADMIN + AUDITOR + EXAM_COORDINATOR
                .requestMatchers("/api/reports/**").hasAnyRole("ADMIN", "AUDITOR", "EXAM_COORDINATOR")

                // ── NOTIFICATIONS — SEND = ADMIN ONLY, READ = authenticated ──
                .requestMatchers("/api/notifications/send/**").hasRole("ADMIN")
                .requestMatchers("/api/notifications/broadcast/**").hasRole("ADMIN")
                .requestMatchers("/api/notifications/**").authenticated()

                // ── MESSAGES — SEND = TEACHER ONLY, READ = TEACHER/PARENT/ADMIN ──
                .requestMatchers("/api/messages/send").hasRole("TEACHER")
                .requestMatchers("/api/messages/**").hasAnyRole("ADMIN", "TEACHER", "PARENT")

                // ── EXAMS & GRADES ──────────────────────────────────────────
                .requestMatchers("/api/exams/**").hasAnyRole("ADMIN", "EXAM_COORDINATOR", "TEACHER")
                .requestMatchers("/api/grades/**").hasAnyRole("ADMIN", "EXAM_COORDINATOR", "TEACHER")
                .requestMatchers("/api/grade-changes/**").hasAnyRole("ADMIN", "EXAM_COORDINATOR")

                // ── ATTENDANCE ──────────────────────────────────────────────
                .requestMatchers("/api/attendance/**").hasAnyRole("ADMIN", "TEACHER", "PARENT", "STUDENT")

                // ── CLASSES ─────────────────────────────────────────────────
                .requestMatchers("/api/classes/**").hasAnyRole("ADMIN", "TEACHER", "STUDENT", "PARENT")

                // ── TEACHERS ────────────────────────────────────────────────
                .requestMatchers("/api/teachers/**").hasAnyRole("ADMIN", "TEACHER", "STUDENT", "PARENT")

                // ── STUDENTS ────────────────────────────────────────────────
                .requestMatchers("/api/students/**").hasAnyRole("ADMIN", "TEACHER", "STUDENT", "PARENT")
                .requestMatchers("/api/enrollments/**").hasAnyRole("ADMIN", "TEACHER")

                // ── CURRENT USER PROFILE ────────────────────────────────────
                .requestMatchers("/api/auth/me").authenticated()

                // Everything else requires authentication
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    /**
     * DaoAuthenticationProvider wires the UserDetailsService + PasswordEncoder
     * so Spring Security's AuthenticationManager can authenticate users from DB.
     * This is the core of the IAM module.
     */
    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(
            "http://localhost:3000",
            "http://localhost:5173",
            "http://localhost:9091"
        ));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
