package com.educare.controller;

import com.educare.dto.response.ApiResponse;
import com.educare.dto.response.NotificationResponse;
import com.educare.dto.request.NotificationRequest;
import com.educare.model.User;
import com.educare.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications", description = "In-app notifications — Only Admin can send")
public class NotificationController {

    private final NotificationService notificationService;

    // ============================================
    // Any authenticated user - view their notifications
    // ============================================
    @GetMapping("/my")
    @Operation(summary = "Get all my notifications")
    public ResponseEntity<ApiResponse<List<NotificationResponse>>> getMy(
            @AuthenticationPrincipal User currentUser) {
        return ResponseEntity.ok(ApiResponse.success(
            notificationService.getByUser(currentUser.getUserId())));
    }

    @GetMapping("/my/unread")
    @Operation(summary = "Get my unread notifications")
    public ResponseEntity<ApiResponse<List<NotificationResponse>>> getUnread(
            @AuthenticationPrincipal User currentUser) {
        return ResponseEntity.ok(ApiResponse.success(
            notificationService.getUnreadByUser(currentUser.getUserId())));
    }

    @GetMapping("/my/unread-count")
    @Operation(summary = "Get count of my unread notifications")
    public ResponseEntity<ApiResponse<Long>> getUnreadCount(
            @AuthenticationPrincipal User currentUser) {
        return ResponseEntity.ok(ApiResponse.success(
            notificationService.countUnread(currentUser.getUserId())));
    }

    @PutMapping("/{id}/read")
    @Operation(summary = "Mark a notification as read")
    public ResponseEntity<ApiResponse<NotificationResponse>> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Marked as read",
            notificationService.markAsRead(id)));
    }

    @PutMapping("/my/read-all")
    @Operation(summary = "Mark all my notifications as read")
    public ResponseEntity<ApiResponse<Void>> markAllRead(
            @AuthenticationPrincipal User currentUser) {
        notificationService.markAllAsRead(currentUser.getUserId());
        return ResponseEntity.ok(ApiResponse.success("All notifications marked as read", null));
    }

    // ============================================
    // ADMIN ONLY - Send notifications
    // ============================================
    @PostMapping("/send/user")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(
        summary = "Send notification to a specific user — ADMIN ONLY",
        description = "Admin sends an in-app notification to one specific user. Provide userId in the request."
    )
    public ResponseEntity<ApiResponse<NotificationResponse>> sendToUser(
            @Valid @RequestBody NotificationRequest request,
            @AuthenticationPrincipal User adminUser) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Notification sent",
                notificationService.sendToUser(request, adminUser)));
    }

    @PostMapping("/broadcast/all")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(
        summary = "Broadcast notification to ALL users — ADMIN ONLY",
        description = "Admin sends an in-app notification + email to every user in the system."
    )
    public ResponseEntity<ApiResponse<List<NotificationResponse>>> broadcastToAll(
            @Valid @RequestBody NotificationRequest request,
            @AuthenticationPrincipal User adminUser) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Broadcast sent to all users",
                notificationService.broadcastToAll(request, adminUser)));
    }

    @PostMapping("/broadcast/role")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(
        summary = "Broadcast notification to all users of a specific role — ADMIN ONLY",
        description = """
            Admin sends an in-app notification + email to all users of a specific role.
            Set targetRole in request body to: STUDENT, TEACHER, PARENT, ADMIN, EXAM_COORDINATOR, or AUDITOR
            """
    )
    public ResponseEntity<ApiResponse<List<NotificationResponse>>> broadcastToRole(
            @Valid @RequestBody NotificationRequest request,
            @AuthenticationPrincipal User adminUser) {
        if (request.getTargetRole() == null) {
            return ResponseEntity.badRequest()
                .body(ApiResponse.error("targetRole is required for role broadcast"));
        }
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(
                "Broadcast sent to all " + request.getTargetRole() + "s",
                notificationService.broadcastToRole(request, adminUser, request.getTargetRole())));
    }
}
