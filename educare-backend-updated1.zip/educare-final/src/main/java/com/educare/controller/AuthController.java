package com.educare.controller;

import com.educare.dto.request.LoginRequest;
import com.educare.dto.request.RegisterRequest;
import com.educare.dto.response.ApiResponse;
import com.educare.dto.response.AuthResponse;
import com.educare.model.User;
import com.educare.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Login and user registration — Register is Admin only")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    @Operation(
        summary = "Login",
        description = "Authenticate with email and password to receive a JWT token"
    )
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Login successful",
            authService.login(request)));
    }

    @PostMapping("/register")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(
        summary = "Register new user — ADMIN ONLY",
        description = """
            Only Admin can register new users.
            Set sendCredentialsEmail=true to automatically send login credentials to the user via email.
            Roles: STUDENT, TEACHER, PARENT, ADMIN, EXAM_COORDINATOR, AUDITOR
            """
    )
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody RegisterRequest request,
            @AuthenticationPrincipal User adminUser) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("User registered successfully",
                authService.registerByAdmin(request, adminUser)));
    }

    @GetMapping("/me")
    @Operation(summary = "Get current logged-in user profile")
    public ResponseEntity<ApiResponse<User>> me(@AuthenticationPrincipal User user) {
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }
}
