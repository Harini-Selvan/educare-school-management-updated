# EduCare Backend — Setup & Run Guide

## Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+

---

## Step 1 — Create MySQL Database

```sql
CREATE DATABASE educare_db;
```

---

## Step 2 — Configure application.properties

Open `src/main/resources/application.properties` and update:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/educare_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

---

## Step 3 — Build and Run

```bash
cd educare-backend
mvn clean install -DskipTests
mvn spring-boot:run
```

Server starts at: `http://localhost:8080`

---

## Step 4 — Open Swagger UI

```
http://localhost:8080/swagger-ui.html
```

---

## Step 5 — Login and Get JWT Token

In Swagger, call **POST /api/auth/login** with:

```json
{
  "email": "admin@educare.com",
  "password": "password123"
}
```

Copy the `token` from the response.

---

## Step 6 — Authorize in Swagger

1. Click the **Authorize** button (lock icon) at the top of Swagger UI
2. In the **bearerAuth** field, enter: `Bearer YOUR_TOKEN_HERE`
3. Click **Authorize** → **Close**
4. All secured APIs now work!

---

## Test Credentials (all use password: `password123`)

| Role             | Email                    |
|------------------|--------------------------|
| Admin            | admin@educare.com        |
| Principal        | principal@educare.com    |
| Teacher          | ravi@educare.com         |
| Teacher          | priya@educare.com        |
| Student          | arjun@educare.com        |
| Parent           | lakshmi@gmail.com        |
| Exam Coordinator | anita@educare.com        |
| Auditor          | auditor@educare.com      |

---

## API Modules in Swagger

| Tag               | Base URL                  | Access                        |
|-------------------|---------------------------|-------------------------------|
| Authentication    | /api/auth                 | Public                        |
| Users             | /api/users                | ADMIN only                    |
| Students          | /api/students             | ADMIN, TEACHER, STUDENT       |
| Classes           | /api/classes              | All roles                     |
| Enrollments       | /api/enrollments          | ADMIN, TEACHER                |
| Teachers          | /api/teachers             | ADMIN                         |
| Attendance        | /api/attendance           | ADMIN, TEACHER                |
| Exams             | /api/exams                | ADMIN, EXAM_COORDINATOR       |
| Grades            | /api/grades               | ADMIN, EXAM_COORDINATOR       |
| Grade Changes     | /api/grade-changes        | ADMIN, EXAM_COORDINATOR       |
| Notifications     | /api/notifications        | All authenticated             |
| Messages          | /api/messages             | All authenticated             |
| Tasks             | /api/tasks                | All authenticated             |
| Reports           | /api/reports              | ADMIN, AUDITOR                |
| Audit Logs        | /api/audit-logs           | ADMIN, AUDITOR                |

---

## Project Structure

```
src/main/java/com/educare/
├── EduCareApplication.java
├── config/
│   ├── SecurityConfig.java       ← CORS, RBAC rules, JWT filter
│   └── SwaggerConfig.java        ← OpenAPI with Bearer auth
├── controller/                   ← 14 REST controllers
├── service/                      ← 14 service classes
├── repository/                   ← 17 JPA repositories
├── model/                        ← 17 JPA entities
├── dto/
│   ├── request/                  ← 13 request DTOs
│   └── response/                 ← 9 response DTOs
├── exception/
│   ├── GlobalExceptionHandler.java
│   ├── ResourceNotFoundException.java
│   └── BadRequestException.java
└── security/
    ├── JwtUtil.java
    └── JwtAuthFilter.java

src/main/resources/
├── application.properties
├── schema.sql                    ← 17 CREATE TABLE statements
└── data.sql                      ← Sample data for all tables
```
