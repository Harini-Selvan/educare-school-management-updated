// SHARED SECURITY CONFIG PATTERN
// Copy this into each service's config/ package, adjusting the package name.
// Example: for student-service → package com.educare.student.config;

package com.educare.task.config;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.config.Customizer;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(Customizer.withDefaults())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                // Internal notification endpoint (no JWT required — internal network only)
                .requestMatchers("/api/v1/notifications/internal/**").permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(new GatewayJwtFilter(jwtSecret),
                    UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    /**
     * Reads X-User-Id and X-User-Role headers injected by the API Gateway.
     * Falls back to validating a raw Bearer token if headers are absent
     * (useful for local development without the gateway).
     */
    @Slf4j
    public static class GatewayJwtFilter extends OncePerRequestFilter {

        private final String secret;

        public GatewayJwtFilter(String secret) {
            this.secret = secret;
        }

        @Override
        protected void doFilterInternal(HttpServletRequest request,
                                        HttpServletResponse response,
                                        FilterChain chain)
                throws ServletException, IOException {

            // Primary path: headers injected by the gateway
            String userId = request.getHeader("X-User-Id");
            String role   = request.getHeader("X-User-Role");
            String email  = request.getHeader("X-User-Email");

            if (userId != null && role != null) {
                var auth = new UsernamePasswordAuthenticationToken(
                        email != null ? email : userId,
                        null,
                        List.of(new SimpleGrantedAuthority("ROLE_" + role)));
                SecurityContextHolder.getContext().setAuthentication(auth);
                chain.doFilter(request, response);
                return;
            }

            // Fallback path: raw Bearer token (local dev only)
            String authHeader = request.getHeader("Authorization");
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7);
                try {
                    Claims claims = Jwts.parserBuilder()
                            .setSigningKey(Keys.hmacShaKeyFor(secret.getBytes()))
                            .build()
                            .parseClaimsJws(token)
                            .getBody();

                    String claimEmail = claims.get("email", String.class);
                    String claimRole  = claims.get("role",  String.class);

                    // Null check: if role is missing, deny access
                    if (claimEmail == null || claimRole == null) {
                        log.warn("JWT token missing required claims. Email: {}, Role: {}", claimEmail, claimRole);
                        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                        return;
                    }

                    var auth = new UsernamePasswordAuthenticationToken(
                            claimEmail,
                            null,
                            List.of(new SimpleGrantedAuthority("ROLE_" + claimRole)));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                    log.debug("JWT token validated for user {} with role {}", claimEmail, claimRole);
                } catch (JwtException ex) {
                    log.warn("JWT validation failed: {}", ex.getMessage());
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    return;
                }
            } else if (authHeader != null) {
                log.warn("Invalid authorization header format");
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }

            chain.doFilter(request, response);
        }
    }
}
