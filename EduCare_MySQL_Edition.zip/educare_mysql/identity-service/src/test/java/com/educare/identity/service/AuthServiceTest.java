package com.educare.identity.service;

import com.educare.identity.dto.AuthDTOs.*;
import com.educare.identity.entity.AuditLog;
import com.educare.identity.entity.Role;
import com.educare.identity.entity.User;
import com.educare.identity.exception.UnauthorizedException;
import com.educare.identity.repository.AuditLogRepository;
import com.educare.identity.repository.UserRepository;
import com.educare.identity.util.JwtUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock UserRepository userRepo;
    @Mock PasswordEncoder encoder;
    @Mock JwtUtil jwtUtil;
    @Mock AuditLogRepository auditRepo;
    @InjectMocks AuthService authService;

    @Test
    @DisplayName("login with valid credentials returns JWT")
    void loginSuccess() {
        User user = User.builder()
                .userId(1L).email("a@b.com")
                .passwordHash("hash").role(Role.ADMIN)
                .name("Admin").status("ACTIVE").build();

        when(userRepo.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        when(encoder.matches("pass", "hash")).thenReturn(true);
        when(jwtUtil.generateToken(user)).thenReturn("jwt-token");

        LoginResponse res = authService.authenticate(new LoginRequest("a@b.com", "pass"));

        assertEquals("jwt-token", res.getToken());
        assertEquals("ADMIN", res.getRole());
        verify(auditRepo, times(1)).save(any(AuditLog.class));
    }

    @Test
    @DisplayName("login with wrong password throws UnauthorizedException")
    void loginWrongPassword() {
        User user = User.builder().email("a@b.com")
                .passwordHash("hash").status("ACTIVE").build();
        when(userRepo.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        when(encoder.matches("wrong", "hash")).thenReturn(false);

        assertThrows(UnauthorizedException.class, () ->
                authService.authenticate(new LoginRequest("a@b.com", "wrong")));
    }

    @Test
    @DisplayName("login with inactive account throws UnauthorizedException")
    void loginInactiveUser() {
        User user = User.builder().email("a@b.com")
                .passwordHash("hash").status("INACTIVE").build();
        when(userRepo.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        when(encoder.matches("pass", "hash")).thenReturn(true);

        assertThrows(UnauthorizedException.class, () ->
                authService.authenticate(new LoginRequest("a@b.com", "pass")));
    }

    @Test
    @DisplayName("login with non-existent email throws UnauthorizedException")
    void loginUserNotFound() {
        when(userRepo.findByEmail(anyString())).thenReturn(Optional.empty());

        assertThrows(UnauthorizedException.class, () ->
                authService.authenticate(new LoginRequest("noone@b.com", "pass")));
    }
}
