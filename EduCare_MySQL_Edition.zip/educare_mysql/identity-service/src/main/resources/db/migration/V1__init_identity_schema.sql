-- V1__init_identity_schema.sql

CREATE TABLE IF NOT EXISTS users (
    user_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(200) NOT NULL,
    role          VARCHAR(50)  NOT NULL CHECK (role IN
                  ('STUDENT','TEACHER','PARENT','ADMIN','EXAM_COORDINATOR','AUDITOR')),
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone         VARCHAR(20),
    status        VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    created_at    DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email  ON users(email);
CREATE INDEX idx_users_role   ON users(role);
CREATE INDEX idx_users_status ON users(status);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT      NOT NULL REFERENCES users(user_id),
    action        VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100),
    resource_id   BIGINT,
    details       TEXT,
    timestamp     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Append-only: revoke UPDATE/DELETE from app user in production
CREATE INDEX idx_audit_user_id   ON audit_log(user_id);
CREATE INDEX idx_audit_timestamp ON audit_log(timestamp);
CREATE INDEX idx_audit_action    ON audit_log(action);

-- Seed default admin (password: Admin@1234 — change immediately)
INSERT IGNORE INTO users (name, role, email, password_hash, status)
VALUES (
    'System Admin',
    'ADMIN',
    'admin@school.edu',
    '$2a$12$Kj5xtFU1Z6V4cxV6JYTmxOc9yw3RKQoMgQOzrxmDmHb3PxHMH9K2.',
    'ACTIVE'
) ;
