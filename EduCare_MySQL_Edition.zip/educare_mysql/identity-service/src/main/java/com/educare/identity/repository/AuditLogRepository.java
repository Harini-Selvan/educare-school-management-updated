package com.educare.identity.repository;

import com.educare.identity.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    Page<AuditLog> findByUserId(Long userId, Pageable pageable);
    List<AuditLog> findByTimestampBetween(Instant from, Instant to);
    Page<AuditLog> findByAction(String action, Pageable pageable);
}
