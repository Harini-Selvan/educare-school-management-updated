package com.educare.identity.service;

import com.educare.identity.dto.AuthDTOs.UserDTO;
import com.educare.identity.entity.User;
import com.educare.identity.exception.ResourceNotFoundException;
import com.educare.identity.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepo;

    public Page<UserDTO> findAll(Pageable pageable) {
        return userRepo.findAll(pageable).map(this::toDTO);
    }

    public UserDTO findById(Long id) {
        return userRepo.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
    }

    @Transactional
    public UserDTO updateStatus(Long id, String status) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        user.setStatus(status);
        log.info("Updated status of user {} to {}", id, status);
        return toDTO(userRepo.save(user));
    }

    private UserDTO toDTO(User u) {
        return new UserDTO(u.getUserId(), u.getName(), u.getEmail(),
                u.getRole().name(), u.getPhone(), u.getStatus());
    }
}
