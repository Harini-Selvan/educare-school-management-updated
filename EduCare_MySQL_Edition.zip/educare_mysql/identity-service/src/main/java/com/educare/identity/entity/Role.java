package com.educare.identity.entity;

public enum Role {
    STUDENT,
    TEACHER,
    PARENT,
    ADMIN,
    EXAM_COORDINATOR,
    AUDITOR
}
