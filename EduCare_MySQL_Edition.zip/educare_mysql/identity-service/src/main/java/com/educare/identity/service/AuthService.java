package com.educare.identity.service;

import com.educare.identity.dto.AuthDTOs.*;
import com.educare.identity.entity.AuditLog;
import com.educare.identity.entity.Role;
import com.educare.identity.entity.User;
import com.educare.identity.exception.DuplicateResourceException;
import com.educare.identity.exception.ResourceNotFoundException;
import com.educare.identity.exception.UnauthorizedException;
import com.educare.identity.repository.AuditLogRepository;
import com.educare.identity.repository.UserRepository;
import com.educare.identity.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtUtil jwtUtil;
    private final AuditLogRepository auditRepo;

    @Transactional
    public LoginResponse authenticate(LoginRequest req) {
        User user = userRepo.findByEmail(req.getEmail())
                .orElseThrow(() -> new UnauthorizedException("Invalid credentials"));

        if (!encoder.matches(req.getPassword(), user.getPasswordHash()))
            throw new UnauthorizedException("Invalid credentials");

        if (!"ACTIVE".equals(user.getStatus()))
            throw new UnauthorizedException("Account is not active");

        String token = jwtUtil.generateToken(user);

        auditRepo.save(AuditLog.builder()
                .userId(user.getUserId())
                .action("LOGIN")
                .resourceType("USER")
                .resourceId(user.getUserId())
                .timestamp(Instant.now())
                .build());

        log.info("User {} authenticated successfully", user.getEmail());
        return new LoginResponse(token, user.getRole().name(), user.getName());
    }

    @Transactional
    public UserDTO register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail())) {
            throw new DuplicateResourceException("Email already registered: " + req.getEmail());
        }

        User user = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .passwordHash(encoder.encode(req.getPassword()))
                .role(Role.valueOf(req.getRole().toUpperCase()))
                .phone(req.getPhone())
                .status("ACTIVE")
                .build();

        User saved = userRepo.save(user);

        auditRepo.save(AuditLog.builder()
                .userId(saved.getUserId())
                .action("REGISTER")
                .resourceType("USER")
                .resourceId(saved.getUserId())
                .timestamp(Instant.now())
                .build());

        log.info("Registered new user: {} with role: {}", saved.getEmail(), saved.getRole());
        return toDTO(saved);
    }

    private UserDTO toDTO(User u) {
        return new UserDTO(u.getUserId(), u.getName(), u.getEmail(),
                u.getRole().name(), u.getPhone(), u.getStatus());
    }
}
