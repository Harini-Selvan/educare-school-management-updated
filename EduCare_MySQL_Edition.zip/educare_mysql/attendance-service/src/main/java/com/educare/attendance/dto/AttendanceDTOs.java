package com.educare.attendance.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.Instant;
import java.time.LocalDate;

public class AttendanceDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AttendanceRequest {
        @NotNull private Long studentId;
        @NotNull private Long classId;
        @NotNull private LocalDate date;
        @NotNull private String status;
        private String remarks;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AttendanceDTO {
        private Long attendanceId;
        private Long studentId;
        private Long classId;
        private LocalDate date;
        private String status;
        private Long recordedBy;
        private String remarks;
        private Instant createdAt;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AttendanceSummary {
        private Long studentId;
        private long totalDays;
        private long presentDays;
        private long absentDays;
        private double attendancePercent;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
