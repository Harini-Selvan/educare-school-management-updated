package com.educare.attendance.service;

import com.educare.attendance.config.NotificationServiceClient;
import com.educare.attendance.dto.AttendanceDTOs.*;
import com.educare.attendance.entity.AttendanceRecord;
import com.educare.attendance.exception.BusinessException;
import com.educare.attendance.exception.ResourceNotFoundException;
import com.educare.attendance.repository.AttendanceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttendanceService {

    private final AttendanceRepository attendanceRepo;
    private final NotificationServiceClient notifClient;

    @Transactional
    public AttendanceDTO mark(AttendanceRequest req, String teacherEmail) {
        if (attendanceRepo.existsByStudentIdAndClassIdAndDate(
                req.getStudentId(), req.getClassId(), req.getDate())) {
            throw new BusinessException("Attendance already marked for student "
                    + req.getStudentId() + " on " + req.getDate());
        }

        AttendanceRecord record = AttendanceRecord.builder()
                .studentId(req.getStudentId())
                .classId(req.getClassId())
                .date(req.getDate())
                .status(req.getStatus())
                .recordedBy(0L) // resolved from header in production
                .remarks(req.getRemarks())
                .build();

        AttendanceRecord saved = attendanceRepo.save(record);
        log.info("Attendance marked: student={} class={} status={} by={}",
                req.getStudentId(), req.getClassId(), req.getStatus(), teacherEmail);

        if ("ABSENT".equals(req.getStatus())) {
            notifClient.sendAbsenceNotification(req.getStudentId(), req.getClassId(),
                    req.getDate().toString());
        }

        return toDTO(saved);
    }

    public List<AttendanceDTO> findByStudentAndDateRange(Long studentId, LocalDate from, LocalDate to) {
        return attendanceRepo.findByStudentIdAndDateBetween(studentId, from, to)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<AttendanceDTO> findByClassAndDate(Long classId, LocalDate date) {
        return attendanceRepo.findByClassIdAndDate(classId, date)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public AttendanceSummary getSummary(Long studentId) {
        long total   = attendanceRepo.countByStudentId(studentId);
        long present = attendanceRepo.countByStudentIdAndStatus(studentId, "PRESENT");
        long absent  = attendanceRepo.countByStudentIdAndStatus(studentId, "ABSENT");
        double pct   = total > 0 ? (present * 100.0) / total : 0;
        return new AttendanceSummary(studentId, total, present, absent, pct);
    }

    private AttendanceDTO toDTO(AttendanceRecord r) {
        return AttendanceDTO.builder()
                .attendanceId(r.getAttendanceId())
                .studentId(r.getStudentId())
                .classId(r.getClassId())
                .date(r.getDate())
                .status(r.getStatus())
                .recordedBy(r.getRecordedBy())
                .remarks(r.getRemarks())
                .createdAt(r.getCreatedAt())
                .build();
    }
}
