package com.educare.attendance.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class NotificationServiceClient {

    private final RestTemplate restTemplate;

    @Value("${notification.service.url:http://notification-service:8086}")
    private String notificationServiceUrl;

    public void sendAbsenceNotification(Long studentId, Long classId, String date) {
        try {
            Map<String, Object> payload = Map.of(
                    "studentId", studentId,
                    "classId", classId,
                    "date", date,
                    "category", "ATTENDANCE",
                    "type", "ABSENCE_ALERT"
            );
            restTemplate.postForEntity(
                    notificationServiceUrl + "/api/v1/notifications/internal/absence",
                    payload,
                    Void.class
            );
            log.info("Absence notification sent for student {}", studentId);
        } catch (Exception e) {
            log.warn("Failed to send absence notification for student {}: {}", studentId, e.getMessage());
            // Non-critical: don't fail the attendance marking
        }
    }
}
