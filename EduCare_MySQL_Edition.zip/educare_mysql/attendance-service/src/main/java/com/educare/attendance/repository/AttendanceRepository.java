package com.educare.attendance.repository;

import com.educare.attendance.entity.AttendanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {

    List<AttendanceRecord> findByStudentIdAndDateBetween(Long studentId, LocalDate from, LocalDate to);

    List<AttendanceRecord> findByClassIdAndDate(Long classId, LocalDate date);

    @Query("SELECT COUNT(a) FROM AttendanceRecord a WHERE a.studentId = :studentId AND a.status = :status")
    long countByStudentIdAndStatus(Long studentId, String status);

    @Query("SELECT COUNT(a) FROM AttendanceRecord a WHERE a.studentId = :studentId")
    long countByStudentId(Long studentId);

    boolean existsByStudentIdAndClassIdAndDate(Long studentId, Long classId, LocalDate date);
}
