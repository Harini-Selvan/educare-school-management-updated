package com.educare.attendance.service;

import com.educare.attendance.config.NotificationServiceClient;
import com.educare.attendance.dto.AttendanceDTOs.*;
import com.educare.attendance.entity.AttendanceRecord;
import com.educare.attendance.exception.BusinessException;
import com.educare.attendance.repository.AttendanceRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AttendanceServiceTest {

    @Mock AttendanceRepository attendanceRepo;
    @Mock NotificationServiceClient notifClient;
    @InjectMocks AttendanceService attendanceService;

    @Test
    @DisplayName("marking ABSENT triggers parent notification")
    void absentTriggerNotification() {
        AttendanceRequest req = AttendanceRequest.builder()
                .studentId(1L).classId(5L)
                .date(LocalDate.now()).status("ABSENT").build();

        when(attendanceRepo.existsByStudentIdAndClassIdAndDate(1L, 5L, LocalDate.now())).thenReturn(false);
        when(attendanceRepo.save(any())).thenReturn(AttendanceRecord.builder()
                .attendanceId(1L).studentId(1L).classId(5L)
                .date(LocalDate.now()).status("ABSENT").recordedBy(0L).build());

        AttendanceDTO result = attendanceService.mark(req, "teacher@school.com");

        assertEquals("ABSENT", result.getStatus());
        verify(notifClient, times(1)).sendAbsenceNotification(eq(1L), eq(5L), anyString());
    }

    @Test
    @DisplayName("marking PRESENT does not trigger notification")
    void presentNoNotification() {
        AttendanceRequest req = AttendanceRequest.builder()
                .studentId(1L).classId(5L)
                .date(LocalDate.now()).status("PRESENT").build();

        when(attendanceRepo.existsByStudentIdAndClassIdAndDate(1L, 5L, LocalDate.now())).thenReturn(false);
        when(attendanceRepo.save(any())).thenReturn(AttendanceRecord.builder()
                .attendanceId(2L).studentId(1L).classId(5L)
                .date(LocalDate.now()).status("PRESENT").recordedBy(0L).build());

        attendanceService.mark(req, "teacher@school.com");
        verify(notifClient, never()).sendAbsenceNotification(anyLong(), anyLong(), anyString());
    }

    @Test
    @DisplayName("duplicate attendance throws BusinessException")
    void duplicateAttendance() {
        AttendanceRequest req = AttendanceRequest.builder()
                .studentId(1L).classId(5L)
                .date(LocalDate.now()).status("PRESENT").build();

        when(attendanceRepo.existsByStudentIdAndClassIdAndDate(1L, 5L, LocalDate.now())).thenReturn(true);

        assertThrows(BusinessException.class,
                () -> attendanceService.mark(req, "teacher@school.com"));
    }
}
