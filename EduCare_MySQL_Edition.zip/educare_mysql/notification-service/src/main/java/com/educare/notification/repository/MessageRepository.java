package com.educare.notification.repository;

import com.educare.notification.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {
    Page<Message> findByRecipientIdOrderBySentAtDesc(Long recipientId, Pageable pageable);
    Page<Message> findBySenderIdOrderBySentAtDesc(Long senderId, Pageable pageable);
}
