package com.educare.notification.service;

import com.educare.notification.dto.NotificationDTOs.*;
import com.educare.notification.entity.Message;
import com.educare.notification.entity.Notification;
import com.educare.notification.repository.MessageRepository;
import com.educare.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepo;
    private final MessageRepository messageRepo;
    private final JavaMailSender mailSender;

    @Transactional
    public void createAbsenceNotification(AbsenceAlert alert) {
        Notification n = Notification.builder()
                .recipientId(alert.getStudentId()) // in production: resolve parent ID
                .category("ATTENDANCE")
                .type("ABSENCE_ALERT")
                .message("Student was marked ABSENT on " + alert.getDate()
                        + " for class " + alert.getClassId())
                .status("UNREAD")
                .build();
        notificationRepo.save(n);
        log.info("Absence notification created for student {}", alert.getStudentId());

        // Optionally send email (fire-and-forget, non-blocking)
        try {
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setTo("parent@school.edu"); // in production: look up parent email
            mail.setSubject("Attendance Alert – Student Absence");
            mail.setText(n.getMessage());
            mailSender.send(mail);
        } catch (Exception e) {
            log.warn("Email delivery failed: {}", e.getMessage());
        }
    }

    public Page<NotificationDTO> getForUser(Long userId, Pageable pageable) {
        return notificationRepo.findByRecipientIdOrderByCreatedAtDesc(userId, pageable)
                .map(this::toDTO);
    }

    @Transactional
    public void markRead(Long notificationId) {
        notificationRepo.findById(notificationId).ifPresent(n -> {
            n.setStatus("READ");
            notificationRepo.save(n);
        });
    }

    @Transactional
    public MessageDTO sendMessage(MessageRequest req, Long senderId) {
        Message msg = Message.builder()
                .senderId(senderId)
                .recipientId(req.getRecipientId())
                .content(req.getContent())
                .status("SENT")
                .build();
        Message saved = messageRepo.save(msg);
        log.info("Message sent from {} to {}", senderId, req.getRecipientId());
        return toMessageDTO(saved);
    }

    private NotificationDTO toDTO(Notification n) {
        return NotificationDTO.builder()
                .notificationId(n.getNotificationId())
                .recipientId(n.getRecipientId())
                .category(n.getCategory())
                .type(n.getType())
                .message(n.getMessage())
                .status(n.getStatus())
                .createdAt(n.getCreatedAt())
                .build();
    }

    private MessageDTO toMessageDTO(Message m) {
        return MessageDTO.builder()
                .messageId(m.getMessageId())
                .senderId(m.getSenderId())
                .recipientId(m.getRecipientId())
                .content(m.getContent())
                .status(m.getStatus())
                .sentAt(m.getSentAt())
                .build();
    }
}
