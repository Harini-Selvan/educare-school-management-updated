package com.educare.notification.controller;

import com.educare.notification.dto.NotificationDTOs.*;
import com.educare.notification.service.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping("/api/v1/notifications")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Page<NotificationDTO>> getNotifications(
            @RequestParam Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(notificationService.getForUser(userId, PageRequest.of(page, size)));
    }

    @PutMapping("/api/v1/notifications/{id}/read")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> markRead(@PathVariable Long id) {
        notificationService.markRead(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/api/v1/messages")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    public ResponseEntity<MessageDTO> sendMessage(
            @Valid @RequestBody MessageRequest req,
            @RequestHeader("X-User-Id") Long senderId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(notificationService.sendMessage(req, senderId));
    }

    // Internal endpoint called by attendance-service (no JWT, internal network only)
    @PostMapping("/api/v1/notifications/internal/absence")
    public ResponseEntity<Void> handleAbsenceAlert(@RequestBody AbsenceAlert alert) {
        notificationService.createAbsenceNotification(alert);
        return ResponseEntity.ok().build();
    }
}
