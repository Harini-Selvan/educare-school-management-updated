package com.educare.notification.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.Instant;

public class NotificationDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class NotificationDTO {
        private Long notificationId;
        private Long recipientId;
        private String category;
        private String type;
        private String message;
        private String status;
        private Instant createdAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MessageRequest {
        @NotNull  private Long recipientId;
        @NotBlank private String content;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MessageDTO {
        private Long messageId;
        private Long senderId;
        private Long recipientId;
        private String content;
        private String status;
        private Instant sentAt;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AbsenceAlert {
        private Long studentId;
        private Long classId;
        private String date;
        private String category;
        private String type;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
