-- V1__init_student_schema.sql

CREATE TABLE IF NOT EXISTS students (
    student_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(200) NOT NULL,
    dob          DATE         NOT NULL,
    gender       VARCHAR(10),
    contact_info TEXT,
    program      VARCHAR(100),
    status       VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    created_at   DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_students_status  ON students(status);
CREATE INDEX idx_students_program ON students(program);

CREATE TABLE IF NOT EXISTS enrollment_records (
    enroll_id   BIGINT AUTO_INCREMENT    PRIMARY KEY,
    student_id  BIGINT       NOT NULL REFERENCES students(student_id),
    class_id    BIGINT       NOT NULL,
    enrolled_at DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status      VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE'
);

CREATE INDEX idx_enroll_student ON enrollment_records(student_id);
CREATE INDEX idx_enroll_class   ON enrollment_records(class_id);
CREATE UNIQUE INDEX idx_enroll_unique_active
    ON enrollment_records(student_id, class_id, status)
    WHERE status = 'ACTIVE';
