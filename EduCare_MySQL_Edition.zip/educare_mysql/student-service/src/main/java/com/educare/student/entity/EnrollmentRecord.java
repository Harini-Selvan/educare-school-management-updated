package com.educare.student.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "enrollment_records",
       uniqueConstraints = @UniqueConstraint(columnNames = {"student_id","class_id","status"}))
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @Column(nullable = false)
    private Long classId;

    @CreationTimestamp
    @Column(updatable = false)
    private Instant enrolledAt;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "ACTIVE";
}
