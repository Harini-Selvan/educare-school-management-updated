package com.educare.student.repository;

import com.educare.student.entity.EnrollmentRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnrollmentRepository extends JpaRepository<EnrollmentRecord, Long> {
    List<EnrollmentRecord> findByStudent_StudentId(Long studentId);
    long countByClassIdAndStatus(Long classId, String status);
    boolean existsByStudent_StudentIdAndClassIdAndStatus(Long studentId, Long classId, String status);
}
