package com.educare.student.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDate;

public class StudentDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class StudentDTO {
        private Long studentId;
        @NotBlank private String name;
        @NotNull  private LocalDate dob;
        private String gender;
        private String contactInfo;
        private String program;
        private String status;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class EnrollmentRequest {
        @NotNull private Long classId;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class EnrollmentDTO {
        private Long enrollId;
        private Long studentId;
        private Long classId;
        private Instant enrolledAt;
        private String status;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
