package com.educare.student.service;

import com.educare.student.dto.StudentDTOs.*;
import com.educare.student.entity.EnrollmentRecord;
import com.educare.student.entity.Student;
import com.educare.student.exception.BusinessException;
import com.educare.student.exception.ResourceNotFoundException;
import com.educare.student.repository.EnrollmentRepository;
import com.educare.student.repository.StudentRepository;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class StudentService {

    private final StudentRepository studentRepo;
    private final EnrollmentRepository enrollmentRepo;
    private static final int MAX_CLASS_CAPACITY = 40;

    public Page<StudentDTO> findAll(Pageable pageable) {
        return studentRepo.findAll(pageable).map(this::toDTO);
    }

    public StudentDTO findById(Long id) {
        return studentRepo.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
    }

    @Transactional
    public StudentDTO register(StudentDTO dto) {
        Student student = Student.builder()
                .name(dto.getName())
                .dob(dto.getDob())
                .gender(dto.getGender())
                .contactInfo(dto.getContactInfo())
                .program(dto.getProgram())
                .status("ACTIVE")
                .build();
        Student saved = studentRepo.save(student);
        log.info("Registered student: {}", saved.getStudentId());
        return toDTO(saved);
    }

    @Transactional
    public StudentDTO update(Long id, StudentDTO dto) {
        Student student = studentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
        student.setName(dto.getName());
        student.setDob(dto.getDob());
        student.setGender(dto.getGender());
        student.setContactInfo(dto.getContactInfo());
        student.setProgram(dto.getProgram());
        return toDTO(studentRepo.save(student));
    }

    public List<EnrollmentDTO> getEnrollments(Long studentId) {
        studentRepo.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));
        return enrollmentRepo.findByStudent_StudentId(studentId)
                .stream().map(this::toEnrollDTO).collect(Collectors.toList());
    }

    @Transactional
    public EnrollmentDTO enroll(Long studentId, EnrollmentRequest req) {
        Student student = studentRepo.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));

        if (enrollmentRepo.existsByStudent_StudentIdAndClassIdAndStatus(studentId, req.getClassId(), "ACTIVE")) {
            throw new BusinessException("Student already enrolled in this class");
        }

        long count = enrollmentRepo.countByClassIdAndStatus(req.getClassId(), "ACTIVE");
        if (count >= MAX_CLASS_CAPACITY) {
            throw new BusinessException("Class is at full capacity (" + MAX_CLASS_CAPACITY + ")");
        }

        EnrollmentRecord record = EnrollmentRecord.builder()
                .student(student)
                .classId(req.getClassId())
                .status("ACTIVE")
                .build();

        EnrollmentRecord saved = enrollmentRepo.save(record);
        log.info("Enrolled student {} in class {}", studentId, req.getClassId());
        return toEnrollDTO(saved);
    }

    @Transactional
    public int bulkImport(MultipartFile file) throws IOException, CsvValidationException {
        List<Student> students = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
            String[] line;
            reader.readNext(); // skip header
            while ((line = reader.readNext()) != null) {
                if (line.length < 3) continue;
                students.add(Student.builder()
                        .name(line[0].trim())
                        .dob(LocalDate.parse(line[1].trim()))
                        .gender(line[2].trim())
                        .contactInfo(line.length > 3 ? line[3].trim() : null)
                        .program(line.length > 4 ? line[4].trim() : null)
                        .status("ACTIVE")
                        .build());
            }
        }
        studentRepo.saveAll(students);
        log.info("Bulk imported {} students", students.size());
        return students.size();
    }

    private StudentDTO toDTO(Student s) {
        return StudentDTO.builder()
                .studentId(s.getStudentId())
                .name(s.getName())
                .dob(s.getDob())
                .gender(s.getGender())
                .contactInfo(s.getContactInfo())
                .program(s.getProgram())
                .status(s.getStatus())
                .build();
    }

    private EnrollmentDTO toEnrollDTO(EnrollmentRecord r) {
        return EnrollmentDTO.builder()
                .enrollId(r.getEnrollId())
                .studentId(r.getStudent().getStudentId())
                .classId(r.getClassId())
                .enrolledAt(r.getEnrolledAt())
                .status(r.getStatus())
                .build();
    }
}
