package com.educare.student.exception;
public class BusinessException extends RuntimeException {
    public BusinessException(String message) { super(message); }
}
