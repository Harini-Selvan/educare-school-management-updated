package com.educare.student.service;

import com.educare.student.dto.StudentDTOs.*;
import com.educare.student.entity.EnrollmentRecord;
import com.educare.student.entity.Student;
import com.educare.student.exception.BusinessException;
import com.educare.student.repository.EnrollmentRepository;
import com.educare.student.repository.StudentRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock StudentRepository studentRepo;
    @Mock EnrollmentRepository enrollmentRepo;
    @InjectMocks StudentService studentService;

    @Test
    @DisplayName("register student saves entity and returns DTO")
    void registerStudent() {
        StudentDTO dto = StudentDTO.builder()
                .name("Alice").dob(LocalDate.of(2010, 1, 1)).gender("F").build();
        Student entity = Student.builder()
                .studentId(1L).name("Alice").dob(LocalDate.of(2010, 1, 1))
                .gender("F").status("ACTIVE").build();

        when(studentRepo.save(any(Student.class))).thenReturn(entity);

        StudentDTO result = studentService.register(dto);

        assertNotNull(result);
        assertEquals("Alice", result.getName());
        verify(studentRepo).save(any(Student.class));
    }

    @Test
    @DisplayName("enroll student in valid class creates enrollment record")
    void enrollStudent() {
        Student student = Student.builder().studentId(1L).name("Alice").build();
        EnrollmentRecord record = EnrollmentRecord.builder()
                .enrollId(1L).student(student).classId(10L).status("ACTIVE").build();

        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));
        when(enrollmentRepo.existsByStudent_StudentIdAndClassIdAndStatus(1L, 10L, "ACTIVE")).thenReturn(false);
        when(enrollmentRepo.countByClassIdAndStatus(10L, "ACTIVE")).thenReturn(5L);
        when(enrollmentRepo.save(any(EnrollmentRecord.class))).thenReturn(record);

        EnrollmentDTO result = studentService.enroll(1L, new EnrollmentRequest(10L));

        assertNotNull(result);
        assertEquals(10L, result.getClassId());
        verify(enrollmentRepo).save(any(EnrollmentRecord.class));
    }

    @Test
    @DisplayName("enroll student in full class throws BusinessException")
    void enrollStudentFullClass() {
        Student student = Student.builder().studentId(1L).build();
        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));
        when(enrollmentRepo.existsByStudent_StudentIdAndClassIdAndStatus(1L, 10L, "ACTIVE")).thenReturn(false);
        when(enrollmentRepo.countByClassIdAndStatus(10L, "ACTIVE")).thenReturn(40L);

        assertThrows(BusinessException.class,
                () -> studentService.enroll(1L, new EnrollmentRequest(10L)));
    }

    @Test
    @DisplayName("enroll already-enrolled student throws BusinessException")
    void enrollDuplicate() {
        Student student = Student.builder().studentId(1L).build();
        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));
        when(enrollmentRepo.existsByStudent_StudentIdAndClassIdAndStatus(1L, 10L, "ACTIVE")).thenReturn(true);

        assertThrows(BusinessException.class,
                () -> studentService.enroll(1L, new EnrollmentRequest(10L)));
    }
}
