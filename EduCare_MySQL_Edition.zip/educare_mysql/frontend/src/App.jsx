import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute  from './components/common/ProtectedRoute';
import Navbar          from './components/common/Navbar';
import Sidebar         from './components/common/Sidebar';

// Pages
import Login           from './pages/Login';

// Admin
import AdminDashboard  from './components/admin/AdminDashboard';
import EnrollmentManager from './components/admin/EnrollmentManager';

// Teacher
import TeacherDashboard from './components/teacher/TeacherDashboard';
import AttendanceForm   from './components/teacher/AttendanceForm';

// Student
import StudentPortal   from './components/student/StudentPortal';

// Exam Coordinator
import ExamPanel       from './components/examcoord/ExamPanel';

// Compliance / Auditor
import AuditDashboard  from './components/compliance/AuditDashboard';

// Unauthorised page
const Unauthorized = () => (
  <div className="d-flex flex-column align-items-center justify-content-center" style={{ minHeight: '60vh' }}>
    <div className="fs-1">🚫</div>
    <h4 className="mt-3">Access Denied</h4>
    <p className="text-muted">You don't have permission to view this page.</p>
  </div>
);

// Notifications (simple)
const NotificationsPage = () => (
  <div><h5 className="fw-bold mb-3">Notifications</h5>
    <p className="text-muted">No new notifications.</p></div>
);

// Layout wrapping authenticated pages
const AppLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="d-flex flex-column" style={{ minHeight: '100vh', background: '#f5f7fb' }}>
      <Navbar toggleSidebar={() => setSidebarOpen(o => !o)} />
      <div className="d-flex flex-grow-1" style={{ marginTop: 0 }}>
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <main className="flex-grow-1 p-4" style={{ marginLeft: 0, minWidth: 0 }}>
          <div style={{ maxWidth: 1200, margin: '0 auto' }}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

// Root redirect by role
const RoleRedirect = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const map = {
    ADMIN:            '/admin',
    TEACHER:          '/teacher',
    STUDENT:          '/student',
    PARENT:           '/parent',
    EXAM_COORDINATOR: '/examcoord',
    AUDITOR:          '/compliance',
  };
  return <Navigate to={map[user.role] || '/login'} replace />;
};

const AppRoutes = () => (
  <Routes>
    {/* Public */}
    <Route path="/login"        element={<Login />} />
    <Route path="/unauthorized" element={<AppLayout><Unauthorized /></AppLayout>} />
    <Route path="/"             element={<RoleRedirect />} />

    {/* Admin */}
    <Route path="/admin" element={
      <ProtectedRoute allowedRoles={['ADMIN']}>
        <AppLayout><AdminDashboard /></AppLayout>
      </ProtectedRoute>
    } />
    <Route path="/admin/students" element={
      <ProtectedRoute allowedRoles={['ADMIN']}>
        <AppLayout><EnrollmentManager /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Teacher */}
    <Route path="/teacher" element={
      <ProtectedRoute allowedRoles={['TEACHER']}>
        <AppLayout><TeacherDashboard /></AppLayout>
      </ProtectedRoute>
    } />
    <Route path="/teacher/attendance" element={
      <ProtectedRoute allowedRoles={['TEACHER']}>
        <AppLayout><AttendanceForm /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Student */}
    <Route path="/student" element={
      <ProtectedRoute allowedRoles={['STUDENT']}>
        <AppLayout><StudentPortal /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Parent */}
    <Route path="/parent" element={
      <ProtectedRoute allowedRoles={['PARENT']}>
        <AppLayout>
          <div><h4 className="fw-bold">Parent Portal</h4>
            <p className="text-muted">View your child's performance and attendance.</p></div>
        </AppLayout>
      </ProtectedRoute>
    } />

    {/* Exam Coordinator */}
    <Route path="/examcoord" element={
      <ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}>
        <AppLayout><ExamPanel /></AppLayout>
      </ProtectedRoute>
    } />
    <Route path="/examcoord/exams" element={
      <ProtectedRoute allowedRoles={['EXAM_COORDINATOR']}>
        <AppLayout><ExamPanel /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Auditor / Compliance */}
    <Route path="/compliance" element={
      <ProtectedRoute allowedRoles={['AUDITOR', 'ADMIN']}>
        <AppLayout><AuditDashboard /></AppLayout>
      </ProtectedRoute>
    } />
    <Route path="/compliance/audit" element={
      <ProtectedRoute allowedRoles={['AUDITOR', 'ADMIN']}>
        <AppLayout><AuditDashboard /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Notifications (all authenticated) */}
    <Route path="/notifications" element={
      <ProtectedRoute allowedRoles={['ADMIN','TEACHER','STUDENT','PARENT','EXAM_COORDINATOR','AUDITOR']}>
        <AppLayout><NotificationsPage /></AppLayout>
      </ProtectedRoute>
    } />

    {/* Fallback */}
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  </BrowserRouter>
);

export default App;
