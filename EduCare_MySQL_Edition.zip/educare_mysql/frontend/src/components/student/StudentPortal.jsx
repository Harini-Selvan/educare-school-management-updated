import React, { useEffect, useState } from 'react';
import { gradesAPI, attendanceAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

// ── Grade View ──────────────────────────────────────────────────────────────
export const GradeView = ({ studentId }) => {
  const [grades,  setGrades]  = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!studentId) return;
    gradesAPI.byStudent(studentId)
      .then(r => setGrades(r.data))
      .finally(() => setLoading(false));
  }, [studentId]);

  const avg = grades.length
    ? (grades.reduce((s, g) => s + parseFloat(g.gradeValue), 0) / grades.length).toFixed(1)
    : null;

  const letterGrade = v => {
    if (v >= 90) return { label: 'A', color: 'success' };
    if (v >= 80) return { label: 'B', color: 'primary' };
    if (v >= 70) return { label: 'C', color: 'warning' };
    if (v >= 60) return { label: 'D', color: 'orange' };
    return { label: 'F', color: 'danger' };
  };

  if (loading) return <div className="text-center py-4"><div className="spinner-border spinner-border-sm" /></div>;

  return (
    <div>
      {avg && (
        <div className="alert alert-light d-flex align-items-center gap-3 mb-3">
          <div className="fs-3 fw-bold text-primary">{avg}</div>
          <div className="text-muted small">Overall average across {grades.length} exam(s)</div>
        </div>
      )}
      <div className="table-responsive">
        <table className="table table-sm align-middle">
          <thead className="table-light">
            <tr><th>Exam ID</th><th>Grade</th><th>Letter</th><th>Status</th><th>Submitted</th></tr>
          </thead>
          <tbody>
            {grades.map(g => {
              const { label, color } = letterGrade(g.gradeValue);
              return (
                <tr key={g.gradeId}>
                  <td className="text-muted small">#{g.examId}</td>
                  <td className="fw-bold">{g.gradeValue}</td>
                  <td><span className={`badge bg-${color}`}>{label}</span></td>
                  <td><span className={`badge ${g.status==='PUBLISHED'?'bg-success':'bg-secondary'}`}>{g.status}</span></td>
                  <td className="small text-muted">{g.submittedAt ? new Date(g.submittedAt).toLocaleDateString() : '—'}</td>
                </tr>
              );
            })}
            {grades.length === 0 && (
              <tr><td colSpan="5" className="text-center text-muted py-3">No grades available</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ── Student Portal ──────────────────────────────────────────────────────────
const StudentPortal = () => {
  const { user }                = useAuth();
  const [summary, setSummary]   = useState(null);
  const [activeTab, setTab]     = useState('grades');
  // In production, resolve studentId from userId via API call
  const studentId = 1; // placeholder

  useEffect(() => {
    attendanceAPI.summary(studentId)
      .then(r => setSummary(r.data))
      .catch(() => {});
  }, []);

  return (
    <div>
      <h4 className="fw-bold mb-1">My Portal</h4>
      <p className="text-muted small mb-4">Welcome, {user?.name}</p>

      {summary && (
        <div className="row g-3 mb-4">
          <div className="col-sm-4">
            <div className="card border-0 shadow-sm text-center p-3">
              <div className="fs-1">📋</div>
              <div className="fw-bold fs-4">{summary.presentDays}</div>
              <div className="text-muted small">Days Present</div>
            </div>
          </div>
          <div className="col-sm-4">
            <div className="card border-0 shadow-sm text-center p-3">
              <div className="fs-1">❌</div>
              <div className="fw-bold fs-4">{summary.absentDays}</div>
              <div className="text-muted small">Days Absent</div>
            </div>
          </div>
          <div className="col-sm-4">
            <div className="card border-0 shadow-sm text-center p-3">
              <div className="fs-1">📊</div>
              <div className={`fw-bold fs-4 ${summary.attendancePercent >= 75 ? 'text-success' : 'text-danger'}`}>
                {summary.attendancePercent?.toFixed(1)}%
              </div>
              <div className="text-muted small">Attendance Rate</div>
            </div>
          </div>
        </div>
      )}

      <ul className="nav nav-tabs mb-3">
        {['grades','attendance'].map(tab => (
          <li key={tab} className="nav-item">
            <button className={`nav-link ${activeTab===tab?'active':''}`}
                    onClick={() => setTab(tab)}>
              {tab === 'grades' ? '📝 My Grades' : '📋 Attendance'}
            </button>
          </li>
        ))}
      </ul>

      <div className="card border-0 shadow-sm">
        <div className="card-body">
          {activeTab === 'grades' && <GradeView studentId={studentId} />}
          {activeTab === 'attendance' && (
            <p className="text-muted text-center py-3">Select a date range to view attendance records.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentPortal;
