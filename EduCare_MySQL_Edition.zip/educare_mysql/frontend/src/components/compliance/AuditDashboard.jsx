import React, { useEffect, useState } from 'react';
import { usersAPI, reportsAPI } from '../../services/api';

const AuditDashboard = () => {
  const [logs,    setLogs]    = useState([]);
  const [reports, setReports] = useState([]);
  const [kpis,    setKpis]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab,     setTab]     = useState('logs');
  const [genMsg,  setGenMsg]  = useState('');

  useEffect(() => {
    Promise.all([
      usersAPI.auditLogs(),
      reportsAPI.list(),
      reportsAPI.kpis(),
    ]).then(([lr, rr, kr]) => {
      setLogs(lr.data.content    || []);
      setReports(rr.data.content || []);
      setKpis(kr.data);
    }).finally(() => setLoading(false));
  }, []);

  const generateAuditPackage = async () => {
    try {
      await reportsAPI.auditPackage({ title: `Audit Package ${new Date().toLocaleDateString()}` });
      setGenMsg('Audit package generation started. Check Reports tab.');
    } catch { setGenMsg('Failed to generate audit package.'); }
  };

  if (loading) return <div className="text-center py-5"><div className="spinner-border text-primary" /></div>;

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 className="fw-bold mb-0">Compliance & Audit</h4>
          <span className="text-muted small">Read-only audit view</span>
        </div>
        <button className="btn btn-outline-primary btn-sm" onClick={generateAuditPackage}>
          📦 Generate Audit Package
        </button>
      </div>

      {genMsg && <div className="alert alert-info py-2"><small>{genMsg}</small></div>}

      {kpis && (
        <div className="row g-3 mb-4">
          {[
            { label: 'Total Students', value: kpis.totalStudents, icon: '🎓' },
            { label: 'Avg Attendance', value: `${kpis.averageAttendanceRate?.toFixed(1)}%`, icon: '📋' },
            { label: 'Avg Grade',      value: kpis.averageGrade?.toFixed(1), icon: '📝' },
            { label: 'Pending Tasks',  value: kpis.pendingTasks, icon: '✅' },
          ].map(({ label, value, icon }) => (
            <div key={label} className="col-sm-6 col-xl-3">
              <div className="card border-0 shadow-sm p-3 d-flex flex-row align-items-center gap-3">
                <span className="fs-2">{icon}</span>
                <div><div className="text-muted small">{label}</div><div className="fw-bold fs-5">{value}</div></div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ul className="nav nav-tabs mb-3">
        {['logs', 'reports'].map(t => (
          <li key={t} className="nav-item">
            <button className={`nav-link ${tab===t?'active':''}`} onClick={() => setTab(t)}>
              {t === 'logs' ? '🔍 Audit Logs' : '📁 Reports'}
            </button>
          </li>
        ))}
      </ul>

      {tab === 'logs' && (
        <div className="card border-0 shadow-sm">
          <div className="table-responsive">
            <table className="table table-sm align-middle mb-0">
              <thead className="table-light">
                <tr><th>#</th><th>User ID</th><th>Action</th><th>Resource</th><th>Timestamp</th></tr>
              </thead>
              <tbody>
                {logs.map(log => (
                  <tr key={log.auditId}>
                    <td className="text-muted small">{log.auditId}</td>
                    <td className="small">{log.userId}</td>
                    <td><span className="badge bg-secondary">{log.action}</span></td>
                    <td className="small">{log.resourceType || '—'}</td>
                    <td className="small text-muted">{log.timestamp ? new Date(log.timestamp).toLocaleString() : '—'}</td>
                  </tr>
                ))}
                {logs.length === 0 && <tr><td colSpan="5" className="text-center py-4 text-muted">No audit logs</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'reports' && (
        <div className="card border-0 shadow-sm">
          <div className="table-responsive">
            <table className="table table-sm align-middle mb-0">
              <thead className="table-light">
                <tr><th>#</th><th>Title</th><th>Type</th><th>Status</th><th>Requested</th></tr>
              </thead>
              <tbody>
                {reports.map(r => (
                  <tr key={r.reportId}>
                    <td className="text-muted small">{r.reportId}</td>
                    <td className="small fw-semibold">{r.title}</td>
                    <td><span className="badge bg-info text-dark">{r.type}</span></td>
                    <td>
                      <span className={`badge ${r.status==='COMPLETED'?'bg-success':r.status==='FAILED'?'bg-danger':'bg-warning text-dark'}`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="small text-muted">
                      {r.requestedAt ? new Date(r.requestedAt).toLocaleString() : '—'}
                    </td>
                  </tr>
                ))}
                {reports.length === 0 && <tr><td colSpan="5" className="text-center py-4 text-muted">No reports</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuditDashboard;
