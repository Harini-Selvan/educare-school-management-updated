import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { reportsAPI, studentsAPI, classesAPI } from '../../services/api';

const StatCard = ({ title, value, icon, color, to }) => (
  <div className="col-sm-6 col-xl-3">
    <div className="card border-0 shadow-sm h-100">
      <div className="card-body d-flex align-items-center gap-3">
        <div className="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
             style={{ width: 56, height: 56, background: color + '22', fontSize: 24 }}>
          {icon}
        </div>
        <div>
          <div className="text-muted small">{title}</div>
          <div className="fw-bold fs-4">{value ?? '—'}</div>
        </div>
      </div>
      {to && (
        <div className="card-footer bg-transparent border-0 pt-0">
          <Link to={to} className="small text-decoration-none" style={{ color }}>View all →</Link>
        </div>
      )}
    </div>
  </div>
);

const AdminDashboard = () => {
  const [kpis,    setKpis]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');

  useEffect(() => {
    reportsAPI.kpis()
      .then(r => setKpis(r.data))
      .catch(() => setError('Failed to load KPIs'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: 300 }}>
      <div className="spinner-border text-primary" />
    </div>
  );

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 className="fw-bold mb-0">Admin Dashboard</h4>
          <span className="text-muted small">School overview</span>
        </div>
        <Link to="/admin/reports" className="btn btn-sm btn-outline-primary">
          Generate Report
        </Link>
      </div>

      {error && <div className="alert alert-warning">{error}</div>}

      <div className="row g-3 mb-4">
        <StatCard title="Total Students"  value={kpis?.totalStudents}  icon="🎓" color="#0d6efd" to="/admin/students" />
        <StatCard title="Teachers"        value={kpis?.totalTeachers}  icon="👩‍🏫" color="#198754" to="/admin/teachers" />
        <StatCard title="Classes"         value={kpis?.totalClasses}   icon="🏫" color="#fd7e14" to="/admin/classes" />
        <StatCard title="Pending Tasks"   value={kpis?.pendingTasks}   icon="✅" color="#dc3545" to="/admin/tasks" />
      </div>

      <div className="row g-3">
        <div className="col-md-6">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent fw-semibold">Attendance Rate</div>
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="display-6 fw-bold text-success">
                  {kpis?.averageAttendanceRate?.toFixed(1)}%
                </div>
                <div className="flex-grow-1">
                  <div className="progress" style={{ height: 12 }}>
                    <div className="progress-bar bg-success"
                         style={{ width: `${kpis?.averageAttendanceRate || 0}%` }} />
                  </div>
                  <small className="text-muted">School-wide average</small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent fw-semibold">Average Grade</div>
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="display-6 fw-bold text-primary">
                  {kpis?.averageGrade?.toFixed(1)}
                </div>
                <div className="flex-grow-1">
                  <div className="progress" style={{ height: 12 }}>
                    <div className="progress-bar bg-primary"
                         style={{ width: `${kpis?.averageGrade || 0}%` }} />
                  </div>
                  <small className="text-muted">Out of 100</small>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="col-12">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent fw-semibold">Quick Actions</div>
            <div className="card-body">
              <div className="d-flex flex-wrap gap-2">
                <Link to="/admin/students" className="btn btn-outline-primary btn-sm">+ Register Student</Link>
                <Link to="/admin/classes"  className="btn btn-outline-success btn-sm">+ Create Class</Link>
                <Link to="/admin/teachers" className="btn btn-outline-warning btn-sm">+ Add Teacher</Link>
                <Link to="/admin/users"    className="btn btn-outline-secondary btn-sm">+ Create User</Link>
                <Link to="/admin/reports"  className="btn btn-outline-info btn-sm">📊 Generate Report</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
