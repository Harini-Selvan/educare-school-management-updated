import React, { useEffect, useState } from 'react';
import { studentsAPI, classesAPI } from '../../services/api';

const EnrollmentManager = () => {
  const [students,  setStudents]  = useState([]);
  const [classes,   setClasses]   = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [page,      setPage]      = useState(0);
  const [totalPages,setTotalPages]= useState(0);
  const [showForm,  setShowForm]  = useState(false);
  const [enrolling, setEnrolling] = useState(null); // studentId
  const [classId,   setClassId]   = useState('');
  const [form,      setForm]      = useState({ name:'', dob:'', gender:'', program:'' });
  const [msg,       setMsg]       = useState('');

  const load = () => {
    setLoading(true);
    studentsAPI.list(page)
      .then(r => { setStudents(r.data.content); setTotalPages(r.data.totalPages); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [page]);
  useEffect(() => {
    classesAPI.list().then(r => setClasses(r.data.content || []));
  }, []);

  const handleRegister = async e => {
    e.preventDefault();
    try {
      await studentsAPI.create(form);
      setMsg('Student registered!'); setShowForm(false); setForm({ name:'', dob:'', gender:'', program:'' }); load();
    } catch (err) { setMsg(err.response?.data?.message || 'Error registering student'); }
  };

  const handleEnroll = async () => {
    if (!classId) return;
    try {
      await studentsAPI.enroll(enrolling, { classId: parseInt(classId) });
      setMsg('Enrolled successfully!'); setEnrolling(null); setClassId('');
    } catch (err) { setMsg(err.response?.data?.message || 'Enrollment failed'); }
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h5 className="fw-bold mb-0">Students</h5>
        <div className="d-flex gap-2">
          <label className="btn btn-outline-secondary btn-sm">
            📂 Import CSV
            <input type="file" className="d-none" accept=".csv"
              onChange={e => studentsAPI.import(e.target.files[0]).then(() => { setMsg('Import successful!'); load(); })} />
          </label>
          <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}>
            + Register Student
          </button>
        </div>
      </div>

      {msg && <div className="alert alert-info alert-dismissible py-2"><small>{msg}</small>
        <button className="btn-close btn-sm" onClick={() => setMsg('')} /></div>}

      {/* Register form */}
      {showForm && (
        <div className="card mb-3 border-primary">
          <div className="card-header fw-semibold">New Student</div>
          <div className="card-body">
            <form onSubmit={handleRegister}>
              <div className="row g-2">
                <div className="col-md-3">
                  <input className="form-control form-control-sm" placeholder="Full Name *"
                    value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))} required />
                </div>
                <div className="col-md-3">
                  <input type="date" className="form-control form-control-sm"
                    value={form.dob} onChange={e => setForm(p => ({...p, dob: e.target.value}))} required />
                </div>
                <div className="col-md-2">
                  <select className="form-select form-select-sm"
                    value={form.gender} onChange={e => setForm(p => ({...p, gender: e.target.value}))}>
                    <option value="">Gender</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input className="form-control form-control-sm" placeholder="Program"
                    value={form.program} onChange={e => setForm(p => ({...p, program: e.target.value}))} />
                </div>
                <div className="col-md-2 d-flex gap-1">
                  <button className="btn btn-success btn-sm flex-grow-1" type="submit">Save</button>
                  <button className="btn btn-outline-secondary btn-sm" type="button" onClick={() => setShowForm(false)}>✕</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Enroll modal */}
      {enrolling && (
        <div className="modal show d-block" style={{ background: 'rgba(0,0,0,.4)' }}>
          <div className="modal-dialog modal-sm">
            <div className="modal-content">
              <div className="modal-header py-2">
                <h6 className="modal-title">Enroll Student #{enrolling}</h6>
                <button className="btn-close btn-sm" onClick={() => setEnrolling(null)} />
              </div>
              <div className="modal-body">
                <select className="form-select form-select-sm" value={classId} onChange={e => setClassId(e.target.value)}>
                  <option value="">Select class…</option>
                  {classes.map(c => <option key={c.classId} value={c.classId}>{c.name}</option>)}
                </select>
              </div>
              <div className="modal-footer py-2">
                <button className="btn btn-primary btn-sm" onClick={handleEnroll}>Enroll</button>
                <button className="btn btn-outline-secondary btn-sm" onClick={() => setEnrolling(null)}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center py-5"><div className="spinner-border text-primary" /></div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-hover table-sm align-middle">
              <thead className="table-light">
                <tr>
                  <th>#</th><th>Name</th><th>DOB</th><th>Gender</th><th>Program</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map(s => (
                  <tr key={s.studentId}>
                    <td className="text-muted small">{s.studentId}</td>
                    <td className="fw-semibold">{s.name}</td>
                    <td className="small">{s.dob}</td>
                    <td className="small">{s.gender}</td>
                    <td className="small">{s.program || '—'}</td>
                    <td>
                      <span className={`badge ${s.status === 'ACTIVE' ? 'bg-success' : 'bg-secondary'}`}>
                        {s.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-outline-primary btn-sm py-0"
                              onClick={() => setEnrolling(s.studentId)}>
                        Enroll
                      </button>
                    </td>
                  </tr>
                ))}
                {students.length === 0 && (
                  <tr><td colSpan="7" className="text-center text-muted py-4">No students found</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <nav>
              <ul className="pagination pagination-sm justify-content-end">
                <li className={`page-item ${page === 0 ? 'disabled' : ''}`}>
                  <button className="page-link" onClick={() => setPage(p => p - 1)}>‹</button>
                </li>
                <li className="page-item disabled">
                  <span className="page-link">{page + 1} / {totalPages}</span>
                </li>
                <li className={`page-item ${page >= totalPages - 1 ? 'disabled' : ''}`}>
                  <button className="page-link" onClick={() => setPage(p => p + 1)}>›</button>
                </li>
              </ul>
            </nav>
          )}
        </>
      )}
    </div>
  );
};

export default EnrollmentManager;
