import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const NAV = {
  ADMIN: [
    { to: '/admin',              icon: '📊', label: 'Dashboard' },
    { to: '/admin/students',     icon: '🎓', label: 'Students' },
    { to: '/admin/classes',      icon: '🏫', label: 'Classes' },
    { to: '/admin/teachers',     icon: '👩‍🏫', label: 'Teachers' },
    { to: '/admin/users',        icon: '👥', label: 'Users' },
    { to: '/admin/reports',      icon: '📈', label: 'Reports & KPIs' },
    { to: '/admin/tasks',        icon: '✅', label: 'Tasks' },
  ],
  TEACHER: [
    { to: '/teacher',            icon: '📊', label: 'Dashboard' },
    { to: '/teacher/attendance', icon: '📋', label: 'Attendance' },
    { to: '/teacher/grades',     icon: '📝', label: 'Grades' },
    { to: '/teacher/classes',    icon: '🏫', label: 'My Classes' },
    { to: '/teacher/tasks',      icon: '✅', label: 'Tasks' },
  ],
  STUDENT: [
    { to: '/student',            icon: '📊', label: 'Dashboard' },
    { to: '/student/grades',     icon: '📝', label: 'My Grades' },
    { to: '/student/attendance', icon: '📋', label: 'Attendance' },
    { to: '/student/timetable',  icon: '📅', label: 'Timetable' },
  ],
  PARENT: [
    { to: '/parent',             icon: '📊', label: 'Dashboard' },
    { to: '/parent/performance', icon: '📈', label: 'Performance' },
    { to: '/parent/attendance',  icon: '📋', label: 'Attendance' },
    { to: '/parent/messages',    icon: '💬', label: 'Messages' },
  ],
  EXAM_COORDINATOR: [
    { to: '/examcoord',          icon: '📊', label: 'Dashboard' },
    { to: '/examcoord/exams',    icon: '📝', label: 'Exams' },
    { to: '/examcoord/grades',   icon: '🎯', label: 'Grade Moderation' },
  ],
  AUDITOR: [
    { to: '/compliance',         icon: '📊', label: 'Dashboard' },
    { to: '/compliance/audit',   icon: '🔍', label: 'Audit Logs' },
    { to: '/compliance/reports', icon: '📁', label: 'Reports' },
  ],
};

const Sidebar = ({ open, onClose }) => {
  const { user } = useAuth();
  const links    = NAV[user?.role] || [];

  return (
    <>
      {/* Backdrop (mobile) */}
      {open && (
        <div className="d-lg-none position-fixed top-0 start-0 w-100 h-100"
             style={{ background: 'rgba(0,0,0,.5)', zIndex: 1040 }}
             onClick={onClose} />
      )}

      <aside className={`d-flex flex-column flex-shrink-0 p-3 text-white position-fixed top-0 h-100
                         ${open ? 'd-flex' : 'd-none d-lg-flex'}`}
             style={{ width: 240, background: '#132d46', zIndex: 1045, overflowY: 'auto',
                      top: 56, paddingTop: '1rem' }}>

        <ul className="nav nav-pills flex-column gap-1 mb-auto">
          {links.map(({ to, icon, label }) => (
            <li key={to} className="nav-item">
              <NavLink
                to={to}
                end
                className={({ isActive }) =>
                  `nav-link text-white d-flex align-items-center gap-2 rounded ${isActive ? 'active' : ''}`}
                style={({ isActive }) => isActive
                  ? { background: '#2d6a9f' }
                  : { background: 'transparent' }}
                onClick={onClose}>
                <span>{icon}</span>
                <span className="small">{label}</span>
              </NavLink>
            </li>
          ))}
        </ul>

        <div className="mt-3 pt-3 border-top border-secondary">
          <NavLink to="/notifications"
                   className="nav-link text-white d-flex align-items-center gap-2"
                   onClick={onClose}>
            <span>🔔</span><span className="small">Notifications</span>
          </NavLink>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
