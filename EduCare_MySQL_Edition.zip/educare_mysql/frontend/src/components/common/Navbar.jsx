import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const ROLE_LABELS = {
  ADMIN:            'Administrator',
  TEACHER:          'Teacher',
  STUDENT:          'Student',
  PARENT:           'Parent',
  EXAM_COORDINATOR: 'Exam Coordinator',
  AUDITOR:          'Auditor',
};

const Navbar = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark sticky-top shadow-sm"
         style={{ background: '#1a3c5e', zIndex: 1030 }}>
      <div className="container-fluid px-3">
        {/* Sidebar toggle for mobile */}
        <button className="btn btn-link text-white me-2 d-lg-none p-0"
                onClick={toggleSidebar} aria-label="Toggle sidebar">
          <span className="navbar-toggler-icon" />
        </button>

        <Link className="navbar-brand fw-bold fs-5 me-auto" to="/">
          <span className="me-2">🎓</span>EduCare
        </Link>

        <div className="d-flex align-items-center gap-3">
          {/* Notification bell */}
          <Link to="/notifications" className="btn btn-link text-white p-0 position-relative">
            <svg width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
              <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7a5.002 5.002 0 0 0-3.005-4.9z"/>
            </svg>
          </Link>

          {/* User dropdown */}
          <div className="dropdown">
            <button className="btn btn-link text-white p-0 d-flex align-items-center gap-2"
                    data-bs-toggle="dropdown" aria-expanded="false">
              <div className="rounded-circle d-flex align-items-center justify-content-center"
                   style={{ width: 32, height: 32, background: '#2d6a9f', fontSize: 13, fontWeight: 700 }}>
                {user?.name?.charAt(0).toUpperCase()}
              </div>
              <span className="d-none d-md-inline small fw-semibold">{user?.name}</span>
            </button>
            <ul className="dropdown-menu dropdown-menu-end shadow">
              <li>
                <span className="dropdown-item-text small text-muted">
                  {ROLE_LABELS[user?.role] || user?.role}
                </span>
              </li>
              <li><hr className="dropdown-divider my-1" /></li>
              <li>
                <button className="dropdown-item text-danger small" onClick={handleLogout}>
                  Sign Out
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
