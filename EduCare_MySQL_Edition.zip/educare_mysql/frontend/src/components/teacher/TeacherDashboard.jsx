import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { classesAPI, tasksAPI } from '../../services/api';

const TeacherDashboard = () => {
  const { user }             = useAuth();
  const [classes,  setClasses]  = useState([]);
  const [tasks,    setTasks]    = useState([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    Promise.all([
      classesAPI.list(),
      tasksAPI.list(0).catch(() => ({ data: { content: [] } })),
    ]).then(([cr, tr]) => {
      setClasses(cr.data.content || []);
      setTasks(tr.data.content   || []);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="d-flex justify-content-center py-5">
      <div className="spinner-border text-primary" />
    </div>
  );

  return (
    <div>
      <h4 className="fw-bold mb-1">Welcome, {user?.name}</h4>
      <p className="text-muted small mb-4">Teacher Dashboard</p>

      <div className="row g-3 mb-4">
        <div className="col-sm-4">
          <div className="card border-0 shadow-sm text-center p-3">
            <div className="fs-1">🏫</div>
            <div className="fw-bold fs-4">{classes.length}</div>
            <div className="text-muted small">My Classes</div>
          </div>
        </div>
        <div className="col-sm-4">
          <div className="card border-0 shadow-sm text-center p-3">
            <div className="fs-1">✅</div>
            <div className="fw-bold fs-4">{tasks.filter(t => t.status === 'OPEN').length}</div>
            <div className="text-muted small">Open Tasks</div>
          </div>
        </div>
        <div className="col-sm-4">
          <div className="card border-0 shadow-sm text-center p-3">
            <div className="fs-1">⚠️</div>
            <div className="fw-bold fs-4">{tasks.filter(t => t.priority === 'URGENT').length}</div>
            <div className="text-muted small">Urgent Tasks</div>
          </div>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-md-7">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent d-flex justify-content-between align-items-center">
              <span className="fw-semibold">My Classes</span>
              <Link to="/teacher/attendance" className="btn btn-sm btn-primary">Mark Attendance</Link>
            </div>
            <ul className="list-group list-group-flush">
              {classes.slice(0, 6).map(c => (
                <li key={c.classId} className="list-group-item d-flex justify-content-between align-items-center">
                  <div>
                    <div className="fw-semibold small">{c.name}</div>
                    <div className="text-muted" style={{ fontSize: 12 }}>Grade {c.gradeLevel} · Capacity {c.capacity}</div>
                  </div>
                  <span className={`badge ${c.status === 'ACTIVE' ? 'bg-success' : 'bg-secondary'}`}>{c.status}</span>
                </li>
              ))}
              {classes.length === 0 && (
                <li className="list-group-item text-muted text-center py-3">No classes assigned</li>
              )}
            </ul>
          </div>
        </div>

        <div className="col-md-5">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent fw-semibold">Pending Tasks</div>
            <ul className="list-group list-group-flush">
              {tasks.filter(t => t.status === 'OPEN').slice(0, 5).map(t => (
                <li key={t.taskId} className="list-group-item">
                  <div className="small fw-semibold">{t.title}</div>
                  <div className="d-flex gap-2 mt-1">
                    <span className={`badge ${t.priority === 'URGENT' ? 'bg-danger' : t.priority === 'HIGH' ? 'bg-warning text-dark' : 'bg-secondary'}`}>
                      {t.priority}
                    </span>
                    {t.dueDate && <span className="text-muted" style={{ fontSize: 11 }}>Due {t.dueDate}</span>}
                  </div>
                </li>
              ))}
              {tasks.filter(t => t.status === 'OPEN').length === 0 && (
                <li className="list-group-item text-muted text-center py-3">No pending tasks</li>
              )}
            </ul>
          </div>

          <div className="card border-0 shadow-sm mt-3">
            <div className="card-header bg-transparent fw-semibold">Quick Actions</div>
            <div className="card-body d-flex flex-wrap gap-2">
              <Link to="/teacher/attendance" className="btn btn-sm btn-outline-primary">📋 Attendance</Link>
              <Link to="/teacher/grades"     className="btn btn-sm btn-outline-success">📝 Submit Grades</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
