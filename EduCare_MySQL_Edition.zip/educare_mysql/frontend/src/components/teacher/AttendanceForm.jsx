import React, { useEffect, useState } from 'react';
import { classesAPI, studentsAPI, attendanceAPI } from '../../services/api';

const AttendanceForm = () => {
  const [classes,   setClasses]   = useState([]);
  const [classId,   setClassId]   = useState('');
  const [date,      setDate]      = useState(new Date().toISOString().split('T')[0]);
  const [students,  setStudents]  = useState([]);
  const [statuses,  setStatuses]  = useState({});
  const [loading,   setLoading]   = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error,     setError]     = useState('');

  useEffect(() => {
    classesAPI.list().then(r => setClasses(r.data.content || []));
  }, []);

  const loadStudents = async () => {
    if (!classId) return;
    setLoading(true);
    try {
      // Fetch enrollments for the class (simplified: list all students)
      const r = await studentsAPI.list(0, 100);
      const list = r.data.content || [];
      setStudents(list);
      const init = {};
      list.forEach(s => { init[s.studentId] = 'PRESENT'; });
      setStatuses(init);
    } catch { setError('Failed to load students'); }
    finally { setLoading(false); }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const promises = students.map(s =>
        attendanceAPI.mark({
          studentId: s.studentId,
          classId:   parseInt(classId),
          date,
          status:    statuses[s.studentId],
        }).catch(err => ({ error: err.response?.data?.message }))
      );
      await Promise.all(promises);
      setSubmitted(true);
    } catch { setError('Some attendance records failed to save'); }
    finally { setLoading(false); }
  };

  const toggleStatus = (id, val) =>
    setStatuses(prev => ({ ...prev, [id]: val }));

  const STATUS_OPTS = ['PRESENT','ABSENT','LATE','EXCUSED'];
  const STATUS_COLORS = { PRESENT: 'success', ABSENT: 'danger', LATE: 'warning', EXCUSED: 'info' };

  return (
    <div>
      <h5 className="fw-bold mb-3">Mark Attendance</h5>

      {submitted ? (
        <div className="alert alert-success">
          ✅ Attendance saved for {date}!
          <button className="btn btn-sm btn-success ms-3" onClick={() => setSubmitted(false)}>
            Mark Another
          </button>
        </div>
      ) : (
        <>
          <div className="card border-0 shadow-sm mb-3">
            <div className="card-body">
              <div className="row g-2 align-items-end">
                <div className="col-md-4">
                  <label className="form-label small fw-semibold">Class</label>
                  <select className="form-select form-select-sm" value={classId}
                          onChange={e => { setClassId(e.target.value); setStudents([]); }}>
                    <option value="">Select class…</option>
                    {classes.map(c => <option key={c.classId} value={c.classId}>{c.name}</option>)}
                  </select>
                </div>
                <div className="col-md-3">
                  <label className="form-label small fw-semibold">Date</label>
                  <input type="date" className="form-control form-control-sm"
                         value={date} onChange={e => setDate(e.target.value)} />
                </div>
                <div className="col-md-2">
                  <button className="btn btn-primary btn-sm w-100"
                          onClick={loadStudents} disabled={!classId || loading}>
                    {loading ? <span className="spinner-border spinner-border-sm" /> : 'Load Students'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {error && <div className="alert alert-danger py-2"><small>{error}</small></div>}

          {students.length > 0 && (
            <form onSubmit={handleSubmit}>
              <div className="card border-0 shadow-sm">
                <div className="card-header bg-transparent d-flex justify-content-between">
                  <span className="fw-semibold">Students ({students.length})</span>
                  <div className="d-flex gap-1">
                    <button type="button" className="btn btn-outline-success btn-sm"
                            onClick={() => { const s = {}; students.forEach(st => s[st.studentId]='PRESENT'); setStatuses(s); }}>
                      All Present
                    </button>
                  </div>
                </div>
                <div className="table-responsive">
                  <table className="table table-sm align-middle mb-0">
                    <thead className="table-light">
                      <tr><th>#</th><th>Student</th>{STATUS_OPTS.map(s => <th key={s} className="text-center">{s}</th>)}</tr>
                    </thead>
                    <tbody>
                      {students.map((s, i) => (
                        <tr key={s.studentId}>
                          <td className="text-muted small">{i + 1}</td>
                          <td className="fw-semibold small">{s.name}</td>
                          {STATUS_OPTS.map(opt => (
                            <td key={opt} className="text-center">
                              <input type="radio" className="form-check-input"
                                     name={`status-${s.studentId}`}
                                     checked={statuses[s.studentId] === opt}
                                     onChange={() => toggleStatus(s.studentId, opt)} />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="card-footer text-end">
                  <button type="submit" className="btn btn-success btn-sm" disabled={loading}>
                    {loading ? <span className="spinner-border spinner-border-sm me-1" /> : null}
                    Submit Attendance
                  </button>
                </div>
              </div>
            </form>
          )}
        </>
      )}
    </div>
  );
};

export default AttendanceForm;
