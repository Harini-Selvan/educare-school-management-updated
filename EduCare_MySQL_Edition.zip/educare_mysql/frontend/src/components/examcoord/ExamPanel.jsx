import React, { useEffect, useState } from 'react';
import { examsAPI, gradesAPI, studentsAPI } from '../../services/api';

const ExamPanel = () => {
  const [exams,    setExams]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [gradeModal, setGradeModal] = useState(null); // examId
  const [students, setStudents] = useState([]);
  const [grades,   setGrades]   = useState({});
  const [form, setForm] = useState({ classId:'', subject:'', scheduledAt:'' });
  const [msg,  setMsg]  = useState('');

  const load = () => {
    setLoading(true);
    examsAPI.list()
      .then(r => setExams(r.data.content || []))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleSchedule = async e => {
    e.preventDefault();
    try {
      await examsAPI.schedule({ ...form, classId: parseInt(form.classId), scheduledAt: new Date(form.scheduledAt).toISOString() });
      setMsg('Exam scheduled!'); setShowForm(false); load();
    } catch (err) { setMsg(err.response?.data?.message || 'Error'); }
  };

  const openGradeModal = async examId => {
    setGradeModal(examId);
    const r = await studentsAPI.list(0, 100);
    setStudents(r.data.content || []);
    const init = {};
    (r.data.content || []).forEach(s => { init[s.studentId] = ''; });
    setGrades(init);
  };

  const submitGrades = async () => {
    const entries = Object.entries(grades).filter(([, v]) => v !== '');
    await Promise.all(entries.map(([sid, val]) =>
      gradesAPI.submit({ studentId: parseInt(sid), examId: gradeModal, gradeValue: parseFloat(val) })
        .catch(() => {})
    ));
    setMsg(`Grades submitted for exam #${gradeModal}`);
    setGradeModal(null);
  };

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h5 className="fw-bold mb-0">Exam Panel</h5>
        <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}>+ Schedule Exam</button>
      </div>

      {msg && <div className="alert alert-info py-2"><small>{msg}</small>
        <button className="btn-close btn-sm ms-2" onClick={() => setMsg('')} /></div>}

      {showForm && (
        <div className="card border-primary mb-3">
          <div className="card-header">New Exam</div>
          <div className="card-body">
            <form onSubmit={handleSchedule}>
              <div className="row g-2">
                <div className="col-md-3">
                  <input className="form-control form-control-sm" placeholder="Class ID *"
                    value={form.classId} onChange={e => setForm(p => ({...p, classId: e.target.value}))} required />
                </div>
                <div className="col-md-4">
                  <input className="form-control form-control-sm" placeholder="Subject *"
                    value={form.subject} onChange={e => setForm(p => ({...p, subject: e.target.value}))} required />
                </div>
                <div className="col-md-3">
                  <input type="datetime-local" className="form-control form-control-sm"
                    value={form.scheduledAt} onChange={e => setForm(p => ({...p, scheduledAt: e.target.value}))} required />
                </div>
                <div className="col-md-2 d-flex gap-1">
                  <button className="btn btn-success btn-sm" type="submit">Save</button>
                  <button className="btn btn-outline-secondary btn-sm" type="button" onClick={() => setShowForm(false)}>✕</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Grade Entry Modal */}
      {gradeModal && (
        <div className="modal show d-block" style={{ background: 'rgba(0,0,0,.4)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h6 className="modal-title">Enter Grades — Exam #{gradeModal}</h6>
                <button className="btn-close" onClick={() => setGradeModal(null)} />
              </div>
              <div className="modal-body" style={{ maxHeight: 400, overflowY: 'auto' }}>
                <table className="table table-sm">
                  <thead><tr><th>Student</th><th style={{ width: 140 }}>Grade (0–100)</th></tr></thead>
                  <tbody>
                    {students.map(s => (
                      <tr key={s.studentId}>
                        <td>{s.name}</td>
                        <td>
                          <input type="number" min="0" max="100" step="0.1"
                            className="form-control form-control-sm"
                            value={grades[s.studentId] || ''}
                            onChange={e => setGrades(p => ({...p, [s.studentId]: e.target.value}))} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="modal-footer">
                <button className="btn btn-success btn-sm" onClick={submitGrades}>Submit All Grades</button>
                <button className="btn btn-outline-secondary btn-sm" onClick={() => setGradeModal(null)}>Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {loading ? <div className="text-center py-5"><div className="spinner-border text-primary" /></div> : (
        <div className="table-responsive">
          <table className="table table-hover table-sm align-middle">
            <thead className="table-light">
              <tr><th>#</th><th>Subject</th><th>Class</th><th>Scheduled</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {exams.map(ex => (
                <tr key={ex.examId}>
                  <td className="text-muted small">{ex.examId}</td>
                  <td className="fw-semibold small">{ex.subject}</td>
                  <td className="small">#{ex.classId}</td>
                  <td className="small">{ex.scheduledAt ? new Date(ex.scheduledAt).toLocaleString() : '—'}</td>
                  <td>
                    <span className={`badge ${ex.status==='SCHEDULED'?'bg-primary':ex.status==='COMPLETED'?'bg-success':'bg-secondary'}`}>
                      {ex.status}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-outline-success btn-sm py-0"
                            onClick={() => openGradeModal(ex.examId)}>
                      Enter Grades
                    </button>
                  </td>
                </tr>
              ))}
              {exams.length === 0 && <tr><td colSpan="6" className="text-center text-muted py-4">No exams scheduled</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ExamPanel;
