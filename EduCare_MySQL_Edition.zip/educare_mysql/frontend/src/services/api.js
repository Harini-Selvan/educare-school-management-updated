import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:9090',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor — attach JWT
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor — handle 401 globally
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ── Auth ──────────────────────────────────────────────
export const authAPI = {
  login:    (data)     => api.post('/api/v1/auth/login', data),
  register: (data)     => api.post('/api/v1/auth/register', data),
};

// ── Users ─────────────────────────────────────────────
export const usersAPI = {
  list:         (page = 0, size = 20) => api.get(`/api/v1/users?page=${page}&size=${size}`),
  getById:      (id)                  => api.get(`/api/v1/users/${id}`),
  updateStatus: (id, status)          => api.put(`/api/v1/users/${id}/status`, { status }),
  auditLogs:    (page = 0)            => api.get(`/api/v1/users/audit-logs?page=${page}`),
};

// ── Students ──────────────────────────────────────────
export const studentsAPI = {
  list:        (page = 0, size = 20) => api.get(`/api/v1/students?page=${page}&size=${size}`),
  getById:     (id)                  => api.get(`/api/v1/students/${id}`),
  create:      (data)                => api.post('/api/v1/students', data),
  update:      (id, data)            => api.put(`/api/v1/students/${id}`, data),
  enrollments: (id)                  => api.get(`/api/v1/students/${id}/enrollment`),
  enroll:      (id, data)            => api.post(`/api/v1/students/${id}/enroll`, data),
  import:      (file)                => {
    const fd = new FormData(); fd.append('file', file);
    return api.post('/api/v1/students/import', fd, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
};

// ── Classes & Teachers ────────────────────────────────
export const classesAPI = {
  list:   (page = 0) => api.get(`/api/v1/classes?page=${page}`),
  create: (data)     => api.post('/api/v1/classes', data),
  getById:(id)       => api.get(`/api/v1/classes/${id}`),
};

export const teachersAPI = {
  list:            (page = 0) => api.get(`/api/v1/teachers?page=${page}`),
  create:          (data)     => api.post('/api/v1/teachers', data),
  assign:          (id, data) => api.post(`/api/v1/teachers/${id}/assign`, data),
  getAssignments:  (id)       => api.get(`/api/v1/teachers/${id}/assignments`),
  removeAssignment:(cid, tid) => api.delete(`/api/v1/classes/${cid}/teachers/${tid}`),
};

// ── Attendance ────────────────────────────────────────
export const attendanceAPI = {
  mark:          (data)                    => api.post('/api/v1/attendance', data),
  byStudent:     (id, from, to)            => api.get(`/api/v1/attendance/student/${id}?from=${from}&to=${to}`),
  byClass:       (id, date)               => api.get(`/api/v1/attendance/class/${id}?date=${date}`),
  summary:       (id)                     => api.get(`/api/v1/attendance/student/${id}/summary`),
};

// ── Exams & Grades ────────────────────────────────────
export const examsAPI = {
  list:         (page = 0) => api.get(`/api/v1/exams?page=${page}`),
  getById:      (id)       => api.get(`/api/v1/exams/${id}`),
  schedule:     (data)     => api.post('/api/v1/exams', data),
  updateStatus: (id, s)    => api.put(`/api/v1/exams/${id}/status`, { status: s }),
};

export const gradesAPI = {
  submit:        (data)       => api.post('/api/v1/grades', data),
  modify:        (id, data)   => api.put(`/api/v1/grades/${id}`, data),
  byStudent:     (id)         => api.get(`/api/v1/grades/student/${id}`),
};

// ── Notifications & Messages ──────────────────────────
export const notificationsAPI = {
  list:    (userId, page = 0) => api.get(`/api/v1/notifications?userId=${userId}&page=${page}`),
  markRead:(id)               => api.put(`/api/v1/notifications/${id}/read`),
  send:    (data)             => api.post('/api/v1/messages', data),
};

// ── Reports & KPIs ────────────────────────────────────
export const reportsAPI = {
  list:            (page = 0) => api.get(`/api/v1/reports?page=${page}`),
  getById:         (id)       => api.get(`/api/v1/reports/${id}`),
  generate:        (data)     => api.post('/api/v1/reports/generate', data),
  kpis:            ()         => api.get('/api/v1/kpis'),
  auditPackage:    (data)     => api.post('/api/v1/audit-packages', data),
};

// ── Tasks ─────────────────────────────────────────────
export const tasksAPI = {
  list:         (userId, page = 0) => api.get(`/api/v1/tasks?userId=${userId}&page=${page}`),
  getById:      (id)               => api.get(`/api/v1/tasks/${id}`),
  create:       (data)             => api.post('/api/v1/tasks', data),
  updateStatus: (id, status)       => api.put(`/api/v1/tasks/${id}/status`, { status }),
};

export default api;
