import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const { login } = useAuth();
  const navigate   = useNavigate();
  const [form, setForm]       = useState({ email: '', password: '' });
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = e =>
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      const dest = {
        ADMIN:            '/admin',
        TEACHER:          '/teacher',
        STUDENT:          '/student',
        PARENT:           '/parent',
        EXAM_COORDINATOR: '/examcoord',
        AUDITOR:          '/compliance',
      }[user.role] || '/';
      navigate(dest, { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid credentials. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center"
         style={{ background: 'linear-gradient(135deg, #1a3c5e 0%, #2d6a9f 100%)' }}>
      <div className="card shadow-lg" style={{ width: '100%', maxWidth: 420 }}>
        <div className="card-body p-5">
          {/* Logo */}
          <div className="text-center mb-4">
            <div className="d-inline-flex align-items-center justify-content-center rounded-circle mb-3"
                 style={{ width: 64, height: 64, background: '#1a3c5e' }}>
              <span className="text-white fw-bold fs-4">EC</span>
            </div>
            <h3 className="fw-bold text-dark mb-1">EduCare</h3>
            <p className="text-muted small">School Administration System</p>
          </div>

          {error && (
            <div className="alert alert-danger alert-dismissible py-2" role="alert">
              <small>{error}</small>
              <button type="button" className="btn-close btn-sm" onClick={() => setError('')} />
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label fw-semibold small">Email Address</label>
              <input
                type="email"
                name="email"
                className="form-control"
                placeholder="you@school.edu"
                value={form.email}
                onChange={handleChange}
                required
                autoFocus
              />
            </div>
            <div className="mb-4">
              <label className="form-label fw-semibold small">Password</label>
              <input
                type="password"
                name="password"
                className="form-control"
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                required
              />
            </div>
            <button
              type="submit"
              className="btn btn-primary w-100 fw-semibold"
              disabled={loading}
              style={{ background: '#1a3c5e', borderColor: '#1a3c5e' }}>
              {loading ? (
                <><span className="spinner-border spinner-border-sm me-2" />Signing in…</>
              ) : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-muted small mt-4 mb-0">
            © {new Date().getFullYear()} EduCare v1.0
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
