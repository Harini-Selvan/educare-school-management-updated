# EduCare — MySQL Edition (No Docker)

> Spring Boot 3 microservices with MySQL, React 18, Swagger UI.
> PostgreSQL removed. Docker removed. Port changed to 9090.

---

## What Changed from Original
- ✅ PostgreSQL → MySQL 8+
- ✅ application.yml → application.properties (all services)
- ✅ API Gateway port: 8080 → 9090
- ✅ Swagger UI added to all services
- ✅ Docker & docker-compose removed
- ✅ All SQL migrations converted to MySQL syntax

---

## Prerequisites

| Tool       | Version  | Download |
|------------|----------|----------|
| Java JDK   | 17 LTS   | https://adoptium.net/ |
| Maven      | 3.9+     | https://maven.apache.org/ |
| Node.js    | 18+      | https://nodejs.org/ |
| MySQL      | 8+       | Already installed ✅ |

---

## STEP 1 — Set Up MySQL Databases

Open MySQL Workbench or MySQL terminal and run:

```sql
CREATE DATABASE IF NOT EXISTS educare_identity;
CREATE DATABASE IF NOT EXISTS educare_students;
CREATE DATABASE IF NOT EXISTS educare_classes;
CREATE DATABASE IF NOT EXISTS educare_attendance;
CREATE DATABASE IF NOT EXISTS educare_exams;
CREATE DATABASE IF NOT EXISTS educare_notifications;
CREATE DATABASE IF NOT EXISTS educare_reporting;
CREATE DATABASE IF NOT EXISTS educare_tasks;
```

Or just run the provided script:
```bash
mysql -u root -p < init-db.sql
```

---

## STEP 2 — Set Your MySQL Password

Open each service's `src/main/resources/application.properties` and replace:
```
spring.datasource.password=your_mysql_password
```
with your actual MySQL root password.

**Services to update:** identity-service, student-service, class-teacher-service,
attendance-service, exam-grade-service, notification-service, reporting-service, task-alert-service

---

## STEP 3 — Set Your JWT Secret

In each service's `application.properties`, change:
```
jwt.secret=change_this_256bit_secret_in_production_env
```
Use the same secret string in ALL services (minimum 32 characters).

---

## STEP 4 — Start Services (in this exact order)

Open a separate terminal for each:

```bash
# Terminal 1
cd config-server && mvn spring-boot:run

# Terminal 2 (wait for config-server to start)
cd eureka-server && mvn spring-boot:run

# Terminal 3
cd api-gateway && mvn spring-boot:run

# Terminal 4
cd identity-service && mvn spring-boot:run

# Terminal 5
cd student-service && mvn spring-boot:run

# Terminal 6
cd class-teacher-service && mvn spring-boot:run

# Terminal 7
cd attendance-service && mvn spring-boot:run

# Terminal 8
cd exam-grade-service && mvn spring-boot:run

# Terminal 9
cd notification-service && mvn spring-boot:run

# Terminal 10
cd reporting-service && mvn spring-boot:run

# Terminal 11
cd task-alert-service && mvn spring-boot:run
```

---

## STEP 5 — Start the Frontend

```bash
cd frontend
npm install
npm start
```

Frontend opens at: http://localhost:3000

---

## Service URLs

| Service               | Port | Swagger UI |
|-----------------------|------|------------|
| API Gateway           | 9090 | — |
| Identity Service      | 8081 | http://localhost:8081/swagger-ui.html |
| Student Service       | 8082 | http://localhost:8082/swagger-ui.html |
| Class/Teacher Service | 8083 | http://localhost:8083/swagger-ui.html |
| Attendance Service    | 8084 | http://localhost:8084/swagger-ui.html |
| Exam/Grade Service    | 8085 | http://localhost:8085/swagger-ui.html |
| Notification Service  | 8086 | http://localhost:8086/swagger-ui.html |
| Reporting Service     | 8087 | http://localhost:8087/swagger-ui.html |
| Task-Alert Service    | 8088 | http://localhost:8088/swagger-ui.html |
| Eureka Dashboard      | 8761 | http://localhost:8761 |
| Frontend              | 3000 | http://localhost:3000 |

---

## Default Login

Email: `admin@school.edu`  
Password: `Admin@1234`

> Change the password immediately after first login!

