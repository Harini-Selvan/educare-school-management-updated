package com.educare.task.repository;

import com.educare.task.entity.Task;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    Page<Task> findByAssignedToOrderByDueDateAsc(Long assignedTo, Pageable pageable);
    Page<Task> findByCreatedByOrderByCreatedAtDesc(Long createdBy, Pageable pageable);
    List<Task> findByStatusAndDueDateBefore(String status, LocalDate date);
}
