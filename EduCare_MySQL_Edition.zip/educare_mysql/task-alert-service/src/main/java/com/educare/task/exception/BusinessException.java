package com.educare.task.exception;
public class BusinessException extends RuntimeException {
    public BusinessException(String msg) { super(msg); }
}
