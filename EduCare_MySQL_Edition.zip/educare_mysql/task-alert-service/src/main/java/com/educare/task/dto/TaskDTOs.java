package com.educare.task.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.Instant;
import java.time.LocalDate;

public class TaskDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class TaskRequest {
        @NotBlank private String title;
        private String description;
        @NotNull  private Long assignedTo;
        private LocalDate dueDate;
        private String priority;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class TaskDTO {
        private Long taskId;
        private String title;
        private String description;
        private Long assignedTo;
        private Long createdBy;
        private LocalDate dueDate;
        private String priority;
        private String status;
        private Instant createdAt;
        private Instant updatedAt;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
