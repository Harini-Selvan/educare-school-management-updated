package com.educare.task.service;

import com.educare.task.dto.TaskDTOs.*;
import com.educare.task.entity.Task;
import com.educare.task.exception.ResourceNotFoundException;
import com.educare.task.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class TaskService {

    private final TaskRepository taskRepo;

    public Page<TaskDTO> findForUser(Long userId, Pageable pageable) {
        return taskRepo.findByAssignedToOrderByDueDateAsc(userId, pageable).map(this::toDTO);
    }

    public TaskDTO findById(Long id) {
        return taskRepo.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + id));
    }

    @Transactional
    public TaskDTO create(TaskRequest req, Long createdBy) {
        Task task = Task.builder()
                .title(req.getTitle())
                .description(req.getDescription())
                .assignedTo(req.getAssignedTo())
                .createdBy(createdBy)
                .dueDate(req.getDueDate())
                .priority(req.getPriority() != null ? req.getPriority() : "NORMAL")
                .status("OPEN")
                .build();
        Task saved = taskRepo.save(task);
        log.info("Task created: {} assigned to user {}", saved.getTaskId(), saved.getAssignedTo());
        return toDTO(saved);
    }

    @Transactional
    public TaskDTO updateStatus(Long taskId, String status) {
        Task task = taskRepo.findById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + taskId));
        task.setStatus(status);
        return toDTO(taskRepo.save(task));
    }

    // Runs every day at 08:00 to flag overdue tasks
    @Scheduled(cron = "0 0 8 * * *")
    public void flagOverdueTasks() {
        List<Task> overdue = taskRepo.findByStatusAndDueDateBefore("OPEN", LocalDate.now());
        overdue.forEach(t -> {
            t.setPriority("URGENT");
            taskRepo.save(t);
            log.warn("Task {} is overdue (due: {})", t.getTaskId(), t.getDueDate());
        });
        if (!overdue.isEmpty())
            log.info("Flagged {} overdue tasks as URGENT", overdue.size());
    }

    private TaskDTO toDTO(Task t) {
        return TaskDTO.builder()
                .taskId(t.getTaskId())
                .title(t.getTitle())
                .description(t.getDescription())
                .assignedTo(t.getAssignedTo())
                .createdBy(t.getCreatedBy())
                .dueDate(t.getDueDate())
                .priority(t.getPriority())
                .status(t.getStatus())
                .createdAt(t.getCreatedAt())
                .updatedAt(t.getUpdatedAt())
                .build();
    }
}
