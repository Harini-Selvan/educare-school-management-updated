-- V1__init_task_schema.sql

CREATE TABLE IF NOT EXISTS tasks (
    task_id     BIGINT AUTO_INCREMENT    PRIMARY KEY,
    title       VARCHAR(300) NOT NULL,
    description TEXT,
    assigned_to BIGINT       NOT NULL,
    created_by  BIGINT       NOT NULL,
    due_date    DATE,
    priority    VARCHAR(20)  NOT NULL DEFAULT 'NORMAL',
    status      VARCHAR(20)  NOT NULL DEFAULT 'OPEN',
    created_at  DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tasks_assigned_to ON tasks(assigned_to, due_date);
CREATE INDEX idx_tasks_created_by  ON tasks(created_by,  created_at DESC);
CREATE INDEX idx_tasks_status      ON tasks(status,      due_date);
