package com.educare.reporting.exception;
public class BusinessException extends RuntimeException {
    public BusinessException(String msg) { super(msg); }
}
