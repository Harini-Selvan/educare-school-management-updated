package com.educare.reporting.service;

import com.educare.reporting.dto.ReportingDTOs.*;
import com.educare.reporting.entity.Report;
import com.educare.reporting.exception.ResourceNotFoundException;
import com.educare.reporting.repository.ReportRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportingService {

    private final ReportRepository reportRepo;
    private final ObjectMapper objectMapper;

    public Page<ReportDTO> findAll(Pageable pageable) {
        return reportRepo.findAll(pageable).map(this::toDTO);
    }

    public ReportDTO findById(Long id) {
        return reportRepo.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found: " + id));
    }

    @Transactional
    public ReportDTO generate(ReportRequest req, Long requestedBy) {
        String paramsJson = null;
        try {
            if (req.getParameters() != null)
                paramsJson = objectMapper.writeValueAsString(req.getParameters());
        } catch (JsonProcessingException e) {
            log.warn("Could not serialize parameters: {}", e.getMessage());
        }

        Report report = Report.builder()
                .type(req.getType())
                .title(req.getTitle())
                .parameters(paramsJson)
                .requestedBy(requestedBy)
                .status("PENDING")
                .build();

        Report saved = reportRepo.save(report);
        log.info("Report generation requested: id={} type={}", saved.getReportId(), saved.getType());

        // async generation
        processReportAsync(saved.getReportId());

        return toDTO(saved);
    }

    @Async
    public void processReportAsync(Long reportId) {
        try {
            Thread.sleep(2000); // simulate processing
            reportRepo.findById(reportId).ifPresent(r -> {
                r.setStatus("COMPLETED");
                r.setResultUri("/reports/" + reportId + "/output.csv");
                r.setCompletedAt(Instant.now());
                reportRepo.save(r);
                log.info("Report {} completed", reportId);
            });
        } catch (Exception e) {
            log.error("Report {} failed: {}", reportId, e.getMessage());
            reportRepo.findById(reportId).ifPresent(r -> {
                r.setStatus("FAILED");
                reportRepo.save(r);
            });
        }
    }

    public KpiDTO getKpis() {
        // In production, these would query across services via Feign/REST
        return KpiDTO.builder()
                .totalStudents(reportRepo.count())
                .activeStudents(reportRepo.count())
                .totalTeachers(0L)
                .totalClasses(0L)
                .averageAttendanceRate(92.5)
                .averageGrade(74.3)
                .pendingTasks(3L)
                .generatedAt(Instant.now())
                .build();
    }

    private ReportDTO toDTO(Report r) {
        return ReportDTO.builder()
                .reportId(r.getReportId())
                .type(r.getType())
                .title(r.getTitle())
                .status(r.getStatus())
                .resultUri(r.getResultUri())
                .requestedBy(r.getRequestedBy())
                .requestedAt(r.getRequestedAt())
                .completedAt(r.getCompletedAt())
                .build();
    }
}
