package com.educare.reporting.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.Instant;
import java.util.Map;

public class ReportingDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ReportRequest {
        @NotBlank private String type;
        @NotBlank private String title;
        private Map<String, String> parameters;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ReportDTO {
        private Long reportId;
        private String type;
        private String title;
        private String status;
        private String resultUri;
        private Long requestedBy;
        private Instant requestedAt;
        private Instant completedAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class KpiDTO {
        private long totalStudents;
        private long activeStudents;
        private long totalTeachers;
        private long totalClasses;
        private double averageAttendanceRate;
        private double averageGrade;
        private long pendingTasks;
        private Instant generatedAt;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
