package com.educare.reporting.controller;

import com.educare.reporting.dto.ReportingDTOs.*;
import com.educare.reporting.service.ReportingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class ReportingController {

    private final ReportingService reportingService;

    @GetMapping("/api/v1/reports")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    public ResponseEntity<Page<ReportDTO>> listReports(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(reportingService.findAll(PageRequest.of(page, size)));
    }

    @GetMapping("/api/v1/reports/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    public ResponseEntity<ReportDTO> getReport(@PathVariable Long id) {
        return ResponseEntity.ok(reportingService.findById(id));
    }

    @PostMapping("/api/v1/reports/generate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ReportDTO> generateReport(
            @Valid @RequestBody ReportRequest req,
            @RequestHeader("X-User-Id") Long userId) {
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(reportingService.generate(req, userId));
    }

    @GetMapping("/api/v1/kpis")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    public ResponseEntity<KpiDTO> getKpis() {
        return ResponseEntity.ok(reportingService.getKpis());
    }

    @PostMapping("/api/v1/audit-packages")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    public ResponseEntity<ReportDTO> generateAuditPackage(
            @RequestBody ReportRequest req,
            @RequestHeader("X-User-Id") Long userId) {
        req.setType("AUDIT_PACKAGE");
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(reportingService.generate(req, userId));
    }
}
