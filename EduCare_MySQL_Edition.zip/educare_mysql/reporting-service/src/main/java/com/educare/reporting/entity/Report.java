package com.educare.reporting.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "reports")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Report {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;

    @Column(nullable = false, length = 100)
    private String type; // ATTENDANCE, GRADE, AUDIT_PACKAGE, KPI

    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String parameters; // JSON

    @Column(columnDefinition = "TEXT")
    private String resultUri; // S3/storage path

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "PENDING"; // PENDING, COMPLETED, FAILED

    @Column(nullable = false)
    private Long requestedBy;

    @CreationTimestamp @Column(updatable = false)
    private Instant requestedAt;

    private Instant completedAt;
}
