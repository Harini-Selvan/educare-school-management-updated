package com.educare.reporting.repository;

import com.educare.reporting.entity.Report;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {
    Page<Report> findByRequestedByOrderByRequestedAtDesc(Long userId, Pageable pageable);
    Page<Report> findByTypeOrderByRequestedAtDesc(String type, Pageable pageable);
}
