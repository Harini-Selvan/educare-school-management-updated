-- V1__init_reporting_schema.sql

CREATE TABLE IF NOT EXISTS reports (
    report_id    BIGINT AUTO_INCREMENT    PRIMARY KEY,
    type         VARCHAR(100) NOT NULL,
    title        VARCHAR(200) NOT NULL,
    parameters   TEXT,
    result_uri   TEXT,
    status       VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    requested_by BIGINT       NOT NULL,
    requested_at DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME
);

CREATE INDEX idx_reports_requested_by ON reports(requested_by, requested_at DESC);
CREATE INDEX idx_reports_type         ON reports(type, requested_at DESC);
CREATE INDEX idx_reports_status       ON reports(status);
