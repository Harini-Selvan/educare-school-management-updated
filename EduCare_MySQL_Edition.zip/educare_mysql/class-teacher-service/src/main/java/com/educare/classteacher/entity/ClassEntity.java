package com.educare.classteacher.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;

@Entity
@Table(name = "classes")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ClassEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long classId;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(length = 50)
    private String gradeLevel;

    @Column(columnDefinition = "TEXT")
    private String scheduleJson;

    @Builder.Default
    private Integer capacity = 30;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "ACTIVE";

    @CreationTimestamp @Column(updatable = false) private Instant createdAt;
    @UpdateTimestamp private Instant updatedAt;
}
