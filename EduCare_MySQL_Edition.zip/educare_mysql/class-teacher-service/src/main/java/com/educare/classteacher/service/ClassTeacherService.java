package com.educare.classteacher.service;

import com.educare.classteacher.dto.ClassTeacherDTOs.*;
import com.educare.classteacher.entity.ClassEntity;
import com.educare.classteacher.entity.Teacher;
import com.educare.classteacher.entity.TeacherAssignment;
import com.educare.classteacher.exception.BusinessException;
import com.educare.classteacher.exception.ResourceNotFoundException;
import com.educare.classteacher.repository.ClassRepository;
import com.educare.classteacher.repository.TeacherAssignmentRepository;
import com.educare.classteacher.repository.TeacherRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClassTeacherService {

    private final ClassRepository classRepo;
    private final TeacherRepository teacherRepo;
    private final TeacherAssignmentRepository assignmentRepo;

    // --- Class operations ---

    public Page<ClassDTO> findAllClasses(Pageable pageable) {
        return classRepo.findAll(pageable).map(this::toClassDTO);
    }

    @Transactional
    public ClassDTO createClass(ClassDTO dto) {
        ClassEntity c = ClassEntity.builder()
                .name(dto.getName())
                .gradeLevel(dto.getGradeLevel())
                .scheduleJson(dto.getScheduleJson())
                .capacity(dto.getCapacity() != null ? dto.getCapacity() : 30)
                .status("ACTIVE")
                .build();
        ClassEntity saved = classRepo.save(c);
        log.info("Class created: {}", saved.getClassId());
        return toClassDTO(saved);
    }

    public ClassDTO findClassById(Long id) {
        return classRepo.findById(id)
                .map(this::toClassDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + id));
    }

    // --- Teacher operations ---

    public Page<TeacherDTO> findAllTeachers(Pageable pageable) {
        return teacherRepo.findAll(pageable).map(this::toTeacherDTO);
    }

    @Transactional
    public TeacherDTO createTeacher(TeacherDTO dto) {
        Teacher t = Teacher.builder()
                .name(dto.getName())
                .department(dto.getDepartment())
                .contactInfo(dto.getContactInfo())
                .status("ACTIVE")
                .build();
        return toTeacherDTO(teacherRepo.save(t));
    }

    // --- Assignment operations ---

    @Transactional
    public AssignmentDTO assignTeacher(Long teacherId, AssignmentRequest req) {
        if (!teacherRepo.existsById(teacherId))
            throw new ResourceNotFoundException("Teacher not found: " + teacherId);
        if (!classRepo.existsById(req.getClassId()))
            throw new ResourceNotFoundException("Class not found: " + req.getClassId());
        if (assignmentRepo.existsByTeacherIdAndClassIdAndStatus(teacherId, req.getClassId(), "ACTIVE"))
            throw new BusinessException("Teacher already assigned to this class");

        TeacherAssignment a = TeacherAssignment.builder()
                .teacherId(teacherId)
                .classId(req.getClassId())
                .assignedBy(0L)
                .status("ACTIVE")
                .build();
        return toAssignmentDTO(assignmentRepo.save(a));
    }

    public List<AssignmentDTO> getTeacherAssignments(Long teacherId) {
        return assignmentRepo.findByTeacherIdAndStatus(teacherId, "ACTIVE")
                .stream().map(this::toAssignmentDTO).collect(Collectors.toList());
    }

    @Transactional
    public void removeAssignment(Long classId, Long teacherId) {
        assignmentRepo.findByTeacherIdAndStatus(teacherId, "ACTIVE").stream()
                .filter(a -> a.getClassId().equals(classId))
                .findFirst()
                .ifPresent(a -> {
                    a.setStatus("INACTIVE");
                    assignmentRepo.save(a);
                    log.info("Removed teacher {} from class {}", teacherId, classId);
                });
    }

    // --- Mappers ---

    private ClassDTO toClassDTO(ClassEntity c) {
        return ClassDTO.builder()
                .classId(c.getClassId()).name(c.getName())
                .gradeLevel(c.getGradeLevel()).scheduleJson(c.getScheduleJson())
                .capacity(c.getCapacity()).status(c.getStatus()).build();
    }

    private TeacherDTO toTeacherDTO(Teacher t) {
        return TeacherDTO.builder()
                .teacherId(t.getTeacherId()).name(t.getName())
                .department(t.getDepartment()).contactInfo(t.getContactInfo())
                .status(t.getStatus()).build();
    }

    private AssignmentDTO toAssignmentDTO(TeacherAssignment a) {
        return AssignmentDTO.builder()
                .assignId(a.getAssignId()).teacherId(a.getTeacherId())
                .classId(a.getClassId()).assignedBy(a.getAssignedBy())
                .assignedAt(a.getAssignedAt()).status(a.getStatus()).build();
    }
}
