package com.educare.classteacher.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "teacher_assignments",
       uniqueConstraints = @UniqueConstraint(columnNames = {"teacher_id","class_id"}))
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TeacherAssignment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long assignId;

    @Column(nullable = false)
    private Long teacherId;

    @Column(nullable = false)
    private Long classId;

    @Column(nullable = false)
    private Long assignedBy;

    @CreationTimestamp @Column(updatable = false)
    private Instant assignedAt;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "ACTIVE";
}
