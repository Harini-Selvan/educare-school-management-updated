package com.educare.classteacher.repository;

import com.educare.classteacher.entity.TeacherAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TeacherAssignmentRepository extends JpaRepository<TeacherAssignment, Long> {
    List<TeacherAssignment> findByTeacherIdAndStatus(Long teacherId, String status);
    List<TeacherAssignment> findByClassIdAndStatus(Long classId, String status);
    boolean existsByTeacherIdAndClassIdAndStatus(Long teacherId, Long classId, String status);
}
