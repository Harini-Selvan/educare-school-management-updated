package com.educare.classteacher.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.Instant;

public class ClassTeacherDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ClassDTO {
        private Long classId;
        @NotBlank private String name;
        private String gradeLevel;
        private String scheduleJson;
        private Integer capacity;
        private String status;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class TeacherDTO {
        private Long teacherId;
        @NotBlank private String name;
        private String department;
        private String contactInfo;
        private String status;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AssignmentRequest {
        @NotNull private Long classId;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AssignmentDTO {
        private Long assignId;
        private Long teacherId;
        private Long classId;
        private Long assignedBy;
        private Instant assignedAt;
        private String status;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
