package com.educare.classteacher.exception;
public class BusinessException extends RuntimeException {
    public BusinessException(String msg) { super(msg); }
}
