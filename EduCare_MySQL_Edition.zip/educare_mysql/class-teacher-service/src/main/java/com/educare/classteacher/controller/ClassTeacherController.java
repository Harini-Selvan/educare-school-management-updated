package com.educare.classteacher.controller;

import com.educare.classteacher.dto.ClassTeacherDTOs.*;
import com.educare.classteacher.service.ClassTeacherService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ClassTeacherController {

    private final ClassTeacherService service;

    @GetMapping("/api/v1/classes")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER')")
    public ResponseEntity<Page<ClassDTO>> listClasses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(service.findAllClasses(PageRequest.of(page, size)));
    }

    @PostMapping("/api/v1/classes")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ClassDTO> createClass(@Valid @RequestBody ClassDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.createClass(dto));
    }

    @GetMapping("/api/v1/classes/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER')")
    public ResponseEntity<ClassDTO> getClass(@PathVariable Long id) {
        return ResponseEntity.ok(service.findClassById(id));
    }

    @GetMapping("/api/v1/teachers")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<TeacherDTO>> listTeachers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(service.findAllTeachers(PageRequest.of(page, size)));
    }

    @PostMapping("/api/v1/teachers")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<TeacherDTO> createTeacher(@Valid @RequestBody TeacherDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.createTeacher(dto));
    }

    @PostMapping("/api/v1/teachers/{teacherId}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AssignmentDTO> assignTeacher(
            @PathVariable Long teacherId,
            @Valid @RequestBody AssignmentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.assignTeacher(teacherId, req));
    }

    @GetMapping("/api/v1/teachers/{teacherId}/assignments")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER')")
    public ResponseEntity<List<AssignmentDTO>> getAssignments(@PathVariable Long teacherId) {
        return ResponseEntity.ok(service.getTeacherAssignments(teacherId));
    }

    @DeleteMapping("/api/v1/classes/{classId}/teachers/{teacherId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> removeAssignment(
            @PathVariable Long classId,
            @PathVariable Long teacherId) {
        service.removeAssignment(classId, teacherId);
        return ResponseEntity.noContent().build();
    }
}
