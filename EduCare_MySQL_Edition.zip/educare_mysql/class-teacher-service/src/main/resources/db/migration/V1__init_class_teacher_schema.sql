-- V1__init_class_teacher_schema.sql

CREATE TABLE IF NOT EXISTS classes (
    class_id      BIGINT AUTO_INCREMENT    PRIMARY KEY,
    name          VARCHAR(200) NOT NULL,
    grade_level   VARCHAR(50),
    schedule_json TEXT,
    capacity      INT          NOT NULL DEFAULT 30,
    status        VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    created_at    DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_classes_status      ON classes(status);
CREATE INDEX idx_classes_grade_level ON classes(grade_level);

CREATE TABLE IF NOT EXISTS teachers (
    teacher_id   BIGINT AUTO_INCREMENT    PRIMARY KEY,
    name         VARCHAR(200) NOT NULL,
    department   VARCHAR(100),
    contact_info TEXT,
    status       VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
    created_at   DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_teachers_department ON teachers(department);
CREATE INDEX idx_teachers_status     ON teachers(status);

CREATE TABLE IF NOT EXISTS teacher_assignments (
    assign_id   BIGINT AUTO_INCREMENT   PRIMARY KEY,
    teacher_id  BIGINT      NOT NULL REFERENCES teachers(teacher_id),
    class_id    BIGINT      NOT NULL REFERENCES classes(class_id),
    assigned_by BIGINT      NOT NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status      VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    UNIQUE (teacher_id, class_id)
);

CREATE INDEX idx_teacher_assign_teacher ON teacher_assignments(teacher_id, status);
CREATE INDEX idx_teacher_assign_class   ON teacher_assignments(class_id,   status);
