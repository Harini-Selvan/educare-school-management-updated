package com.educare.examgrade.service;

import com.educare.examgrade.dto.ExamGradeDTOs.*;
import com.educare.examgrade.entity.Exam;
import com.educare.examgrade.entity.Grade;
import com.educare.examgrade.entity.GradeChange;
import com.educare.examgrade.exception.BusinessException;
import com.educare.examgrade.repository.ExamRepository;
import com.educare.examgrade.repository.GradeChangeRepository;
import com.educare.examgrade.repository.GradeRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GradeServiceTest {

    @Mock GradeRepository gradeRepo;
    @Mock GradeChangeRepository changeRepo;
    @Mock ExamRepository examRepo;
    @InjectMocks GradeService gradeService;

    @Test
    @DisplayName("submitting grade saves and returns DTO")
    void submitGrade() {
        GradeRequest req = new GradeRequest(1L, 10L, new BigDecimal("85.5"));
        Exam exam = Exam.builder().examId(10L).status("SCHEDULED").build();
        Grade grade = Grade.builder().gradeId(1L).studentId(1L).examId(10L)
                .gradeValue(new BigDecimal("85.5")).status("SUBMITTED").build();

        when(examRepo.findById(10L)).thenReturn(Optional.of(exam));
        when(gradeRepo.findByStudentIdAndExamId(1L, 10L)).thenReturn(Optional.empty());
        when(gradeRepo.save(any())).thenReturn(grade);

        GradeDTO result = gradeService.submit(req, "teacher@school.com");

        assertNotNull(result);
        assertEquals(new BigDecimal("85.5"), result.getGradeValue());
        verify(gradeRepo).save(any(Grade.class));
    }

    @Test
    @DisplayName("duplicate grade submission throws BusinessException")
    void duplicateGrade() {
        GradeRequest req = new GradeRequest(1L, 10L, new BigDecimal("85.5"));
        Exam exam = Exam.builder().examId(10L).status("SCHEDULED").build();
        Grade existing = Grade.builder().gradeId(1L).build();

        when(examRepo.findById(10L)).thenReturn(Optional.of(exam));
        when(gradeRepo.findByStudentIdAndExamId(1L, 10L)).thenReturn(Optional.of(existing));

        assertThrows(BusinessException.class,
                () -> gradeService.submit(req, "teacher@school.com"));
    }

    @Test
    @DisplayName("grade modification requires reason and evidence")
    void modifyGradeWithEvidence() {
        Grade existing = Grade.builder().gradeId(1L).studentId(1L).examId(10L)
                .gradeValue(new BigDecimal("80.0")).status("SUBMITTED").build();

        when(gradeRepo.findById(1L)).thenReturn(Optional.of(existing));
        when(gradeRepo.save(any())).thenReturn(existing);

        GradeChangeRequest req = new GradeChangeRequest(
                new BigDecimal("90.0"), "Clerical error", "evidence://doc1.pdf");

        gradeService.modify(1L, req);

        verify(gradeRepo).save(any(Grade.class));
        verify(changeRepo).save(argThat(c -> c.getReason().equals("Clerical error")));
    }
}
