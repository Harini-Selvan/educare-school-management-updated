package com.educare.examgrade.repository;

import com.educare.examgrade.entity.GradeChange;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GradeChangeRepository extends JpaRepository<GradeChange, Long> {
    List<GradeChange> findByGradeId(Long gradeId);
    Page<GradeChange> findAll(Pageable pageable);
}
