package com.educare.examgrade.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "grades",
       uniqueConstraints = @UniqueConstraint(columnNames = {"student_id","exam_id"}))
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Grade {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long gradeId;

    @Column(nullable = false)
    private Long studentId;

    @Column(nullable = false)
    private Long examId;

    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal gradeValue;

    @Column(nullable = false)
    private Long submittedBy;

    @CreationTimestamp @Column(updatable = false)
    private Instant submittedAt;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "SUBMITTED"; // SUBMITTED, MODERATED, PUBLISHED
}
