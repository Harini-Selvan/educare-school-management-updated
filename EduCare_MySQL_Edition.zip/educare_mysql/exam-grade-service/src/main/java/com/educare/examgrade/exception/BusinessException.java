package com.educare.examgrade.exception;
public class BusinessException extends RuntimeException {
    public BusinessException(String msg) { super(msg); }
}
