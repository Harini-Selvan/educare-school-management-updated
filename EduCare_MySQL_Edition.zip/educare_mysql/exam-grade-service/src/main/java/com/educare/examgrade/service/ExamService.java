package com.educare.examgrade.service;

import com.educare.examgrade.dto.ExamGradeDTOs.*;
import com.educare.examgrade.entity.Exam;
import com.educare.examgrade.exception.ResourceNotFoundException;
import com.educare.examgrade.repository.ExamRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExamService {

    private final ExamRepository examRepo;

    @Transactional
    public ExamDTO schedule(ExamRequest req) {
        Exam exam = Exam.builder()
                .classId(req.getClassId())
                .scheduledAt(req.getScheduledAt())
                .subject(req.getSubject())
                .status("SCHEDULED")
                .build();
        Exam saved = examRepo.save(exam);
        log.info("Exam scheduled: {}", saved.getExamId());
        return toDTO(saved);
    }

    public Page<ExamDTO> findAll(Pageable pageable) {
        return examRepo.findAll(pageable).map(this::toDTO);
    }

    public ExamDTO findById(Long id) {
        return examRepo.findById(id)
                .map(this::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + id));
    }

    @Transactional
    public ExamDTO updateStatus(Long id, String status) {
        Exam exam = examRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + id));
        exam.setStatus(status);
        return toDTO(examRepo.save(exam));
    }

    private ExamDTO toDTO(Exam e) {
        return ExamDTO.builder()
                .examId(e.getExamId())
                .classId(e.getClassId())
                .scheduledAt(e.getScheduledAt())
                .subject(e.getSubject())
                .status(e.getStatus())
                .build();
    }
}
