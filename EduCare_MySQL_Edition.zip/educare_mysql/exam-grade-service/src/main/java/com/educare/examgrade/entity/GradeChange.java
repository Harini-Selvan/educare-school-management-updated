package com.educare.examgrade.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

@Entity
@Table(name = "grade_changes")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class GradeChange {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long changeId;

    @Column(nullable = false)
    private Long gradeId;

    @Column(nullable = false)
    private Long changedBy;

    @CreationTimestamp @Column(updatable = false)
    private Instant changedAt;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String reason;

    @Column(length = 500)
    private String evidenceUri;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "APPROVED";
}
