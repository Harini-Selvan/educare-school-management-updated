package com.educare.examgrade.service;

import com.educare.examgrade.dto.ExamGradeDTOs.*;
import com.educare.examgrade.entity.Exam;
import com.educare.examgrade.entity.Grade;
import com.educare.examgrade.entity.GradeChange;
import com.educare.examgrade.exception.BusinessException;
import com.educare.examgrade.exception.ResourceNotFoundException;
import com.educare.examgrade.repository.ExamRepository;
import com.educare.examgrade.repository.GradeChangeRepository;
import com.educare.examgrade.repository.GradeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class GradeService {

    private final GradeRepository gradeRepo;
    private final GradeChangeRepository changeRepo;
    private final ExamRepository examRepo;

    @Transactional
    public GradeDTO submit(GradeRequest req, String submitterEmail) {
        Exam exam = examRepo.findById(req.getExamId())
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + req.getExamId()));

        if ("CANCELLED".equals(exam.getStatus())) {
            throw new BusinessException("Cannot submit grade for a cancelled exam");
        }

        if (gradeRepo.findByStudentIdAndExamId(req.getStudentId(), req.getExamId()).isPresent()) {
            throw new BusinessException("Grade already submitted for this student and exam");
        }

        Grade grade = Grade.builder()
                .studentId(req.getStudentId())
                .examId(req.getExamId())
                .gradeValue(req.getGradeValue())
                .submittedBy(0L) // resolved from JWT header in production
                .status("SUBMITTED")
                .build();

        Grade saved = gradeRepo.save(grade);
        log.info("Grade submitted by {} for student={} exam={}", submitterEmail, req.getStudentId(), req.getExamId());
        return toGradeDTO(saved);
    }

    @Transactional
    public GradeDTO modify(Long gradeId, GradeChangeRequest req) {
        Grade grade = gradeRepo.findById(gradeId)
                .orElseThrow(() -> new ResourceNotFoundException("Grade not found: " + gradeId));

        grade.setGradeValue(req.getNewGradeValue());
        grade.setStatus("MODERATED");
        gradeRepo.save(grade);

        GradeChange change = GradeChange.builder()
                .gradeId(gradeId)
                .changedBy(0L)
                .reason(req.getReason())
                .evidenceUri(req.getEvidenceUri())
                .status("APPROVED")
                .build();
        changeRepo.save(change);

        log.info("Grade {} modified. Reason: {}", gradeId, req.getReason());
        return toGradeDTO(grade);
    }

    public List<GradeDTO> findByStudent(Long studentId) {
        return gradeRepo.findByStudentId(studentId).stream()
                .map(this::toGradeDTO).collect(Collectors.toList());
    }

    private GradeDTO toGradeDTO(Grade g) {
        return GradeDTO.builder()
                .gradeId(g.getGradeId())
                .studentId(g.getStudentId())
                .examId(g.getExamId())
                .gradeValue(g.getGradeValue())
                .submittedBy(g.getSubmittedBy())
                .submittedAt(g.getSubmittedAt())
                .status(g.getStatus())
                .build();
    }
}
