package com.educare.examgrade.repository;

import com.educare.examgrade.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByClassId(Long classId);
    List<Exam> findByStatus(String status);
}
