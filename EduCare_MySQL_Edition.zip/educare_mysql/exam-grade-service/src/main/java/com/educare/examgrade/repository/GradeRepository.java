package com.educare.examgrade.repository;

import com.educare.examgrade.entity.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByStudentId(Long studentId);
    List<Grade> findByExamId(Long examId);
    Optional<Grade> findByStudentIdAndExamId(Long studentId, Long examId);
}
