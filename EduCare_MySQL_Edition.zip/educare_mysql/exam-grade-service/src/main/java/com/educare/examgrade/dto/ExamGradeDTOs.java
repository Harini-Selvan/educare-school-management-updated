package com.educare.examgrade.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

public class ExamGradeDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ExamRequest {
        @NotNull  private Long classId;
        @NotNull  private Instant scheduledAt;
        @NotBlank private String subject;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ExamDTO {
        private Long examId;
        private Long classId;
        private Instant scheduledAt;
        private String subject;
        private String status;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class GradeRequest {
        @NotNull private Long studentId;
        @NotNull private Long examId;
        @NotNull
        @DecimalMin("0.0") @DecimalMax("100.0")
        private BigDecimal gradeValue;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class GradeDTO {
        private Long gradeId;
        private Long studentId;
        private Long examId;
        private BigDecimal gradeValue;
        private Long submittedBy;
        private Instant submittedAt;
        private String status;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class GradeChangeRequest {
        @NotNull  private BigDecimal newGradeValue;
        @NotBlank private String reason;
        private String evidenceUri;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private String code;
        private String message;
        private Instant timestamp;
    }
}
