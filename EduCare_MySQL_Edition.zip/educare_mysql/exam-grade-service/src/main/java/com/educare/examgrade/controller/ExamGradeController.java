package com.educare.examgrade.controller;

import com.educare.examgrade.dto.ExamGradeDTOs.*;
import com.educare.examgrade.service.ExamService;
import com.educare.examgrade.service.GradeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@Slf4j
public class ExamGradeController {

    private final ExamService examService;
    private final GradeService gradeService;

    // ---- EXAM ENDPOINTS ----

    @PostMapping("/api/v1/exams")
    @PreAuthorize("hasRole('EXAM_COORDINATOR')")
    public ResponseEntity<ExamDTO> scheduleExam(@Valid @RequestBody ExamRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(examService.schedule(req));
    }

    @GetMapping("/api/v1/exams")
    @PreAuthorize("hasAnyRole('TEACHER','STUDENT','ADMIN','EXAM_COORDINATOR')")
    public ResponseEntity<Page<ExamDTO>> listExams(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(examService.findAll(PageRequest.of(page, size)));
    }

    @GetMapping("/api/v1/exams/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','STUDENT','ADMIN','EXAM_COORDINATOR')")
    public ResponseEntity<ExamDTO> getExam(@PathVariable Long id) {
        return ResponseEntity.ok(examService.findById(id));
    }

    @PutMapping("/api/v1/exams/{id}/status")
    @PreAuthorize("hasRole('EXAM_COORDINATOR')")
    public ResponseEntity<ExamDTO> updateExamStatus(@PathVariable Long id,
                                                     @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(examService.updateStatus(id, body.get("status")));
    }

    // ---- GRADE ENDPOINTS ----

    @PostMapping("/api/v1/grades")
    @PreAuthorize("hasAnyRole('TEACHER','EXAM_COORDINATOR')")
    public ResponseEntity<GradeDTO> submitGrade(
            @Valid @RequestBody GradeRequest req,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(gradeService.submit(req, user.getUsername()));
    }

    @PutMapping("/api/v1/grades/{gradeId}")
    @PreAuthorize("hasRole('EXAM_COORDINATOR')")
    public ResponseEntity<GradeDTO> modifyGrade(
            @PathVariable Long gradeId,
            @Valid @RequestBody GradeChangeRequest req) {
        return ResponseEntity.ok(gradeService.modify(gradeId, req));
    }

    @GetMapping("/api/v1/grades/student/{studentId}")
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER','STUDENT','PARENT','EXAM_COORDINATOR')")
    public ResponseEntity<List<GradeDTO>> getStudentGrades(@PathVariable Long studentId) {
        return ResponseEntity.ok(gradeService.findByStudent(studentId));
    }
}
