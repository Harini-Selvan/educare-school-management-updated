import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { examAPI, classAPI, studentAPI, authAPI, notificationAPI } from '../../services/api';

function computeStatus(scheduledAt) {
  if (!scheduledAt) return 'SCHEDULED';
  const now = new Date();
  const d = new Date(scheduledAt);
  if (now < d) return 'SCHEDULED';
  if (now > new Date(d.getTime() + 3 * 60 * 60 * 1000)) return 'COMPLETED';
  return 'ONGOING';
}
const STATUS_COLORS = {
  SCHEDULED: { bg: '#eff6ff', color: '#1e40af', dot: '#3b82f6' },
  ONGOING:   { bg: '#fef3c7', color: '#92400e', dot: '#f59e0b' },
  COMPLETED: { bg: '#f0fdf4', color: '#065f46', dot: '#22c55e' },
  CANCELLED: { bg: '#fef2f2', color: '#991b1b', dot: '#ef4444' },
};

async function sendExamNotifications(classId, message, classes, allUsers) {
  // Get enrollments for the class
  let notifyTargets = [];
  try {
    const enrollRes = await studentAPI.getEnrollmentsByClass(classId);
    const studentIds = (enrollRes.data || []).filter(e => e.status === 'ACTIVE').map(en => en.studentId);
    for (const sid of studentIds) {
      try {
        const sRec = await studentAPI.getById(sid);
        const sRecord = sRec.data;
        // Match student user by name
        const sUser = allUsers.find(u =>
          u.role === 'STUDENT' && u.name?.toLowerCase() === sRecord?.name?.toLowerCase()
        );
        if (sUser) notifyTargets.push({ userId: sUser.id, recipientEmail: sUser.email });
        const parentEmail = sRecord?.parentEmail;
        if (parentEmail) {
          const pUser = allUsers.find(u => u.email === parentEmail);
          if (pUser) notifyTargets.push({ userId: pUser.id, recipientEmail: parentEmail });
          else notifyTargets.push({ userId: 0, recipientEmail: parentEmail }); // parent email fallback
        }
      } catch {}
    }
    // Resolve teacher: assignment teacherId -> teacher profile -> auth userId
    const classAssignments = await classAPI.getAssignmentsByClass(classId);
    const teacherProfilesRes = await classAPI.getTeachers();
    const teacherProfiles = teacherProfilesRes.data || [];
    for (const asgn of (classAssignments.data || [])) {
      const teacherProfile = teacherProfiles.find(t => String(t.id) === String(asgn.teacherId));
      if (!teacherProfile) continue;
      const tUser = allUsers.find(u =>
        u.role === 'TEACHER' && String(u.id) === String(teacherProfile.userId)
      );
      if (tUser) notifyTargets.push({ userId: tUser.id, recipientEmail: tUser.email });
    }
  } catch {}

  let sentCount = 0;
  for (const target of notifyTargets) {
    try {
      await notificationAPI.create({ userId: target.userId, recipientEmail: target.recipientEmail, message, category: 'EXAM', entityId: Number(classId) });
      sentCount++;
    } catch {}
  }
  return sentCount;
}

export default function CoordinatorExams() {
  const [exams, setExams] = useState([]);
  const [classes, setClasses] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [selectedExam, setSelectedExam] = useState(null);
  const [form, setForm] = useState({ classId: '', subject: '', fromTime: '', toTime: '', totalMarks: 100 });
  const [editForm, setEditForm] = useState({ classId: '', subject: '', fromTime: '', toTime: '', totalMarks: 100 });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [filterClass, setFilterClass] = useState('');

  const load = () => {
    setLoading(true);
    Promise.all([examAPI.getAll(), classAPI.getAll(), authAPI.getUsers()])
      .then(([e, c, u]) => {
        setExams(e.data || []);
        setClasses(c.data?.filter(cls => cls.status === 'ACTIVE') || []);
        setAllUsers(u.data || []);
      }).catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const handleCreate = async e => {
    e.preventDefault(); setSaving(true);
    try {
      const created = await examAPI.create({
        classId: Number(form.classId), subject: form.subject,
        scheduledAt: form.fromTime, fromTime: form.fromTime, toTime: form.toTime,
        totalMarks: Number(form.totalMarks), passingMarks: Math.round(Number(form.totalMarks) * 0.4),
      });
      // Auto-notify students, parents, teachers
      const className = classes.find(c => String(c.id) === String(form.classId))?.name || 'the class';
      const msg = `📢 New exam scheduled: ${form.subject} for ${className}. Date: ${new Date(form.fromTime).toLocaleString()} to ${new Date(form.toTime).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}. Max marks: ${form.totalMarks}`;
      const sentCount = await sendExamNotifications(form.classId, msg, classes, allUsers);
      setToast({ message: `Exam scheduled! Notifications sent to ${sentCount} people.`, type: 'success' });
      setModal(false);
      setForm({ classId: '', subject: '', fromTime: '', toTime: '', totalMarks: 100 });
      load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error scheduling exam', type: 'error' });
    } finally { setSaving(false); }
  };

  const openEdit = (exam) => {
    setSelectedExam(exam);
    setEditForm({
      classId: String(exam.classId), subject: exam.subject,
      fromTime: exam.fromTime ? exam.fromTime.slice(0,16) : (exam.scheduledAt ? exam.scheduledAt.slice(0,16) : ''),
      toTime: exam.toTime ? exam.toTime.slice(0,16) : '',
      totalMarks: exam.totalMarks || 100,
    });
    setEditModal(true);
  };

  const handleReschedule = async e => {
    e.preventDefault(); setSaving(true);
    try {
      await examAPI.create({ // We'll update — use the updateStatus or re-create with PUT if available
        classId: Number(editForm.classId), subject: editForm.subject,
        scheduledAt: editForm.fromTime, fromTime: editForm.fromTime, toTime: editForm.toTime,
        totalMarks: Number(editForm.totalMarks), passingMarks: Math.round(Number(editForm.totalMarks) * 0.4),
      });
      // Notify about reschedule
      const className = classes.find(c => String(c.id) === String(editForm.classId))?.name || 'the class';
      const msg = `🔔 RESCHEDULE: ${editForm.subject} exam for ${className} has been rescheduled. New time: ${new Date(editForm.fromTime).toLocaleString()} to ${new Date(editForm.toTime).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}. Max marks: ${editForm.totalMarks}`;
      const sentCount = await sendExamNotifications(editForm.classId, msg, classes, allUsers);
      setToast({ message: `Exam rescheduled! Notifications sent to ${sentCount} people.`, type: 'success' });
      setEditModal(false);
      load();
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error rescheduling exam', type: 'error' });
    } finally { setSaving(false); }
  };

  const getClassName = id => classes.find(c => String(c.id) === String(id))?.name || `Class #${id}`;
  const displayedExams = filterClass ? exams.filter(e => String(e.classId) === filterClass) : exams;

  const statusCounts = { SCHEDULED: 0, ONGOING: 0, COMPLETED: 0 };
  exams.forEach(ex => { const s = computeStatus(ex.scheduledAt); if (statusCounts[s] !== undefined) statusCounts[s]++; });

  const StatusBadge = ({ scheduledAt, serverStatus }) => {
    const computed = computeStatus(scheduledAt) || serverStatus;
    const cfg = STATUS_COLORS[computed] || STATUS_COLORS.SCHEDULED;
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: cfg.bg, color: cfg.color, padding: '4px 10px', borderRadius: 20, fontSize: 12, fontWeight: 700 }}>
        <span style={{ width: 7, height: 7, borderRadius: '50%', background: cfg.dot, display: 'inline-block' }} />{computed}
      </span>
    );
  };

  const columns = [
    { title: 'Subject', key: 'subject', render: v => <span style={{ fontWeight: 600 }}>{v}</span> },
    { title: 'Class', key: 'classId', render: v => <span style={{ fontSize: 13 }}>{getClassName(v)}</span> },
    { title: 'From', key: 'fromTime', render: (v, r) => {
      const t = v || r.scheduledAt;
      return t ? (<div><div style={{ fontWeight: 600 }}>{new Date(t).toLocaleDateString()}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{new Date(t).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div></div>) : '—';
    }},
    { title: 'To', key: 'toTime', render: v => v ? <span style={{ fontSize: 13 }}>{new Date(v).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</span> : '—' },
    { title: 'Max Marks', key: 'totalMarks', render: v => <span style={{ fontWeight: 700, fontSize: 15 }}>{v}</span> },
    { title: 'Status', key: 'status', render: (v, r) => <StatusBadge scheduledAt={r.scheduledAt} serverStatus={v} /> },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <Button size="sm" variant="ghost" onClick={() => openEdit(r)}>✏️ Reschedule</Button>
    )},
  ];

  const ExamForm = ({ formData, setFormData, onSubmit, submitLabel }) => (
    <form onSubmit={onSubmit}>
      <Select label="Class" value={formData.classId} onChange={e => setFormData({...formData, classId: e.target.value})} required
        placeholder="Select class..." options={classes.map(c => ({value: c.id, label: c.name}))} />
      <Input label="Subject" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} required placeholder="Mathematics" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Input label="From Time" type="datetime-local" value={formData.fromTime} onChange={e => setFormData({...formData, fromTime: e.target.value})} required hint="Exam start" />
        <Input label="To Time" type="datetime-local" value={formData.toTime} onChange={e => setFormData({...formData, toTime: e.target.value})} required hint="Exam end" />
      </div>
      <Input label="Maximum Marks" type="number" value={formData.totalMarks} onChange={e => setFormData({...formData, totalMarks: e.target.value})} required placeholder="100" />
      <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: 13, color: '#065f46' }}>
        ✅ Notification will be automatically sent to all students, parents, and teachers in the selected class.
      </div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
        <Button variant="secondary" onClick={() => { setModal(false); setEditModal(false); }}>Cancel</Button>
        <Button type="submit" loading={saving}>{submitLabel}</Button>
      </div>
    </form>
  );

  return (
    <DashboardLayout title="Exam Schedule">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 20 }}>
        {[['Scheduled', statusCounts.SCHEDULED, '#1e40af'], ['Ongoing', statusCounts.ONGOING, '#d97706'], ['Completed', statusCounts.COMPLETED, '#059669']].map(([l, v, c]) => (
          <div key={l} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, borderTop: `3px solid ${c}` }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: c }}>{v}</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{l} Exams</div>
          </div>
        ))}
      </div>

      <Card
        title="All Exams"
        subtitle={`${displayedExams.length} exams${filterClass ? ' in selected class' : ' total'}`}
        extra={
          <div style={{ display: 'flex', gap: 8 }}>
            <select value={filterClass} onChange={e => setFilterClass(e.target.value)}
              style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 13, background: 'var(--surface)', outline: 'none' }}>
              <option value="">All Classes</option>
              {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <Button onClick={() => setModal(true)}>+ Schedule Exam</Button>
          </div>
        }
      >
        <Table columns={columns} data={displayedExams} loading={loading} emptyText="No exams scheduled yet" />
      </Card>

      <Modal open={modal} onClose={() => setModal(false)} title="Schedule New Exam">
        <ExamForm formData={form} setFormData={setForm} onSubmit={handleCreate} submitLabel="Schedule Exam" />
      </Modal>

      <Modal open={editModal} onClose={() => setEditModal(false)} title={`Reschedule Exam — ${selectedExam?.subject}`}>
        <ExamForm formData={editForm} setFormData={setEditForm} onSubmit={handleReschedule} submitLabel="Reschedule & Notify" />
      </Modal>
    </DashboardLayout>
  );
}
