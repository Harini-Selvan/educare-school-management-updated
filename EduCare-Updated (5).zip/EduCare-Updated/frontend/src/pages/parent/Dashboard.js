import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { studentAPI, attendanceAPI, notificationAPI, examAPI, classAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

export default function ParentDashboard() {
  const [children, setChildren] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [childClass, setChildClass] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [cRes, nRes] = await Promise.all([studentAPI.getMyChildren(), notificationAPI.getMy()]);
        if (cancelled) return;
        const kids = cRes.data || [];
        setChildren(kids);
        setNotifications(nRes.data || []);
        // Load grades and class for first child
        if (kids.length > 0) {
          try {
            const g = await examAPI.getGradesByStudent(kids[0].id);
            if (!cancelled) setGrades(g.data || []);
          } catch {}
          try {
            const eRes = await studentAPI.getEnrollmentsByStudent(kids[0].id);
            const activeEnrollment = (eRes.data || []).find(e => e.status === 'ACTIVE');
            if (activeEnrollment) {
              const clsRes = await classAPI.getById(activeEnrollment.classId);
              if (!cancelled) setChildClass(clsRes.data?.name || '');
            }
          } catch {}
        }
      } catch (err) {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const child = children[0];
  const unreadNotifications = notifications.filter(n => n.status === 'UNREAD').length;

  return (
    <DashboardLayout title="Parent Portal">
      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #7c3aed' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🔔</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#7c3aed' }}>{unreadNotifications}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Unread Notifications</div>
        </div>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #059669' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📝</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#059669' }}>{grades.length}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Grade Records</div>
        </div>
        <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: 20, boxShadow: 'var(--shadow)', borderTop: '3px solid #0891b2' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🎓</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#0891b2' }}>{childClass || child?.program || '—'}</div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>Enrolled Class</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        {/* Child Info */}
        <Card title="Linked Student">
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           !child ? <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>No student linked. Ask admin to register student link.</p> : (
            <div>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center', padding: '16px', background: '#fdf4ff', borderRadius: 10, marginBottom: 16 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#e9d5ff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 800, color: '#7c3aed' }}>
                  {child.name?.charAt(0)}
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700 }}>{child.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{child.program} • ID: {child.id}</div>
                  <Badge text={child.status} />
                </div>
              </div>
              {[['Date of Birth', child.dob || '—'], ['Gender', child.gender || '—'], ['Contact', child.contactInfo || '—']].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{l}</span>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{v}</span>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                <Button size="sm" variant="ghost" onClick={() => navigate('/parent/grades')}>📊 View Grades</Button>
                <Button size="sm" variant="ghost" onClick={() => navigate('/parent/attendance')}>📅 Attendance</Button>
              </div>
            </div>
          )}
        </Card>

        {/* Notifications */}
        <Card title="Recent Notifications">
          {notifications.slice(0, 6).map(n => (
            <div key={n.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', gap: 6, marginBottom: 4 }}><Badge text={n.category} /></div>
              <p style={{ fontSize: 13, fontWeight: n.status === 'UNREAD' ? 600 : 400, color: 'var(--text)' }}>
                {n.message?.substring(0, 70)}{n.message?.length > 70 ? '...' : ''}
              </p>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</p>
            </div>
          ))}
          {notifications.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No notifications</p>}
        </Card>
      </div>
    </DashboardLayout>
  );
}
