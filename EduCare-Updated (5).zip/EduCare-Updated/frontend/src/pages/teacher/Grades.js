import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { examAPI, classAPI, studentAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function TeacherGrades() {
  const { user } = useAuth();
  const [classes, setClasses] = useState([]);
  const [exams, setExams] = useState([]);
  const [grades, setGrades] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [requestModal, setRequestModal] = useState(false);
  const [selectedGradeId, setSelectedGradeId] = useState(null);
  // Grade entry form — one row at a time
  const [gradeForm, setGradeForm] = useState({ studentId: '', marks: '', remarks: '' });
  const [submitted, setSubmitted] = useState(false);
  const [requestForm, setRequestForm] = useState({ newValue: '', reason: '', evidenceFile: null, studentId: null, examId: null });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    classAPI.getAll()
      .then(c => setClasses(c.data?.filter(cls => cls.status === 'ACTIVE') || []))
      .catch(() => {});
  }, []);

  function loadExams(classId) {
    setSelectedClass(classId);
    setSelectedExam(''); setGrades([]); setSubmitted(false);
    setGradeForm({ studentId: '', marks: '', remarks: '' });
    if (classId) {
      examAPI.getByClass(classId).then(r => setExams(r.data || [])).catch(() => {});
      // Load only enrolled students for this class
      studentAPI.getEnrollmentsByClass(classId).then(async enrollRes => {
        const activeIds = new Set((enrollRes.data || []).filter(e => e.status === 'ACTIVE').map(e => String(e.studentId)));
        if (activeIds.size > 0) {
          const allRes = await studentAPI.getAll();
          setStudents((allRes.data || []).filter(s => activeIds.has(String(s.id))));
        } else {
          // No enrollments — show all students as fallback
          const allRes = await studentAPI.getAll();
          setStudents(allRes.data || []);
        }
      }).catch(() => {});
    }
  }

  function loadGrades(examId) {
    setSelectedExam(examId);
    setSubmitted(false);
    setGradeForm(f => ({ ...f, studentId: '', marks: '', remarks: '' }));
    if (examId) examAPI.getGradesByExam(examId).then(r => setGrades(r.data || [])).catch(() => {});
  }

  const getStudentName = id => students.find(s => s.id === Number(id))?.name || `Student #${id}`;
  const getClassName = id => classes.find(c => String(c.id) === String(id))?.name || `Class #${id}`;

  async function submitGrade(e) {
    e.preventDefault();
    if (!gradeForm.studentId || !gradeForm.marks) {
      setToast({ message: 'Please select a student and enter marks.', type: 'error' });
      return;
    }
    setSaving(true);
    try {
      await examAPI.submitGrade({
        studentId: Number(gradeForm.studentId),
        examId: Number(selectedExam),
        gradeValue: Number(gradeForm.marks),
        remarks: gradeForm.remarks,
        evidenceUri: '',
        submittedBy: user?.email,
      });
      setToast({ message: `Marks submitted for ${getStudentName(gradeForm.studentId)}!`, type: 'success' });
      setGradeForm({ studentId: '', marks: '', remarks: '' });
      setSubmitted(true);
      examAPI.getGradesByExam(selectedExam).then(r => setGrades(r.data || [])).catch(() => {});
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error submitting marks', type: 'error' });
    } finally { setSaving(false); }
  }

  async function submitGradeChangeRequest(e) {
    e.preventDefault();
    setSaving(true);
    try {
      let evidenceUri = '';
      if (requestForm.evidenceFile) evidenceUri = `/evidence/${requestForm.evidenceFile.name}`;
      await examAPI.raiseGradeRequest({
        gradeId: Number(selectedGradeId),
        studentId: requestForm.studentId ? Number(requestForm.studentId) : null,
        examId: requestForm.examId ? Number(requestForm.examId) : null,
        requestedValue: Number(requestForm.newValue),
        reason: requestForm.reason,
        evidenceUri,
        requestedBy: user?.email,
      });
      setToast({ message: 'Grade change request submitted!', type: 'success' });
      setRequestModal(false);
      setRequestForm({ newValue: '', reason: '', evidenceFile: null });
    } catch (err) {
      setToast({ message: err.response?.data?.message || 'Error submitting request', type: 'error' });
    } finally { setSaving(false); }
  }

  const columns = [
    { title: 'Student Name', key: 'studentId', render: v => <span style={{ fontWeight: 600 }}>{getStudentName(v)}</span> },
    { title: 'Class', key: 'examId', render: () => <span style={{ fontSize: 13 }}>{getClassName(selectedClass)}</span> },
    { title: 'Date', key: 'submittedAt', render: v => <span style={{ fontSize: 13 }}>{v ? new Date(v).toLocaleDateString() : '—'}</span> },
    { title: 'Marks', key: 'gradeValue', render: v => (
      <span style={{ fontSize: 18, fontWeight: 800, color: v >= 40 ? 'var(--success)' : 'var(--danger)' }}>{v}</span>
    )},
    { title: 'Request Change', key: 'id', render: (v, r) => (
      <Button size="sm" variant="ghost" onClick={() => {
        setSelectedGradeId(v);
        setRequestForm({ newValue: '', reason: '', evidenceFile: null, studentId: r.studentId, examId: r.examId });
        setRequestModal(true);
      }}>Request Change</Button>
    )},
  ];

  return (
    <DashboardLayout title="Grade Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Grades by Exam">

        {/* Class and Exam selectors */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 180 }}>
            <Select
              label="Select Class"
              value={selectedClass}
              onChange={e => loadExams(e.target.value)}
              placeholder="Choose class..."
              options={classes.map(c => ({ value: c.id, label: c.name }))}
              style={{ marginBottom: 0 }}
            />
          </div>
          <div style={{ flex: 1, minWidth: 180 }}>
            <Select
              label="Select Exam"
              value={selectedExam}
              onChange={e => loadGrades(e.target.value)}
              placeholder="Choose exam..."
              options={exams.map(ex => ({ value: ex.id, label: `${ex.subject} — ${ex.scheduledAt ? new Date(ex.scheduledAt).toLocaleDateString() : 'N/A'}` }))}
              style={{ marginBottom: 0 }}
            />
          </div>
        </div>

        {/* Grade Entry Form — shown only when exam is selected */}
        {selectedExam && (
          <div style={{ background: '#f8fafc', border: '1px solid var(--border)', borderRadius: 10, padding: 16, marginBottom: 20 }}>
            <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14, color: 'var(--text)' }}>Add Grade Entry</h4>
            <form onSubmit={submitGrade}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 14 }}>
                <Select
                  label="Student"
                  value={gradeForm.studentId}
                  onChange={e => setGradeForm({ ...gradeForm, studentId: e.target.value })}
                  placeholder="Select student..."
                  options={students.map(s => ({ value: s.id, label: s.name }))}
                />
                <Input
                  label="Marks (0–100)"
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={gradeForm.marks}
                  onChange={e => setGradeForm({ ...gradeForm, marks: e.target.value })}
                  required
                  placeholder="e.g. 85"
                />
                <Input
                  label="Remarks"
                  value={gradeForm.remarks}
                  onChange={e => setGradeForm({ ...gradeForm, remarks: e.target.value })}
                  placeholder="Optional"
                />
              </div>
              <Button type="submit" loading={saving}>Submit Grade</Button>
            </form>
          </div>
        )}

        {/* Grades Table */}
        {submitted && grades.length > 0 && (
          <Table columns={columns} data={grades} emptyText="No grades submitted yet" />
        )}
        {!submitted && grades.length > 0 && (
          <Table columns={columns} data={grades} emptyText="No grades submitted yet" />
        )}
        {!selectedExam && (
          <p style={{ color: 'var(--text-muted)', fontSize: 13, textAlign: 'center', padding: '24px 0' }}>
            Select a class and exam to view and enter grades.
          </p>
        )}
      </Card>

      {/* Request Grade Change Modal */}
      <Modal open={requestModal} onClose={() => setRequestModal(false)} title="Request Grade Change">
        <form onSubmit={submitGradeChangeRequest}>
          {/* Show Grade ID as read-only info */}
          <div style={{ background: '#f8fafc', border: '1px solid var(--border)', borderRadius: 7, padding: '10px 14px', marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Grade Record ID</span>
            <span style={{ fontFamily: 'monospace', fontSize: 14, fontWeight: 700, color: 'var(--primary)' }}>#{selectedGradeId}</span>
          </div>
          <Input
            label="Requested New Value (Marks)"
            type="number"
            step="0.1"
            min="0"
            max="100"
            value={requestForm.newValue}
            onChange={e => setRequestForm({ ...requestForm, newValue: e.target.value })}
            required
            placeholder="Enter new marks value"
          />
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
              Reason for Change
            </label>
            <textarea
              value={requestForm.reason}
              onChange={e => setRequestForm({ ...requestForm, reason: e.target.value })}
              required
              rows={3}
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none' }}
              placeholder="Explain why the marks should be changed..."
            />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
              Evidence (PDF Upload)
            </label>
            <input
              type="file"
              accept=".pdf"
              onChange={e => setRequestForm({ ...requestForm, evidenceFile: e.target.files[0] })}
              style={{ padding: '8px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 13, width: '100%', boxSizing: 'border-box' }}
            />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setRequestModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Submit Request</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
