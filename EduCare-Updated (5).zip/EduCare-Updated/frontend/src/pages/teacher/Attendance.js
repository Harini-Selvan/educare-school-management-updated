import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { attendanceAPI, classAPI, studentAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function TeacherAttendance() {
  const { user } = useAuth();
  const [classes, setClasses] = useState([]);      // teacher's assigned classes only
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [batchRecords, setBatchRecords] = useState([]);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);
  const [loadingStudents, setLoadingStudents] = useState(false);

  // On mount: load teacher's assigned classes only
  useEffect(() => {
    let cancelled = false;
    async function loadTeacherClasses() {
      try {
        // Find this teacher's profile
        const teachersRes = await classAPI.getTeachers();
        const allTeachers = teachersRes.data || [];
        const myProfile = allTeachers.find(t =>
          String(t.userId) === String(user?.userId) || t.name === user?.name
        );

        if (!myProfile) {
          // Fallback: show all active classes if teacher profile not found
          const allClassesRes = await classAPI.getAll();
          if (!cancelled) setClasses(allClassesRes.data?.filter(c => c.status === 'ACTIVE') || []);
          return;
        }

        // Get only this teacher's assigned classes
        const assignRes = await classAPI.getAssignmentsByTeacher(myProfile.id);
        const assignments = (assignRes.data || []).filter(a => a.status === 'ACTIVE');

        if (assignments.length === 0) {
          if (!cancelled) setClasses([]);
          return;
        }

        // Load class details
        const allClassesRes = await classAPI.getAll();
        const allClasses = allClassesRes.data || [];
        const assignedIds = new Set(assignments.map(a => String(a.classId)));
        const teacherClasses = allClasses.filter(c => assignedIds.has(String(c.id)) && c.status === 'ACTIVE');
        if (!cancelled) setClasses(teacherClasses);
      } catch {
        // Last resort fallback
        try {
          const allClassesRes = await classAPI.getAll();
          if (!cancelled) setClasses(allClassesRes.data?.filter(c => c.status === 'ACTIVE') || []);
        } catch {}
      }
    }
    loadTeacherClasses();
    return () => { cancelled = true; };
  }, [user]);

  async function loadStudents(classId) {
    setSelectedClass(classId);
    setStudents([]);
    setBatchRecords([]);
    setAttendance([]);
    if (!classId) return;

    setLoadingStudents(true);
    try {
      // Get enrollment records for this class
      const enrollRes = await studentAPI.getEnrollmentsByClass(classId);
      const enrollments = enrollRes.data || [];
      const activeEnrollments = enrollments.filter(e =>
        e.status === 'ACTIVE' || e.status === 'active'
      );

      if (activeEnrollments.length === 0) {
        setToast({
          message: 'No students enrolled in this class yet. Ask admin to enroll students.',
          type: 'error',
        });
        setLoadingStudents(false);
        return;
      }

      // Get all students and filter to enrolled ones
      const allStudentsRes = await studentAPI.getAll();
      const allStudents = allStudentsRes.data || [];

      // Use String comparison to avoid type mismatch
      const enrolledStudentIds = new Set(activeEnrollments.map(e => String(e.studentId)));
      const classStudents = allStudents.filter(s => enrolledStudentIds.has(String(s.id)));

      if (classStudents.length === 0) {
        // Enrollment records exist but no matching students — show all students as fallback
        setToast({
          message: `Found ${activeEnrollments.length} enrollment record(s) but could not match student profiles. Showing all students.`,
          type: 'error',
        });
        // Use all students as fallback so teacher can still mark attendance
        const fallbackStudents = allStudents;
        setStudents(fallbackStudents);
        setBatchRecords(fallbackStudents.map(s => ({
          studentId: s.id,
          name: s.name,
          classId: Number(classId),
          date: selectedDate,
          status: 'PRESENT',
        })));
        setLoadingStudents(false);
        return;
      }

      setStudents(classStudents);
      setBatchRecords(classStudents.map(s => ({
        studentId: s.id,
        name: s.name,
        classId: Number(classId),
        date: selectedDate,
        status: 'PRESENT',
      })));
    } catch (err) {
      setToast({ message: 'Error loading students: ' + (err.response?.data?.message || err.message || 'Unknown error'), type: 'error' });
    } finally {
      setLoadingStudents(false);
    }
  }

  async function loadAttendanceRecords() {
    if (!selectedClass || !selectedDate) return;
    try {
      const r = await attendanceAPI.getByClassAndDate(selectedClass, selectedDate);
      setAttendance(r.data || []);
      if ((r.data || []).length === 0) {
        setToast({ message: 'No attendance records for this date yet.', type: 'error' });
      }
    } catch {
      setToast({ message: 'Could not load attendance records.', type: 'error' });
    }
  }

  async function saveBatch() {
    if (batchRecords.length === 0) {
      setToast({ message: 'No students to mark attendance for.', type: 'error' });
      return;
    }
    setSaving(true);
    let saved = 0; let skipped = 0;

    // Try batch endpoint first
    try {
      await attendanceAPI.recordBatch({
        classId: Number(selectedClass),
        date: selectedDate,
        recordedBy: user?.email || 'teacher',
        records: batchRecords.map(r => ({
          studentId: r.studentId,
          classId: Number(selectedClass),
          date: selectedDate,
          status: r.status,
          recordedBy: user?.email || 'teacher',
        })),
      });
      saved = batchRecords.length;
    } catch (batchErr) {
      // Batch failed — try one by one
      for (const rec of batchRecords) {
        try {
          await attendanceAPI.record({
            studentId: rec.studentId,
            classId: Number(selectedClass),
            date: selectedDate,
            status: rec.status,
            recordedBy: user?.email || 'teacher',
          });
          saved++;
        } catch (indErr) {
          const msg = (indErr.response?.data?.message || '').toLowerCase();
          if (msg.includes('already')) skipped++;
        }
      }
    }

    setSaving(false);
    if (saved > 0 || skipped > 0) {
      setToast({
        message: `Attendance saved for ${saved} student(s)!${skipped > 0 ? ` (${skipped} already recorded)` : ''}`,
        type: 'success',
      });
      await loadAttendanceRecords();
    } else {
      setToast({ message: 'Could not save attendance. Please try again.', type: 'error' });
    }
  }

  const getStudentName = id => students.find(s => Number(s.id) === Number(id))?.name || `Student #${id}`;

  return (
    <DashboardLayout title="Attendance Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <Card title="Record Attendance" style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 16, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}>
            {classes.length === 0 ? (
              <div style={{ padding: '10px', background: '#fef9c3', borderRadius: 7, border: '1px solid #fde047', fontSize: 13, color: '#713f12' }}>
                ⚠️ No classes assigned to you yet. Ask admin to assign you to a class.
              </div>
            ) : (
              <Select
                label="Select Class"
                value={selectedClass}
                onChange={e => loadStudents(e.target.value)}
                placeholder="Choose your class..."
                options={classes.map(c => ({ value: c.id, label: c.name }))}
                style={{ marginBottom: 0 }}
              />
            )}
          </div>
          <div style={{ flex: 1 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={e => {
                setSelectedDate(e.target.value);
                setBatchRecords(prev => prev.map(r => ({ ...r, date: e.target.value })));
              }}
              style={{ width: '100%', padding: '9px 13px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, outline: 'none', background: '#f8fafc', fontFamily: 'Outfit, sans-serif' }}
            />
          </div>
          <Button onClick={loadAttendanceRecords} variant="secondary">View Records</Button>
        </div>

        {loadingStudents && (
          <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)' }}>
            Loading enrolled students...
          </div>
        )}

        {!loadingStudents && batchRecords.length > 0 && (
          <>
            <div style={{ marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h4 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>
                Mark Attendance — {batchRecords.length} student(s)
              </h4>
              <Button onClick={saveBatch} loading={saving}>Submit Attendance</Button>
            </div>
            <div style={{ display: 'grid', gap: 8 }}>
              {batchRecords.map((rec, i) => (
                <div key={rec.studentId} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', background: 'var(--surface2)', borderRadius: 8, border: '1px solid var(--border)' }}>
                  <div>
                    <span style={{ fontWeight: 600, fontSize: 14 }}>{rec.name}</span>
                    <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 8 }}>ID: {rec.studentId}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'].map(s => (
                      <button
                        key={s}
                        onClick={() => setBatchRecords(prev => prev.map((r, j) => j === i ? { ...r, status: s } : r))}
                        style={{
                          padding: '5px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: 'pointer',
                          border: rec.status === s ? 'none' : '1px solid var(--border)',
                          background: rec.status === s
                            ? (s === 'PRESENT' ? '#059669' : s === 'ABSENT' ? '#dc2626' : s === 'LATE' ? '#d97706' : '#7c3aed')
                            : 'var(--surface)',
                          color: rec.status === s ? '#fff' : 'var(--text-muted)',
                          fontFamily: 'Outfit, sans-serif',
                        }}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      {attendance.length > 0 && (
        <Card title={`Attendance Records — ${selectedDate}`}>
          <Table
            columns={[
              { title: 'Student Name', key: 'studentId', render: v => <span style={{ fontWeight: 600 }}>{getStudentName(v)}</span> },
              { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
              { title: 'Recorded By', key: 'recordedBy' },
              { title: 'Remarks', key: 'remarks' },
            ]}
            data={attendance}
          />
        </Card>
      )}
    </DashboardLayout>
  );
}
