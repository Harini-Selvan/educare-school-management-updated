import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import StatCard from '../../components/common/StatCard';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import { notificationAPI, examAPI, classAPI, studentAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function TeacherDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [requests, setRequests] = useState([]);
  const [myClasses, setMyClasses] = useState([]);
  const [studentCount, setStudentCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [t, r, n] = await Promise.all([
          notificationAPI.getMyTasks().catch(() => ({ data: [] })),
          examAPI.getMyRequests().catch(() => ({ data: [] })),
          notificationAPI.getMy().catch(() => ({ data: [] })),
        ]);
        if (!cancelled) {
          setTasks(t.data || []);
          setRequests(r.data || []);
          setNotifications(n.data || []);
        }

        // Load teacher's class info
        const teachersRes = await classAPI.getTeachers();
        const allTeachers = teachersRes.data || [];
        const myProfile = allTeachers.find(t2 =>
          String(t2.userId) === String(user?.userId) || t2.name === user?.name
        );

        if (myProfile) {
          const assignRes = await classAPI.getAssignmentsByTeacher(myProfile.id);
          const assignments = (assignRes.data || []).filter(a => a.status === 'ACTIVE');

          const allClassesRes = await classAPI.getAll();
          const allClasses = allClassesRes.data || [];
          const assignedIds = new Set(assignments.map(a => String(a.classId)));
          const teacherClasses = allClasses.filter(c => assignedIds.has(String(c.id)));
          if (!cancelled) setMyClasses(teacherClasses);

          // Count enrolled students across all assigned classes
          let totalStudents = 0;
          for (const cls of teacherClasses) {
            try {
              const eRes = await studentAPI.getEnrollmentsByClass(cls.id);
              totalStudents += (eRes.data || []).filter(e => e.status === 'ACTIVE').length;
            } catch {}
          }
          if (!cancelled) setStudentCount(totalStudents);
        }
      } catch {}
      finally { if (!cancelled) setLoading(false); }
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  const pendingTasks = tasks.filter(t => t.status === 'PENDING').length;
  const pendingRequests = requests.filter(r => r.status === 'PENDING').length;
  const unreadNotifs = notifications.filter(n => n.status === 'UNREAD').length;

  return (
    <DashboardLayout title="Teacher Console">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard title="My Students" value={loading ? '...' : studentCount} icon="🎓" color="var(--success)" />
        <StatCard title="My Classes" value={loading ? '...' : myClasses.length} icon="🏫" color="var(--primary)" />
        <StatCard title="Pending Tasks" value={loading ? '...' : pendingTasks} icon="✅" color="var(--warning)" />
        <StatCard title="Unread Alerts" value={loading ? '...' : unreadNotifs} icon="🔔" color="var(--danger)" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* My Classes */}
        <Card title="My Assigned Classes" extra={<Button size="sm" onClick={() => navigate('/teacher/timetable')}>View Timetable</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           myClasses.length === 0 ? (
            <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)' }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>🏫</div>
              <p style={{ fontSize: 13 }}>No classes assigned yet. Ask admin to assign you.</p>
            </div>
          ) : (
            myClasses.map(cls => (
              <div key={cls.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{cls.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Capacity: {cls.capacity || 'N/A'}</div>
                </div>
                <Badge text={cls.status} />
              </div>
            ))
          )}
        </Card>

        {/* Tasks */}
        <Card title="My Tasks" extra={<Button size="sm" onClick={() => navigate('/teacher/tasks')}>View All</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           tasks.length === 0 ? <p style={{ color: 'var(--text-muted)', fontSize: 14, padding: '12px 0' }}>No tasks assigned</p> :
           tasks.slice(0, 5).map(t => (
            <div key={t.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>{t.description}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Due: {t.dueDate}</div>
              </div>
              <Badge text={t.status} />
            </div>
          ))}
        </Card>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Grade Requests */}
        <Card title="Grade Change Requests" extra={<Button size="sm" onClick={() => navigate('/teacher/grade-requests')}>View All</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           requests.length === 0 ? <p style={{ color: 'var(--text-muted)', fontSize: 14, padding: '12px 0' }}>No grade requests submitted</p> :
           requests.slice(0, 4).map(r => (
            <div key={r.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>Grade #{r.gradeId}: {r.currentValue} → {r.requestedValue}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{r.reason?.substring(0, 40)}{r.reason?.length > 40 ? '...' : ''}</div>
              </div>
              <Badge text={r.status} />
            </div>
          ))}
        </Card>

        {/* Notifications */}
        <Card title="Recent Notifications" extra={<Button size="sm" onClick={() => navigate('/teacher/notifications')}>View All</Button>}>
          {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> :
           notifications.length === 0 ? <p style={{ color: 'var(--text-muted)', fontSize: 14, padding: '12px 0' }}>No notifications yet</p> :
           notifications.slice(0, 4).map(n => (
            <div key={n.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)', background: n.status === 'UNREAD' ? 'var(--primary-light)' : 'transparent', borderRadius: 4, paddingLeft: n.status === 'UNREAD' ? 8 : 0 }}>
              <div style={{ fontSize: 13, fontWeight: n.status === 'UNREAD' ? 600 : 400 }}>{n.message?.substring(0, 60)}{n.message?.length > 60 ? '...' : ''}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}</div>
            </div>
          ))}
        </Card>
      </div>
    </DashboardLayout>
  );
}
