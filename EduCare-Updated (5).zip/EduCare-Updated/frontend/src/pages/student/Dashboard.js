import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import StatCard from '../../components/common/StatCard';
import Card from '../../components/common/Card';
import Badge from '../../components/common/Badge';
import Table from '../../components/common/Table';
import { studentAPI, attendanceAPI, examAPI, classAPI } from '../../services/api';

export default function StudentDashboard() {
  const [profile, setProfile] = useState(null);
  const [summary, setSummary] = useState(null);
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [className, setClassName] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const pRes = await studentAPI.getMyProfile();
        if (cancelled) return;
        const p = pRes.data;
        setProfile(p);
        // Get student's class via enrollment
        try {
          const eRes = await studentAPI.getEnrollmentsByStudent(p.id);
          const activeEnrollment = (eRes.data || []).find(e => e.status === 'ACTIVE');
          if (activeEnrollment) {
            const cRes = await classAPI.getById(activeEnrollment.classId);
            if (!cancelled) setClassName(cRes.data?.name || '');
          }
        } catch {}
        const [aRes, gRes] = await Promise.all([
          attendanceAPI.getSummary(p.id),
          examAPI.getGradesByStudent(p.id),
        ]);
        if (cancelled) return;
        setSummary(aRes.data);
        setGrades(gRes.data || []);
      } catch (err) {
        if (!cancelled) setError('Could not load profile. Ask admin to register your student link.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const avg = grades.length
    ? (grades.reduce((s, g) => s + g.gradeValue, 0) / grades.length).toFixed(1)
    : 'N/A';

  return (
    <DashboardLayout title="Student Dashboard">

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <StatCard title="Attendance %" value={loading ? '...' : (summary ? summary.attendancePercentage + '%' : 'N/A')} icon="📊" color="var(--success)" />
        <StatCard title="Days Present" value={loading ? '...' : (summary?.presentDays ?? 0)} icon="✅" color="var(--primary)" />
        <StatCard title="Total Exams" value={loading ? '...' : grades.length} icon="📝" color="var(--warning)" />
        <StatCard title="Average Grade" value={loading ? '...' : avg} icon="🎯" color="var(--purple)" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* Profile Card */}
        <Card title="My Profile">
          {loading ? (
            <p style={{ color: 'var(--text-muted)', padding: 20 }}>Loading...</p>
          ) : error ? (
            <div style={{ background: '#fee2e2', border: '1px solid #fecaca', borderRadius: 8, padding: 16, color: '#991b1b', fontSize: 13 }}>
              <strong>⚠️ {error}</strong>
            </div>
          ) : profile ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
                <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#fff7ed', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 800, color: '#c2410c', flexShrink: 0 }}>
                  {profile.name?.charAt(0)}
                </div>
                <div>
                  <div style={{ fontSize: 20, fontWeight: 800 }}>{profile.name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{className || profile.program}</div>
                  <Badge text={profile.status} />
                </div>
              </div>
              {[
                ['Student ID', profile.id],
                ['Date of Birth', profile.dob],
                ['Gender', profile.gender],
                ['Contact', profile.contactInfo],
              ].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 500 }}>{l}</span>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>{v || '-'}</span>
                </div>
              ))}

            </div>
          ) : null}
        </Card>

        {/* Recent Grades */}
        <Card title="Recent Grades">
          {loading ? (
            <p style={{ color: 'var(--text-muted)' }}>Loading...</p>
          ) : grades.length === 0 ? (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>📝</div>
              <p>No grades yet</p>
            </div>
          ) : (
            <>
              {grades.slice(0, 5).map(g => (
                <div key={g.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{g.examName || g.subject || `Exam #${g.examId}`}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{g.submittedAt ? new Date(g.submittedAt).toLocaleDateString() : ''}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 20, fontWeight: 800, color: g.gradeValue >= 40 ? 'var(--success)' : 'var(--danger)' }}>{g.gradeValue}</div>
                  </div>
                </div>
              ))}
            </>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
