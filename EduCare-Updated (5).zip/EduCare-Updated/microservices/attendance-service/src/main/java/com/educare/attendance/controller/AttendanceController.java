package com.educare.attendance.controller;

import com.educare.attendance.dto.request.AttendanceRequest;
import com.educare.attendance.dto.request.BatchAttendanceRequest;
import com.educare.attendance.dto.response.AttendanceResponse;
import com.educare.attendance.dto.response.AttendanceSummaryResponse;
import com.educare.attendance.exception.UnauthorizedException;
import com.educare.attendance.security.RoleValidator;
import com.educare.attendance.service.AttendanceService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final RoleValidator roleValidator;

    // ADMIN, TEACHER can record attendance
    @PostMapping
    public ResponseEntity<AttendanceResponse> record(
            @Valid @RequestBody AttendanceRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER");
        return ResponseEntity.ok(attendanceService.recordAttendance(req));
    }

    // ADMIN, TEACHER can record batch attendance
    @PostMapping("/batch")
    public ResponseEntity<List<AttendanceResponse>> recordBatch(
            @Valid @RequestBody BatchAttendanceRequest req, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER");
        return ResponseEntity.ok(attendanceService.recordBatch(req));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR → see any student
    // PARENT, STUDENT → only see if they are linked to that student
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<AttendanceResponse>> byStudent(
            @PathVariable Long studentId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR", "AUDITOR");
        checkStudentAccess(request, studentId);
        return ResponseEntity.ok(attendanceService.getByStudent(studentId));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR can view class attendance
    @GetMapping("/class/{classId}/date/{date}")
    public ResponseEntity<List<AttendanceResponse>> byClassAndDate(
            @PathVariable Long classId,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "EXAM_COORDINATOR", "AUDITOR");
        return ResponseEntity.ok(attendanceService.getByClassAndDate(classId, date));
    }

    // ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR → any student
    // PARENT, STUDENT → only their linked student
    @GetMapping("/summary/{studentId}")
    public ResponseEntity<AttendanceSummaryResponse> summary(
            @PathVariable Long studentId, HttpServletRequest request) {
        roleValidator.requireAnyRole(request, "ADMIN", "TEACHER", "PARENT", "STUDENT", "EXAM_COORDINATOR", "AUDITOR");
        checkStudentAccess(request, studentId);
        return ResponseEntity.ok(attendanceService.getSummary(studentId));
    }

    /**
     * ADMIN, TEACHER, EXAM_COORDINATOR, AUDITOR pass freely.
     * PARENT and STUDENT must be linked to the requested studentId.
     */
    private void checkStudentAccess(HttpServletRequest request, Long studentId) {
        String role = roleValidator.getRole(request);
        // These roles can see any student's data
        if ("ADMIN".equals(role) || "TEACHER".equals(role) ||
            "EXAM_COORDINATOR".equals(role) || "AUDITOR".equals(role)) {
            return;
        }
        // PARENT and STUDENT must be linked to the student
        String email = roleValidator.getEmail(request);
        boolean linked = attendanceService.isLinkedToStudent(studentId, email, role);
        if (!linked) {
            throw new UnauthorizedException(
                "Access denied. You are not linked to student ID: " + studentId
            );
        }
    }
}