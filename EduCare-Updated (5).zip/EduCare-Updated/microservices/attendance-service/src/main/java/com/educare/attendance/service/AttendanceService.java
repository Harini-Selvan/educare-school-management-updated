package com.educare.attendance.service;

import com.educare.attendance.client.ClassServiceClient;
import com.educare.attendance.client.StudentServiceClient;
import com.educare.attendance.dto.request.AttendanceRequest;
import com.educare.attendance.dto.request.BatchAttendanceRequest;
import com.educare.attendance.dto.response.AttendanceResponse;
import com.educare.attendance.dto.response.AttendanceSummaryResponse;
import com.educare.attendance.entity.AttendanceRecord;
import com.educare.attendance.enums.AttendanceStatus;
import com.educare.attendance.exception.BadRequestException;
import com.educare.attendance.exception.ResourceNotFoundException;
import com.educare.attendance.repository.AttendanceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentServiceClient studentServiceClient;
    private final ClassServiceClient classServiceClient;

    public AttendanceResponse recordAttendance(AttendanceRequest req) {
        validateStudentExists(req.getStudentId());
        validateClassExists(req.getClassId());

        if (attendanceRepository.existsByStudentIdAndClassIdAndDate(
                req.getStudentId(), req.getClassId(), req.getDate()))
            throw new BadRequestException(
                "Attendance already recorded for this student on " + req.getDate());

        AttendanceRecord saved = attendanceRepository.save(AttendanceRecord.builder()
                .studentId(req.getStudentId()).classId(req.getClassId())
                .date(req.getDate()).status(req.getStatus())
                .recordedBy(req.getRecordedBy()).remarks(req.getRemarks()).build());

        log.info("Attendance recorded — student: {}, date: {}, status: {}",
                req.getStudentId(), req.getDate(), req.getStatus());
        return toResponse(saved);
    }

    public List<AttendanceResponse> recordBatch(BatchAttendanceRequest req) {
        return req.getRecords().stream().map(r -> {
            r.setClassId(req.getClassId());
            r.setDate(req.getDate());
            r.setRecordedBy(req.getRecordedBy());
            return recordAttendance(r);
        }).collect(Collectors.toList());
    }

    private void validateStudentExists(Long studentId) {
        try {
            ResponseEntity<Boolean> response = studentServiceClient.existsById(studentId);
            if (!response.getStatusCode().is2xxSuccessful())
                throw new ResourceNotFoundException("Student not found: " + studentId);
        } catch (ResourceNotFoundException e) {
            throw e;
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg != null && (msg.contains("404") || msg.contains("Not Found")))
                throw new ResourceNotFoundException("Student not found: " + studentId);
            log.error("Student validation failed for {}: {}", studentId, msg);
            throw new BadRequestException("Cannot verify student ID: " + studentId);
        }
    }

    private void validateClassExists(Long classId) {
        try {
            ResponseEntity<Boolean> response = classServiceClient.existsById(classId);
            if (!response.getStatusCode().is2xxSuccessful())
                throw new ResourceNotFoundException("Class not found: " + classId);
        } catch (ResourceNotFoundException e) {
            throw e;
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg != null && (msg.contains("404") || msg.contains("Not Found")))
                throw new ResourceNotFoundException("Class not found: " + classId);
            log.error("Class validation failed for {}: {}", classId, msg);
            throw new BadRequestException("Cannot verify class ID: " + classId);
        }
    }

    public List<AttendanceResponse> getByStudent(Long studentId) {
        return attendanceRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<AttendanceResponse> getByClassAndDate(Long classId, LocalDate date) {
        return attendanceRepository.findByClassIdAndDate(classId, date)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public AttendanceSummaryResponse getSummary(Long studentId) {
        long total   = attendanceRepository.countByStudentId(studentId);
        long present = attendanceRepository.countByStudentIdAndStatus(studentId, AttendanceStatus.PRESENT);
        long absent  = attendanceRepository.countByStudentIdAndStatus(studentId, AttendanceStatus.ABSENT);
        long late    = attendanceRepository.countByStudentIdAndStatus(studentId, AttendanceStatus.LATE);
        double pct   = total > 0 ? (double)(present + late) / total * 100 : 0;
        return AttendanceSummaryResponse.builder()
                .studentId(studentId).totalDays(total)
                .presentDays(present).absentDays(absent).lateDays(late)
                .attendancePercentage(Math.round(pct * 100.0) / 100.0).build();
    }

    public boolean isLinkedToStudent(Long studentId, String email, String role) {
        try {
            Boolean result = studentServiceClient.isLinkedToStudent(studentId, email, role);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            log.warn("Could not verify student link: {}", e.getMessage());
            return false;
        }
    }

    private AttendanceResponse toResponse(AttendanceRecord a) {
        return AttendanceResponse.builder()
                .id(a.getId()).studentId(a.getStudentId()).classId(a.getClassId())
                .date(a.getDate()).status(a.getStatus())
                .recordedBy(a.getRecordedBy()).remarks(a.getRemarks()).build();
    }
}