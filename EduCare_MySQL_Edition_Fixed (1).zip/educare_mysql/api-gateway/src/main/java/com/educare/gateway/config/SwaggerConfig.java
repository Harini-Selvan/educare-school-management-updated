package com.educare.gateway.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI gatewayOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("EduCare API Gateway")
                        .version("1.0.0")
                        .description("Central API Gateway for the EduCare microservices platform. " +
                                "Routes and authenticates requests to all downstream services: " +
                                "identity-service, student-service, class-teacher-service, " +
                                "attendance-service, exam-grade-service, notification-service, " +
                                "reporting-service, and task-alert-service.")
                        .contact(new Contact()
                                .name("EduCare Team"))
                        .license(new License()
                                .name("Apache 2.0")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:9090")
                                .description("Local API Gateway")
                ));
    }
}
