import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { authAPI } from '../../services/api';

export default function AdminRegisteredUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewModal, setViewModal] = useState(false);
  const [selected, setSelected] = useState(null);
  const [editModal, setEditModal] = useState(false);
  const [toast, setToast] = useState(null);
  const [filter, setFilter] = useState('');

  const load = () => { setLoading(true); authAPI.getUsers().then(r => setUsers(r.data || [])).finally(() => setLoading(false)); };
  useEffect(load, []);

  const toggleStatus = async (user) => {
    const newStatus = user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      await authAPI.updateUserStatus(user.id, newStatus);
      setToast({ message: `User ${newStatus.toLowerCase()}d`, type: 'success' });
      load();
    } catch { setToast({ message: 'Error updating status', type: 'error' }); }
  };

  const filtered = filter ? users.filter(u => u.role === filter) : users;

  const roleColors = { ADMIN: '#1e40af', TEACHER: '#059669', STUDENT: '#d97706', PARENT: '#7c3aed', EXAM_COORDINATOR: '#0891b2', AUDITOR: '#475569' };

  const columns = [
    { title: 'Name', key: 'name', render: (v, r) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: (roleColors[r.role] || '#1e40af') + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: roleColors[r.role] || '#1e40af', flexShrink: 0 }}>{v?.charAt(0)?.toUpperCase()}</div>
        <div>
          <div style={{ fontWeight: 600, color: 'var(--text)' }}>{v}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{r.email}</div>
        </div>
      </div>
    )},
    { title: 'Phone', key: 'phone', render: v => v || <span style={{ color: 'var(--text-muted)' }}>—</span> },
    { title: 'Role', key: 'role', render: v => <Badge text={v} /> },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Registered', key: 'createdAt', render: v => v ? new Date(v).toLocaleDateString() : '—' },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <div style={{ display: 'flex', gap: 6 }}>
        <Button variant="ghost" size="sm" onClick={() => { setSelected(r); setViewModal(true); }}>View</Button>
        <Button variant={r.status === 'ACTIVE' ? 'danger' : 'success'} size="sm" onClick={() => toggleStatus(r)}>
          {r.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
        </Button>
      </div>
    )},
  ];

  return (
    <DashboardLayout title="Registered Users">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 12, marginBottom: 20 }}>
        {['ADMIN','TEACHER','STUDENT','PARENT','EXAM_COORDINATOR','AUDITOR'].map(role => (
          <div key={role} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 16px', borderTop: `3px solid ${roleColors[role]}` }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: roleColors[role] }}>{users.filter(u => u.role === role).length}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, marginTop: 2 }}>{role === 'EXAM_COORDINATOR' ? 'Coordinator' : role.charAt(0) + role.slice(1).toLowerCase()}s</div>
          </div>
        ))}
      </div>

      <Card
        title="All Registered Users"
        subtitle={`${filtered.length} users`}
        extra={
          <div style={{ display: 'flex', gap: 8 }}>
            <select value={filter} onChange={e => setFilter(e.target.value)} style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontSize: 13, background: 'var(--surface)', outline: 'none' }}>
              <option value="">All Roles</option>
              {['ADMIN','TEACHER','STUDENT','PARENT','EXAM_COORDINATOR','AUDITOR'].map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
        }
      >
        <Table columns={columns} data={filtered} loading={loading} />
      </Card>

      {/* View User Modal */}
      {selected && (
        <Modal open={viewModal} onClose={() => setViewModal(false)} title="User Details">
          <div style={{ display: 'grid', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px', background: 'var(--surface2)', borderRadius: 10, marginBottom: 8 }}>
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: (roleColors[selected.role] || '#1e40af') + '20', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 800, color: roleColors[selected.role] || '#1e40af' }}>
                {selected.name?.charAt(0)?.toUpperCase()}
              </div>
              <div>
                <div style={{ fontSize: 18, fontWeight: 700 }}>{selected.name}</div>
                <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{selected.email}</div>
                <div style={{ marginTop: 4 }}><Badge text={selected.role} /></div>
              </div>
            </div>
            {[['User ID', selected.id], ['Phone', selected.phone || '—'], ['Status', selected.status], ['Registered', selected.createdAt ? new Date(selected.createdAt).toLocaleString() : '—']].map(([l, v]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{l}</span>
                <span style={{ fontSize: 13, fontWeight: 600 }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
              <Button variant="secondary" onClick={() => setViewModal(false)}>Close</Button>
            </div>
          </div>
        </Modal>
      )}
    </DashboardLayout>
  );
}
