import React, { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Card from '../../components/common/Card';
import Table from '../../components/common/Table';
import Badge from '../../components/common/Badge';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Toast from '../../components/common/Toast';
import { examAPI, classAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

export default function CoordinatorGrades() {
  const { user } = useAuth();
  const [classes, setClasses] = useState([]);
  const [exams, setExams] = useState([]);
  const [grades, setGrades] = useState([]);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [modifyModal, setModifyModal] = useState(false);
  const [selectedGrade, setSelectedGrade] = useState(null);
  const [modifyForm, setModifyForm] = useState({ newValue: '', reason: '', evidenceUri: '' });
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const r = await classAPI.getAll();
        if (!cancelled) setClasses(r.data?.filter(c => c.status === 'ACTIVE') || []);
      } catch (err) { /* ignore */ }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  function loadExams(id) { setSelectedClass(id); if (id) examAPI.getByClass(id).then(r => setExams(r.data || [])).catch(() => {}); }
  function loadGrades(id) { setSelectedExam(id); if (id) examAPI.getGradesByExam(id).then(r => setGrades(r.data || [])).catch(() => {}); }

  async function handleModify(e) {
    e.preventDefault(); setSaving(true);
    try {
      await examAPI.modifyGrade(selectedGrade.id, { ...modifyForm, newValue: Number(modifyForm.newValue), changedBy: user?.email });
      setToast({ message: 'Grade modified!', type: 'success' });
      setModifyModal(false); loadGrades(selectedExam);
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error', type: 'error' }); }
    finally { setSaving(false); }
  }

  const columns = [
    { title: 'Student ID', key: 'studentId' },
    { title: 'Grade', key: 'gradeValue', render: v => <span style={{ fontSize: 20, fontWeight: 800, color: v >= 40 ? 'var(--success)' : 'var(--danger)' }}>{v}</span> },
    { title: 'Status', key: 'status', render: v => <Badge text={v} /> },
    { title: 'Remarks', key: 'remarks' },
    { title: 'Actions', key: 'id', render: (v, r) => (
      <div style={{ display: 'flex', gap: 4 }}>
        <Button size="sm" variant="ghost" onClick={() => { setSelectedGrade(r); setModifyModal(true); }}>Modify</Button>
        {r.status === 'MODERATED' && (
          <Button size="sm" variant="success" onClick={() => examAPI.approveGradeChange(r.id).then(() => { setToast({ message: 'Approved!', type: 'success' }); loadGrades(selectedExam); }).catch(() => {})}>Approve</Button>
        )}
      </div>
    )},
  ];

  return (
    <DashboardLayout title="Grade Management">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <Card title="Grades">
        <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
          <div style={{ flex: 1 }}><Select value={selectedClass} onChange={e => loadExams(e.target.value)} options={classes.map(c => ({value: c.id, label: c.name}))} style={{ marginBottom: 0 }} /></div>
          <div style={{ flex: 1 }}><Select value={selectedExam} onChange={e => loadGrades(e.target.value)} options={exams.map(e => ({value: e.id, label: e.subject}))} style={{ marginBottom: 0 }} /></div>
        </div>
        <Table columns={columns} data={grades} emptyText="Select class and exam to view grades" />
      </Card>
      <Modal open={modifyModal} onClose={() => setModifyModal(false)} title="Modify Grade">
        <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>Current grade: <strong>{selectedGrade?.gradeValue}</strong></p>
        <form onSubmit={handleModify}>
          <Input label="New Value" type="number" step="0.1" value={modifyForm.newValue} onChange={e => setModifyForm({...modifyForm, newValue: e.target.value})} required />
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#475569', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' }}>Reason</label>
            <textarea value={modifyForm.reason} onChange={e => setModifyForm({...modifyForm, reason: e.target.value})} required rows={3}
              style={{ width: '100%', padding: '9px 13px', border: '1.5px solid #e2e8f0', borderRadius: 7, fontSize: 14, resize: 'vertical', fontFamily: 'Outfit, sans-serif', boxSizing: 'border-box', outline: 'none', background: '#f8fafc' }} />
          </div>
          <Input label="Evidence URI" value={modifyForm.evidenceUri} onChange={e => setModifyForm({...modifyForm, evidenceUri: e.target.value})} required placeholder="/evidence/file.pdf" />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="secondary" onClick={() => setModifyModal(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Modify</Button>
          </div>
        </form>
      </Modal>
    </DashboardLayout>
  );
}
